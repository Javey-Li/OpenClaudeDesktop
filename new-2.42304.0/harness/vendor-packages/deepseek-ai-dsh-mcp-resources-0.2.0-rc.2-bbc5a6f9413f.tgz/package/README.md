---
description: "Discover and read MCP resources on demand with shared tools, optional discovery filters, and agent-scoped access."
kind: "package-reference"
---

# @deepseek-ai/dsh-mcp-resources

English | [中文](README.zh.md)

## Summary

`dsh-mcp-resources` lets the model discover and read documents from configured MCP servers. Shipped profiles make admitted shared tools available when a server is configured in the caller's scope. Discovery can query one server or aggregate all admitted servers; templates and reads require an explicit server. Content is read only when called. Resource text enters conversation history; binary payloads remain available to programmatic callers and appear as descriptions to the model.

## Table of Contents

- [Use this package](#use-this-package)
- [Understand the implementation](#understand-the-implementation)
- [Further Exploration](#further-exploration)
- [Model Experience](#model-experience)
- [Known Limitations and Deferred Work](#known-limitations-and-deferred-work)
- [Dev Note](#dev-note)

-----

<a id="use-this-package"></a>
## Use this package

Shipped profiles already mount this package once. Configure only the [MCP client](../mcp-client/README.md) entries for the servers you need.

### Server configuration

Use the [client configuration](../mcp-client/README.md#use-this-package) to add a server in the intended scope. This package has no configuration fields.

A caller with no configured MCP server sees no MCP prompt text or resource tools in native or PTC mode. A configured server enables all three shared resource tools by default, including when another provider mounts its client or the server has no tools or instructions. Connection failures do not remove the shared tools while the client entry remains active; discovery skips failed servers, while templates and reads report the connection error.

Programmatic registrations can pass a third tools argument to ctx.mcpResources.register, using names from MCP_RESOURCE_TOOL_NAMES. Omission admits all three operations; an empty list admits none. Operations are counted across providers in the same scope, and each request also checks the selected server’s admission, so a tool exposed for another server does not grant access. Removing a provider removes operations that no remaining provider admits. Scoped tool disposal completes before the registering owner finishes unloading.

### Discover and read

When system-prompt assembly is mounted, the prompt lists servers with operations available to the calling agent. Partial admission lists each server’s usable tools; a server with no usable operation is omitted. Call list_mcp_resources with an optional server filter, or omit it to query all admitted providers concurrently. Exact names take precedence over tool-safe normalized names. Normalization replaces characters outside ASCII letters, digits, underscore and hyphen with underscores; names beginning with "claude.ai " also collapse and trim underscores. Resource discovery collects every page and returns a flat array with the configured server name on each item. Failed providers contribute no entries. MCP Apps UI documents (ui:// URIs or text/html with profile=mcp-app) are excluded from discovery but remain directly readable.

Call list_mcp_resource_templates with an explicit server. Without cursor, the MCP SDK collects every page; an explicit cursor requests that page. Pass returned nextCursor unchanged. Read a listed URI or expanded template with read_mcp_resource using its server and uri. Templates and reads retain their complete protocol JSON.

Every operation resolves servers in the calling agent's scope and checks per-server admission before dispatch. An unavailable explicit server fails without a request; discovery does not fall through from an exact denied name to an allowed normalized collision. Caller cancellation reaches all active discovery requests, and the call waits for them to settle before returning cancellation. The connection owner handles timeouts and recovery.

-----

<a id="understand-the-implementation"></a>
## Understand the implementation

<details>
<summary>Implementation internals — click to expand</summary>

The [base](../../bundle/base/README.md) and standalone [sdk-minimal](../../bundle/sdk-minimal/README.md) bundles each own this row:

```yaml
- id: mcp-resources
  name: '@deepseek-ai/dsh-mcp-resources'
```

The first provider admitting an operation registers that shared tool; removing its last admitting provider removes that registration, while inherited providers and tools remain visible. The resource service owns the shared tool effects independently of the first provider's plugin, so unloading that provider cannot remove tools needed by another server. Provider selection and the server-name prompt use the same scoped registry. Each call resolves its server before dispatch.

Resource discovery returns attributed resource records without the protocol envelope. Templates and reads retain the complete JSON for programmatic callers. Their pure text renderer adds server attribution and replaces string-valued `blob` fields with a description of their base64 length; URI, MIME type, and text fields remain in the rendered JSON. The tool pipeline owns recorded results. Server instructions belong to the MCP client and its logged system-prompt section.

| Source | Responsibility |
|---|---|
| [`src/index.ts`](src/index.ts) | Scoped provider selection and server-name prompt context |
| [`src/tools.ts`](src/tools.ts) | Shared resource operations and argument schemas |
| [`src/discovery.ts`](src/discovery.ts) | Server-name matching and discovery result projection |
| [`src/render.ts`](src/render.ts) | Attributed text projection without inline binary payloads |

No runtime invariant companion is published: tools, prompt names, and dispatch derive from the same effect-owned provider registrations. They supply no independent observation to reconcile; registry-effect checks are not runtime invariants.

</details>

-----

<a id="further-exploration"></a>
## Further Exploration

These pages cover server configuration, execution, and the decisions behind resource access.

- [MCP client](../mcp-client/README.md) — server transports, instructions, and connection lifecycle.
- [Tools subsystem](../../../docs/subsystems/tools.md) — canonical values and model-visible results.
- [Resource visibility decision](../../../.agents/notes/implemented/feature/2026-09-13-mcp-resources-in-profiles.md) — shared profile mounting and visibility from configured servers.
- [Resources and instructions decision](../../../.agents/notes/implemented/feature/2026-09-12-mcp-resources-and-instructions.md) — scope, on-demand access, and excluded mechanisms.

-----

<a id="model-experience"></a>
## Model Experience

### Shared resource tools

#### What the model sees

The [generated tool schemas](../../../docs/tool-catalog.md#deepseek-aidsh-mcp-resources) define three tools shared by all caller-visible configured servers. With none, native schemas, PTC declarations and bindings, and the server-name prompt are absent. Connecting, disconnecting, or retrying an active client leaves these shared tool definitions unchanged. When system-prompt assembly is mounted and providers are visible, the `MCP resource servers` section says `Use list_mcp_resources, list_mcp_resource_templates, or read_mcp_resource with one of these names as the server argument: <JSON array>.` The names come from the same scoped registry, including servers with neither tools nor instructions. Partial admission lists each server and its usable operations. Tool masks also filter this guidance; no usable operations means no section. When listing is admitted, the section adds `Omit server in list_mcp_resources to discover resources from all admitted servers.`

#### Token effect

With no caller-visible configured servers, this package adds no tool or prompt tokens. Otherwise, up to three shared definitions contribute schema cost and the server-name section adds a sorted JSON list of visible names. Resource listings and documents add content only when an operation returns them.

#### KV Cache effect

Adding the first provider admitting an operation or removing the last changes the next tool schema or PTC declaration prefix. Changes to visible names update the server-name section; replacing a provider under the same name and admission leaves that text unchanged. Connection failures alone do not change the shared definitions or names.

### Resource results

#### What the model sees

Resource discovery renders its attributed array as JSON. An empty array renders `No resources found. MCP servers may still provide tools even if they have no resources.` A successful template or read result starts with `MCP server: <server>`, followed by a newline and the returned JSON. Each string-valued `blob` becomes `[binary resource: <length> base64 characters; available to programmatic callers]`. Server-provided text, metadata, and continuation cursors remain visible.

#### Token effect

Rendered results add text to tool history. Binary descriptions replace the payload's base64 token cost; this package imposes no separate text-size limit.

#### KV Cache effect

Each result appends to history without rewriting earlier results. Later reads can return changed server content and append a different result; the package does not refresh previously recorded content.

## Known Limitations and Deferred Work

<a id="known-limitations-and-deferred-work"></a>

Resource access is explicit and on demand.

- Unless filtered, a configured server without the MCP `resources` capability still appears in the server-name prompt and keeps shared resource tools available. The SDK returns empty resource and template lists; unsupported reads fail.
- `tools.restrict()` checks names supplied by global or ancestor scopes when the filter is registered. Naming a resource tool absent from those scopes fails as an unknown tool. Resource tools registered in the caller's own scope are outside allow/deny masks; their registering composition must pass the admitted operations explicitly.
- Resource subscriptions and update notifications are unsupported; call the list or read tools again to obtain current content.
- Binary resources are not projected as native images or audio. Programmatic callers retain their canonical base64 values.
- Templates and reads require an exact server name; normalized matching applies only to resource discovery. Account-specific memory server policy and resource-directory reads are not implemented.

<a id="dev-note"></a>
### Dev Note

<details>
<summary>Working context for maintainers — click to expand</summary>

None.

</details>
