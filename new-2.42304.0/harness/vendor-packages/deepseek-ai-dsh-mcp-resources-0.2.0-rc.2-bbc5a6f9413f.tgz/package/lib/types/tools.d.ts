/**
 * Three shared tools adapt model arguments to scoped resource operations.
 *
 * @module @deepseek-ai/dsh-mcp-resources
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ToolExecution } from '@deepseek-ai/dsh-tools';
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import type { McpResourceRequest } from './index.ts';
type RequestResource = (server: string, request: McpResourceRequest, exec: ToolExecution) => Promise<JsonValue>;
type ListResources = (server: string | undefined, exec: ToolExecution) => Promise<JsonValue[]>;
/** Canonical shared MCP resource tool names, in prompt order. */
export declare const MCP_RESOURCE_TOOL_NAMES: readonly ["list_mcp_resources", "list_mcp_resource_templates", "read_mcp_resource"];
/** A shared resource operation that a scoped server registration may expose. */
export type McpResourceToolName = typeof MCP_RESOURCE_TOOL_NAMES[number];
/**
 * Register resource operations in the consumer's tool scope.
 * @param ctx - context owning the tool registrations.
 * @param request - caller-aware resource operation.
 * @param list - caller-aware discovery across selected servers.
 * @param names - selected canonical operations; omission exposes all three.
 * @returns the effect disposer that removes the selected tools synchronously.
 */
export declare function registerResourceTools(ctx: Context, request: RequestResource, list: ListResources, names?: readonly McpResourceToolName[]): () => void;
export {};
//# sourceMappingURL=tools.d.ts.map