/**
 * Model-facing discovery projects resource records with server attribution and excludes MCP Apps UI documents.
 *
 * @module @deepseek-ai/dsh-mcp-resources
 */
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
/**
 * Resolve the CLI's tool-safe server spelling without changing exact-name precedence.
 * @param name - configured or requested server name.
 * @returns case-preserving normalized spelling.
 */
export declare function normalizedServerName(name: string): string;
/**
 * Project a provider's resource listing for model discovery; direct reads remain available.
 * @param value - protocol JSON returned by the provider.
 * @param server - authoritative configured server name.
 * @returns visible resource records with server attribution.
 * @throws when a provider returns a malformed listing or resource record.
 */
export declare function discoverableResources(value: JsonValue, server: string): JsonValue[];
//# sourceMappingURL=discovery.d.ts.map