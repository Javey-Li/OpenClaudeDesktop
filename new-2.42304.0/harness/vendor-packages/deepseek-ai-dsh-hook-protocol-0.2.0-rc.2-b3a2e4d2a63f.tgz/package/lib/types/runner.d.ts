/**
 * Execute command hooks through `ctx.shell`, using its credential scrub,
 * process-group cancellation, and timeout machinery. The bridge supplies the
 * trusted stdin payload and dialect environment, then this module decodes the
 * captured outcome.
 * @module @deepseek-ai/dsh-hook-protocol/runner
 */
import type { ShellExecRequest, ShellExecutor } from '@deepseek-ai/dsh-shell';
import type { CommandHook, HookOutput } from './types.ts';
/**
 * General command-hook timeout in ms (10 minutes). Bridges supply any
 * event-specific default, such as Claude Code's 30-second UserPromptSubmit
 * deadline. A per-hook {@link CommandHook.timeoutSec} overrides either value.
 */
export declare const DEFAULT_HOOK_TIMEOUT_MS = 600000;
/** Everything a single hook invocation needs beyond its command line. */
export interface RunHookOptions {
    /** The JSON payload object written to the hook's stdin (the bridge builds it). */
    payload: unknown;
    /** Extra env vars for the hook process (`CLAUDE_PROJECT_DIR`, …); the bridge builds these. */
    env?: Record<string, string>;
    /** Working directory for the hook (defaults to the executor's own default when omitted). */
    cwd?: string;
    /** Caller-authorized execution policy; omission retains the executor's deployment policy. */
    sandboxPolicy?: ShellExecRequest['sandboxPolicy'];
    /** Explicit owning-operation signal; firing it cancels the hook run. */
    readonly signal: AbortSignal;
    /** Whether to append a trailing newline to the stdin payload (CC yes, Codex no). */
    trailingNewline: boolean;
    /**
     * Timeout applied when the hook's config sets no `timeout` of its own. The
     * bridge owns the default (its `defaultTimeoutMs` config, reference default
     * {@link DEFAULT_HOOK_TIMEOUT_MS}) and passes it in explicitly.
     */
    defaultTimeoutMs: number;
    /**
     * The event this hook is firing for (e.g. `'PreToolUse'`). When set, a
     * structured `hookSpecificOutput` block whose `hookEventName` names a DIFFERENT
     * event is treated as malformed and its event-scoped fields are discarded (see
     * {@link parseHookOutput}). Omit it to apply any block as-is.
     */
    expectedEventName?: string;
}
/** The {@link HookOutput} plus the wall-clock duration of the run (for `hook/result`). */
export interface RunHookResult {
    output: HookOutput;
    /** Wall-clock duration of the run, from `now` — durable on the `hook/result` event. */
    durationMs: number;
}
/**
 * Run `hook` with serialized stdin and decode its outcome. A hook-specific
 * timeout in seconds overrides the default; trusted environment entries merge
 * after the executor scrub. Infrastructure rejection becomes an outcome with
 * no exit code. Cancelled or timed-out processes also produce no actionable
 * exit code, including a signal handler that exits with zero after termination.
 * @param bash - The executor service the command runs through.
 * @param hook - the configured command; its `timeoutSec` (wire unit: seconds) overrides the default timeout.
 * @param options - the invocation's payload, env, cwd, signal, stdin framing, and default timeout.
 * @param now - millisecond clock used for the reported duration.
 * @returns the decoded output plus the run's wall-clock duration.
 */
export declare function runHook(bash: Pick<ShellExecutor, 'resolve' | 'execute'>, hook: CommandHook, options: RunHookOptions, now: () => number): Promise<RunHookResult>;
//# sourceMappingURL=runner.d.ts.map