/** Load the grammar before tool publication and return a synchronous exit classifier.
 * @returns a classifier whose true result marks a completed command as a tool failure.
 */
export declare function prepareExitCodeClassifier(): Promise<(command: string, exitCode: number) => boolean>;
//# sourceMappingURL=exit-code.d.ts.map