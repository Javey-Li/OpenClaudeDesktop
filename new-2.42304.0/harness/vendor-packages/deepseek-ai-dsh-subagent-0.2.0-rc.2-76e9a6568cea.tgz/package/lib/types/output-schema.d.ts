/** Full object-rooted JSON Schema validation for delegated structured results. */
import { type ValidateFunction } from 'ajv';
import type { StructuredOutputSchema } from './types.ts';
/** Compile a detached schema without coercing output, fetching references, or enforcing formats.
 * @param value - untrusted schema at a workflow or subagent boundary.
 * @returns the compiled synchronous validator; invalid schemas throw JsonSchemaError.
 */
export declare function compileStructuredOutputSchema(value: unknown): ValidateFunction;
/** Assert a full structured-output schema before publishing a child.
 * @param value - schema received across a caller boundary.
 * @returns Narrows a usable object-rooted schema; rejects unsupported or contradictory schemas.
 */
export declare function assertStructuredOutputSchema(value: unknown): asserts value is StructuredOutputSchema;
//# sourceMappingURL=output-schema.d.ts.map