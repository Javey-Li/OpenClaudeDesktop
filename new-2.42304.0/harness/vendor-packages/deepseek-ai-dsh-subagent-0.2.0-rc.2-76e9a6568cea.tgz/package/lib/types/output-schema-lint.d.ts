/** Check local contradictions after Ajv accepts the schema's syntax.
 * References and combinator branches are deliberately left to Ajv, matching
 * the CLI's bounded property/item lint rather than attempting general SAT.
 * @param root - a detached, syntactically valid JSON Schema object.
 */
export declare function assertUsableOutputSchema(root: Record<string, unknown>): void;
//# sourceMappingURL=output-schema-lint.d.ts.map