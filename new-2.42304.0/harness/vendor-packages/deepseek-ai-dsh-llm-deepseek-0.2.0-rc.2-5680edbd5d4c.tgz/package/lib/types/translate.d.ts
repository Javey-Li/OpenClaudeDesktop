/** Translate Messages events while preserving block order and cumulative usage. */
import type { ReplayEnvelope, StreamChunk } from '@deepseek-ai/dsh-llm';
/** Decode a required string from provider JSON.
 * @param value - provider field.
 * @returns the validated string.
 */
export declare function string(value: unknown): string;
/** Translate decoded SSE data into the Harness stream protocol.
 * @param events - framed, decoded provider events in arrival order.
 * @param model - requested model id stored in durable replay state.
 * @param onReplayState - snapshots for the owning adapter to retain on failed streaming settlement.
 * @returns blocks, one final usage value, and exactly one terminal finish.
 */
export declare function translate(events: AsyncIterable<Record<string, unknown>> | Iterable<Record<string, unknown>>, model: string, onReplayState?: (state: ReplayEnvelope) => void): AsyncGenerator<StreamChunk>;
/**
 * Validate a complete Messages response before exposing any executable tool blocks.
 * @param value - decoded non-streaming JSON response.
 * @param model - request model used for native replay metadata.
 * @returns the same block, usage and signature vocabulary as streamed responses.
 */
export declare function translateComplete(value: unknown, model: string): AsyncGenerator<StreamChunk>;
//# sourceMappingURL=translate.d.ts.map