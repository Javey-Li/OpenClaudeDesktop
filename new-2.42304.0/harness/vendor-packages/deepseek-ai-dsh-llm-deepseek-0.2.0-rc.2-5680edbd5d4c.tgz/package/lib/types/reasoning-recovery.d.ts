/** Provider error classification and exact request-to-history reasoning coordinates. */
import type { LlmFailure, RequestMessage } from '@deepseek-ai/dsh-llm';
import type { WireRequest } from './wire-types.ts';
/**
 * Select a reasoning-recovery decision for a rejected request, without changing history.
 * @param failure - normalized HTTP failure.
 * @param headers - provider coordinates for a prefix mismatch.
 * @param body - exact serialized request that was rejected.
 * @param history - immutable history used to build that request.
 * @returns a whole-history or unique suffix decision; absent when no repair is possible.
 */
export declare function reasoningRecovery(failure: LlmFailure, headers: Headers, body: WireRequest, history: readonly RequestMessage[]): LlmFailure['reasoningRecovery'];
//# sourceMappingURL=reasoning-recovery.d.ts.map