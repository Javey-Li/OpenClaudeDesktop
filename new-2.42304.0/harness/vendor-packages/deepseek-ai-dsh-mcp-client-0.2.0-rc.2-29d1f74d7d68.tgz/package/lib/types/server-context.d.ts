/**
 * Publish connection-owned MCP resources and literal server instructions.
 *
 * @module @deepseek-ai/dsh-mcp-client
 */
import type { Context } from '@deepseek-ai/cordis';
import type { McpResourceProvider, McpResourceToolName } from '@deepseek-ai/dsh-mcp-resources';
/** Find a configured server visible from one caller scope.
 * @param ctx - Source context whose scope chain selects the server.
 * @param server - Configured server namespace.
 * @returns Borrowed connection context, including servers that expose no tools; never transfers ownership.
 */
export declare function getMcpServerContext(ctx: Context, server: string): ServerContext | undefined;
/** Borrow a server's visible tools and context into a child without closing its connection.
 * @param ctx - Receiving effect scope; disposal removes only borrowed registrations.
 * @param source - Existing server's viewing scope; its visibility remains authoritative.
 * @param server - Existing server namespace.
 * @param acceptTool - Persistent admission for borrowed public names.
 * @param resourceTools - Requested resource operations, intersected with source visibility and server admission.
 * @returns Whether the server was available; tool-list changes follow the source until disposal.
 */
export declare function inheritMcpServer(ctx: Context, source: Context, server: string, acceptTool: (name: string) => boolean, resourceTools?: readonly McpResourceToolName[]): boolean;
/** Connection-owned values used by the resource and prompt consumers. */
export interface ServerContext {
    /** Resource access through the current connection generation. */
    resources: McpResourceProvider;
    /** Permitted shared resource operations; omission admits all operations. */
    resourceTools?: readonly McpResourceToolName[];
    /**
     * Read the last successfully connected server's attributed instructions.
     * @returns literal prompt text, or an empty string when no server instructions are active.
     */
    instructions(): string;
}
/**
 * Contribute server context to the services enabled by this composition.
 * @param ctx - server plugin's registration scope and effect owner.
 * @param server - configured server identity.
 * @param connection - live resource operations and successful instruction snapshot.
 */
export declare function registerServerContext(ctx: Context, server: string, connection: ServerContext): void;
//# sourceMappingURL=server-context.d.ts.map