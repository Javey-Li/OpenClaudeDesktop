/** Commit provider-requested reasoning omission before admitting a replacement request. */
import type { LlmFailure, RequestMessage } from '@deepseek-ai/dsh-llm';
import type { Session } from '@deepseek-ai/dsh-session';
/**
 * Apply a whole-history repair, or at most two targeted repairs per failed request chain.
 * @param session - authoritative session whose current messages formed the request.
 * @param messages - rejected request history, in model-visible order.
 * @param failure - provider-classified recovery coordinates.
 * @param attempts - reasoning repairs already made for this step and route.
 * @returns whether an omission was committed and retry can make progress.
 */
export declare function recoverReasoning(session: Session, messages: readonly RequestMessage[], failure: LlmFailure, attempts: number): boolean;
//# sourceMappingURL=reasoning-recovery.d.ts.map