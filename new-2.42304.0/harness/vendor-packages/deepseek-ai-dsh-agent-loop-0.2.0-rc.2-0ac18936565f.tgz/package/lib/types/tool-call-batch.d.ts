/** Complete, durably advertised calls arriving during one assistant response. */
import type { ToolCallBlock } from '@deepseek-ai/dsh-llm';
/** One producer feeds calls; the scheduler drains them after closure or cancellation. */
export declare class ToolCallBatch {
    private readonly calls;
    private ended;
    private change;
    /** Number of complete calls received so far. */
    get length(): number;
    /** Whether no more calls may arrive. */
    get closed(): boolean;
    /** Resolves on the next addition or closure; read before inspecting current state. */
    get changed(): Promise<void>;
    /**
     * Snapshot a complete call after its assistant message has committed.
     * @param block - the model-authored call, without input preparation rewrites.
     * @throws if the response has closed, including scheduler cancellation.
     */
    add(block: ToolCallBlock): void;
    /** Stop accepting calls and wake a scheduler waiting for input. Idempotent. */
    close(): void;
    /**
     * Read a received call by its model-order position.
     * @param index - zero-based position.
     * @returns the call, or undefined when it has not arrived.
     */
    at(index: number): ToolCallBlock | undefined;
    private notify;
}
//# sourceMappingURL=tool-call-batch.d.ts.map