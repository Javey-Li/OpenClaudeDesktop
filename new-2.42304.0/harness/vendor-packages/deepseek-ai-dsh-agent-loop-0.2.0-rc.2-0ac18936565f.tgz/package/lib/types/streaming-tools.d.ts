/** Request-owned streaming tool dispatch and durable response settlement. */
import type { Context } from '@deepseek-ai/cordis';
import type { GenerateOptions, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { Session, UserMessage } from '@deepseek-ai/dsh-session';
import type { AssistantStreamAttempt } from './assistant-stream.ts';
/** One request owns the input queue, its cancellation, and the scheduler drain. */
export declare class StreamingTools {
    private readonly session;
    private readonly live;
    private readonly request;
    private readonly batch;
    private readonly abort;
    private readonly advertised;
    private readonly order;
    private readonly closed;
    private hasText;
    private readonly startSeq;
    private readonly result;
    readonly signal: AbortSignal;
    constructor(context: Context, session: Session, live: AssistantStreamAttempt, request: GenerateOptions, signal: AbortSignal, onContext: (message: UserMessage) => void, transport?: 'non-streaming');
    get count(): number;
    /** Dispatch only the completed prefix, preserving model order across barriers. */
    push(chunk: StreamChunk): void;
    private advertise;
    /** Stop the request and its started tools after a thrown provider/middleware failure. */
    fail(error: unknown): void;
    /** Record the text-only recovery instruction after the driver commits to retrying. */
    recordRetry(): void;
    /** Drain every started call, then commit the full stream and its history reconstruction. */
    settle(): Promise<{
        concluded: boolean;
        generationBeforeMerge: number;
        generationAfterMerge: number;
    }>;
}
//# sourceMappingURL=streaming-tools.d.ts.map