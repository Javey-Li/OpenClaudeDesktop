/**
 * Schedules one assistant step's tool calls. Exclusive calls form barriers;
 * parallel calls use a bounded rolling pool and are reclassified before start.
 * Policy preparation follows model order. Streaming batches publish completed
 * tool pipelines in completion order; buffered steps finalize in model order.
 * Abort or an internal scheduler failure stops replenishment and drains started calls.
 *
 * Abort records synthetic error results for skipped calls so replay stays
 * valid. A terminal scheduler failure rejects after draining; the owning step
 * records conservative recovery results before closing.
 * @module dsh-agent-loop/tool-calls
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ToolCallBlock } from '@deepseek-ai/dsh-llm';
import type { UserMessage } from '@deepseek-ai/dsh-session';
import { ToolCallBatch } from './tool-call-batch.ts';
/**
 * Schedule one assistant step's tool calls by their live concurrency mode.
 * Streaming batches commit finalized results in completion order; buffered
 * steps finalize and commit in model order. Abort
 * drains them, records synthetic results for unstarted calls, and returns with
 * the signal still aborted after accepting started-call context through the
 * caller-supplied acceptor (the machine stages it in its next-step inbox for the
 * step boundary). An internal scheduler failure stops new dispatches, drains
 * already-started dispatches, and rejects with the first failure. The owning
 * step supplies error results for requests without a committed outcome.
 * The committed step's AgentLoop driver boundary supplies the initiating Agent
 * that becomes each explicit {@link ToolExecutionInput.agent}.
 *
 * @param ctx - loop context that owns the tool registry and carries the initiating Agent.
 * @param turn - current turn number.
 * @param step - current step number.
 * @param toolCalls - complete advertised calls in model order, or their still-open response batch.
 * @param signal - abort signal shared by the step.
 * @param acceptContext - accepts committed result context for the next step boundary.
 */
export declare function executeToolCalls(ctx: Context, turn: number, step: number, toolCalls: ToolCallBlock[] | ToolCallBatch, signal: AbortSignal, acceptContext: (context: UserMessage) => void): Promise<{
    concluded: boolean;
}>;
//# sourceMappingURL=tool-calls.d.ts.map