---
description: "在 agent 运行期间使用你现有的 Claude Code hooks.json 或 settings 钩子配置——阻塞提示词与工具、附加上下文或强制继续——供本桥接的用户与维护者阅读。"
kind: "package-reference"
---

# @deepseek-ai/dsh-hooks-claude-code

[English](README.md) | 中文

## 概述

`dsh-hooks-claude-code` 在 agent（智能体）运行期间执行你现有 Claude Code `hooks.json` 或 settings 文件中的 command 与 HTTP 钩子，无需重写。受支持的钩子会在会话、提示词、工具、停止或 subagent 到达对应时刻时运行。它们可以带模型可见的原因阻塞提示词或工具调用、添加对话上下文、停止当前活动，或强制模型再执行一个轮次。需要在 harness 中复用 Claude Code command 与 HTTP 钩子时选择本包；没有 Claude Code 对应物的行为应使用原生插件。

## 目录

- [使用本包](#use-this-package)
- [理解实现](#understand-the-implementation)
- [进一步探索](#further-exploration)
- [模型体验](#model-experience)
- [已知限制与延期工作](#known-limitations-and-deferred-work)
- [开发备注](#dev-note)

-----

<a id="use-this-package"></a>
## 使用本包

挂载本包并把 `configPath` 指向你的钩子配置，你已有的钩子就会在 agent 运行中的对应时刻开始触发。在第一个钩子生效之前无需其他设置。

### 何时选择

当你持有 Claude Code `hooks.json`（或 `hooks` key 存放配置的 settings 文件）、且其中受支持的钩子需要把关提示词、工具与轮次时，使用它。没有 Claude Code 对应物的行为请跳过它：原生插件拥有完整的 harness API，而本桥接只运行已记录的事件与处理器子集。

### 最小配置

```yaml
- name: '@deepseek-ai/dsh-hooks-claude-code'
  config:
    configPath: ./.claude/hooks.json
    pluginRoot: ./.claude/plugins/my-plugin
    projectDir: .
```

| 字段 | 默认值 | 含义 |
|---|---|---|
| `configPath` | 必填 | `hooks.json` 或 `hooks` key 存放配置的 settings 文件路径 |
| `pluginRoot` | — | 替换命令字符串中的 `${CLAUDE_PLUGIN_ROOT}` |
| `projectDir` | 会话工作区 | 替换 `${CLAUDE_PROJECT_DIR}` 并设置 `CLAUDE_PROJECT_DIR` 环境变量 |
| `defaultTimeoutMs` | 按事件确定 | 以毫秒覆盖默认值；未设置时 `UserPromptSubmit` 为 `30,000`，其他已支持事件为 `600,000`。处理器的秒单位 `timeout` 优先。 |
| `allowedHttpHookUrls` | 未设置 | 宿主 URL 通配白名单；`[]` 阻止所有 HTTP hook，包括本地代理处理器。多个桥接实例的限制取交集。 |
| `httpHookAllowedEnvVars` | 未设置 | 宿主请求头变量白名单，与每个处理器的 `allowedEnvVars` 取交集；`[]` 不允许任何变量。 |
| `stderrSummaryMaxChars` | `500` | 持久化 `hook/result` stderr 摘要的字符上限 |

生成的[配置目录](../../../docs/config-catalog.zh.md#deepseek-aidsh-hooks-claude-code)是每个受支持字段的穷尽式真源。

### 你的钩子能做什么

| 你的钩子 | 运行时机 | 能做什么 |
|---|---|---|
| `SessionStart` | 会话开始时 | 附加该会话中模型可见的上下文 |
| `UserPromptSubmit` | agent 收到提示词时 | 阻塞提示词、停止活动，或附加上下文 |
| `PreToolUse` | 工具运行前 | 阻塞工具、请求批准或附加上下文 |
| `PostToolUse` | 工具成功后 | 带反馈阻塞结果，或附加上下文 |
| `PostToolUseFailure` | 已调度工具失败后 | 附加失败上下文或反馈 |
| `Stop` | 运行即将停止时 | 带原因强制再执行一步 |
| `SubagentStart` | subagent 启动时 | 向仍在运行的 subagent 附加上下文（仅限同进程） |
| `SubagentStop` | subagent 结束时 | 只观测——不能阻塞或添加上下文 |

### HTTP 处理器

`type: "http"` 的处理器将事件 payload 作为 JSON POST 到 `url`。可选的 `headers`、`allowedEnvVars` 与 `timeout` 配置请求。仅包含有效 hook JSON 的 2xx 响应可改变执行；空响应视为 `{}`。HTTP 状态码不采用 shell 退出码规则。纯文本、格式错误的 JSON、非 2xx、重定向、连接错误和超时均产生非阻塞诊断。请求不跟随重定向；取消覆盖响应体读取，并丢弃迟到决策。`async: true` 响应信封不会产生同步控制效果。

请求头仅展开处理器允许、且所有已配置宿主变量白名单都允许的大写 `$VAR` 与 `${VAR}`。已知普通凭据变量还需要宿主显式授权；CLI 内部凭据名始终不展开。缺失或未允许的变量替换为空文本，并移除 CR、LF 和 NUL。直连拒绝 CLI 的私有及链路本地地址范围，包括混合公网／私网 DNS 答案；仍允许 loopback。代理请求使用已安装的宿主代理策略，将目标解析交给代理。宿主白名单应配置在桥接上，不能由未信任代理 frontmatter 授权。

<a id="local-agent-definitions"></a>
### 本地代理定义

`installClaudeAgentHooks` 直接把已解析 frontmatter 挂载到尚未发布的子代理作用域。spawn 提供方在发布前验证本地定义、跳过未信任项目的 hooks，并忽略插件代理的 hooks。用户代理 hooks 受信任；项目代理 hooks 要求执行环境的 `~/.claude.json` 中存在 `projects[精确项目目录].hasTrustDialogAccepted: true`。祖先目录的信任不能授予该权限。本地事件映射、matcher、超时值无效或处理器类型不支持时，代理初始化失败。参见 [spawn 提供方](../../subagent/subagent-spawn-in-process/README.zh.md)。

本地 `PreToolUse`、`PostToolUse`、`PostToolUseFailure` 仅作用于该子代理。本地 `Stop` 转换为 `SubagentStop`，以声明的代理名匹配，并可要求子代理再执行一步，或通过 `continue: false` 停止它。同一轮次被 hook 强制继续后，`stop_hook_active` 为 true；`last_assistant_message` 包含最新助手文本。处理器 effect、活动命令和 HTTP 请求随子代理一起释放。只有文件配置会安装会话、提示词及子代理生命周期观察器。

`continue: false` 会停止当前提示处理、工具序列或即将结束的轮次，优先于阻塞反馈或强制继续。工具前停止会阻止执行；工具后停止先保留最终工具结果，再取消后续工作。`stopReason` 作为 hook 取消原因记录，缺失或为空时使用 `Execution stopped by hook`。停止不会延续到之后的用户轮次。`SessionStart` 与分离运行的生命周期观察器不会停止运行。

`PreToolUse.updatedInput` 按可见工具 schema 校验，在审计日志、并发分类、审批和执行守卫之前应用。无效输入会拒绝分发，并忽略该次 hook 输出的其余字段。deny/block 输出不应用替换。额外键的校验错误按 CLI 校验器行为忽略；普通工具校验仍然执行。助手原始调用保持不变，持久更正携带原始与接纳的 JSON。`allow` 委托普通策略，`ask` 申请对接纳参数的审批。其他事件不改写输入。

### 钩子如何运行与失败

`SessionStart` 与 `UserPromptSubmit` 成功退出、且不以 `{` 开头的 stdout 会去除首尾空白，以 `<system-reminder>\n<Event[:matcher]> hook success: <text>\n</system-reminder>` 格式成为已记录的模型上下文。其他事件需使用结构化 `additionalContext`。空输出、失败、取消或超时输出不会添加纯文本上下文；取消与超时也会丢弃控制字段，即使信号处理器以零退出。

- 命令钩子在你的项目目录（agent 的会话工作区）中运行，因此钩子里的 `pwd` 与相对路径指向你的项目，而非服务器启动目录。
- 已配置的命令钩子作为受信任宿主代码，在代理的文件沙箱之外运行，包括代理处于只读模式时。Shell 仍执行凭据清理、取消与超时。仅注册受信任命令；本地代理定义的信任检查仍然适用。
- 命令字符串中的 `${CLAUDE_PLUGIN_ROOT}` 与 `${CLAUDE_PROJECT_DIR}` 会按你的配置替换，且每个钩子进程都会设置 `CLAUDE_PROJECT_DIR`。
- 一份配置应用于整个进程：启动时只读取一次，相对 `configPath` 从启动进程的目录解析。
- 同一事件上的钩子按配置顺序逐个运行。
- 如果配置无法读取或解析，桥接会记录警告且不运行任何钩子——agent 仍会启动。
- 运行失败的钩子（命令错误或崩溃）会被记录，agent 继续运行。

-----

<a id="understand-the-implementation"></a>
## 理解实现

<details>
<summary>实现细节——点击展开</summary>

本节解释桥接背后的设计决策，并指出实现它们的代码位置；可观察行为已在[使用本包](#use-this-package)中完整说明。

### Hook 点映射

每个受支持事件都面向一个 harness 扩展点：`SessionStart` 在首个轮次前通过需等待的 `agent/created` 初始化加入上下文，`UserPromptSubmit` 使用 `agent/pre-step`；`PreToolUse` 在串行 `tools/prepare-input` 中运行一次，在 `tools/pre-execute` 中执行同次调用的决策，`PostToolUse` 与 `PostToolUseFailure` 使用能带反馈阻塞或向下游决策添加上下文的 waterfall（`tools/post-execute`），`Stop` 是串行监听器，其阻塞结果通过 `steer()` 强制再执行一步（`agent/turn-stopping`）。两个 subagent 事件面向 child 生命周期发射（`subagent/start`、`subagent/end`）：start 向仍在运行的同进程 child 注入上下文，stop 只观测。提示词及工具后上下文先通过 `next()` 委托再加入下游决策；工具前上下文在决策前注入。后续监听器仍可拒绝或改写。阻塞决策映射为 `deny`，工具前审批请求映射为 `ask`。工具后 hooks 仅对已调度的工具主体运行，因此工具前拒绝不会触发它们。逐事件接线位于 [`src/index.ts`](src/index.ts)。

### 载荷与环境

桥接从 `session_id`、字符串形态的 `transcript_path`、`cwd` 与 `hook_event_name` 的基础字段加逐事件字段构建每个事件的 payload，以命令 stdin 或 HTTP JSON 发送。`transcript_path` 出于兼容性保留在 payload 中，但始终为 `''`：持久化 seam 不暴露产物路径，且默认使用 Zstandard 压缩的会话日志无法被 hook 脚本读取。省略 `projectDir` 时，`CLAUDE_PROJECT_DIR` 按次默认到会话工作区，与钩子运行的目录一致；`${CLAUDE_PLUGIN_ROOT}` 与 `${CLAUDE_PROJECT_DIR}` 替换在配置解析时进行。

### Matcher subject 与串行执行

工具 matcher 同时接受 Harness 名称及 Claude 别名（`PreToolUse`／`PostToolUse`／`PostToolUseFailure`），payload 使用 Claude 别名。其余 matcher subject 是会话源（`SessionStart`），或常量 `agent_type` `general-purpose`（`SubagentStart`／`SubagentStop`——subagent seam 不携带每 kind 标签）；`UserPromptSubmit` 与 `Stop` 忽略 matcher。匹配 hook 按配置顺序串行运行，独立工具调用可重叠运行；事件对通过 `handlerId` 关联，且最严格折叠与顺序无关（`deny > ask > allow`）。

### 脱离运行与释放

文件配置的 `SubagentStart` 与 `SubagentStop` 脱离运行；`SessionStart` 会被跟踪以便清理，并在首个轮次前等待完成。每条运行链都会被跟踪，对桥接执行 dispose（资源释放）时会中止仍在运行的 hook 进程及 HTTP 请求，并在 dispose 完成前排空 continuation（`createDetachedRuns`，位于 `dsh-hook-protocol`）。

### 设计理念

- **兼容适配器，而非强力工具。** 桥接的存在意义是运行现有 Claude Code 配置中显式受支持的 command 与 HTTP 子集；定制行为应放在同一批扩展点上的原生插件中。
- **添加上下文不是否决。** 仅提供上下文的 hook 会先通过 `next()` 委托，再把其消息折叠进下游 enter 决策，因此后续 `agent/pre-step` 或 `tools/post-execute` 监听器仍可拒绝或改写。
- **每个失败点都受控。** 配置读取／解析失败与无效 matcher 不注册任何内容；抛异常的脱离注入会被捕获并记录，而不是破坏会话启动或循环。
- **dispose 必须达到完全停稳。** 脱离运行会被跟踪并在释放时排空，因此不会有 hook 进程或迟到回调超出 fiber 存活。
- **同次调用的 hooks 按配置顺序运行。** 独立调用可重叠。事件交错时，handler ID 保持 invocation/result 配对。决策折叠与顺序无关；命令副作用与耗时仍可能不同于并发运行同级处理器的引擎。

[hook-bridges Agent Note](../../../.agents/notes/archived/feature/2026-06-30-hook-bridges.md) 记录了桥接设计与延期缺口；[hook-protocol-lib Agent Note](../../../.agents/notes/archived/feature/2026-06-30-hook-protocol-lib.md) 记录了共享与逐方言的划分。

### 源码地图

| 文件 | 职责 |
|---|---|
| [`src/index.ts`](src/index.ts) | 插件入口：配置校验、监听器注册、逐事件 payload、决策映射 |
| [`src/config.ts`](src/config.ts) | Claude Code 配置解析：受支持事件、matcher 校验、命令替换 |
| — | 不发布运行时不变式伴生入口；本桥接发布 hook-protocol 会话事件，既有 companion 负责校验每个结果所引用的调用事件。 |

</details>

-----

<a id="further-exploration"></a>
## 进一步探索

当包级约定不够用时阅读以下页面。它们从共享协议进入桥接设计，以及桥接所面向的扩展点。

- [hooks 组地图](../README.zh.md)——同级组页面及其包表。
- [hook 协议库](../hook-protocol/README.zh.md)——本桥接应用的共享钩子规则。
- [钩子桥接 Agent Note](../../../.agents/notes/archived/feature/2026-06-30-hook-bridges.md)——桥接设计、决策映射与延期缺口。
- [拦截扩展点 Agent Note](../../../.agents/notes/implemented/feature/2026-06-30-interception-extension-points.zh.md)——桥接所映射的类型化 Decision 接口面。
- [生成的配置目录](../../../docs/config-catalog.zh.md#deepseek-aidsh-hooks-claude-code)——每个受支持配置字段及其源声明。

-----

<a id="model-experience"></a>
## 模型体验

### Hook 提供的上下文

#### 模型看到什么

`SessionStart`、已接受提示词、工具前、工具后与实时同进程 subagent-start hook 可以添加带源归因的上下文消息；阻塞 `Stop` hook 将原因添加为下一步 steering（中途引导）。远程 child 注入没有本地目标。

#### Token 影响

hook 不返回上下文时没有成本。Hook 文本取决于数据，会被记录，并在后续会话请求中重发，直到压缩（compaction）。

#### KV Cache 影响

仅追加；新可见内容位于可复用请求前缀之后，不会使现有 KV Cache 条目失效。

### 已阻塞提示词或工具结果

#### 模型看到什么

提供方提供的原因逐字传递。缺失原因时，已拒绝工具变为 `Error: blocked by PreToolUse hook`，已阻塞工具后反馈精确为 `blocked by PostToolUse hook`，阻塞 stop 则精确添加 steering `continue: blocked by Stop hook`（本地代理 stop 为 `continue: blocked by SubagentStop hook`）；已阻塞提示词不会产生任何模型可见消息，而是以 `blocked` 结束该轮次。`systemMessage` 会被记录或警告，但对模型不可见。接纳的输入改写会向下一次请求追加带来源的更正，包含原始与接纳的 JSON。

#### Token 影响

阻塞提示词不会产生该提示词对应的模型请求 token；拒绝或反馈会添加保留的回退或提供方文本；强制 continuation 需要另一个完整请求。

#### KV Cache 影响

已阻塞提示词不发送请求，不会导致失效。拒绝、反馈与强制 continuation 上下文会追加在可复用前缀之后，不改写前缀。

## 已知限制与延期工作

<a id="known-limitations-and-deferred-work"></a>


这些限制描述你的 Claude Code 钩子目前还无法通过本桥接做到的事情，以及行为与参考工具的差异。它们是当前包约束，而非任务积压。

- **不支持的 hook 事件**——`Setup`、`InstructionsLoaded`、`UserPromptExpansion`、`MessageDisplay`、`PermissionRequest`、`PostToolBatch`、`PermissionDenied`、`Notification`、`TaskCreated`、`TaskCompleted`、`StopFailure`、`TeammateIdle`、`ConfigChange`、`CwdChanged`、`FileChanged`、`WorktreeCreate`、`WorktreeRemove`、`PreCompact`、`PostCompact`、`SessionEnd`、`Elicitation` 与 `ElicitationResult`。文件配置在配置组解析前忽略这些事件；本地代理 frontmatter 会拒绝它们。比较基线是 Claude Code [官方 hook 事件参考](https://code.claude.com/docs/en/hooks#hook-events)。
- **`SessionStart` 只支持部分功能**——会消费 JSON `additionalContext` 与成功退出的纯 stdout，但不支持 `initialUserMessage`、`sessionTitle`、`watchPaths`、`reloadSkills` 与 `CLAUDE_ENV_FILE`。初始化会在首个请求前等待 hook 完成；payload 会省略 `model`、`agent_type` 与 `session_title` 等可选字段。
- **`UserPromptSubmit` 只支持部分功能**——支持阻塞、JSON `additionalContext` 与成功退出的纯 stdout，但不支持 `sessionTitle` 与 `suppressOriginalPrompt`。
- **`PostToolUse` 只支持部分功能**——支持阻塞反馈与 JSON `additionalContext`，但不支持 `updatedToolOutput` 与 `updatedMCPToolOutput`，`tool_response` 会展平为文本。
- **文件配置的 `SubagentStart` 与 `SubagentStop` 只支持部分功能**——两者均报告常量 `agent_type` `general-purpose`，并在 Claude Code 报告父会话的位置使用 child 会话 id。Start 上下文是尽力而为，且只能到达仍在运行的同进程 child；stop 只观测，无法阻塞 subagent 或向其提供上下文。Stop 省略 `agent_transcript_path`、`last_assistant_message`、`background_tasks` 与 `session_crons`，并始终报告 `stop_hook_active: false`。
- **`Stop` 只支持部分功能**——阻塞会强制再执行一个模型步骤；提供 `stop_hook_active` 与 `last_assistant_message`，但会省略 `background_tasks` 与 `session_crons`，且未实现连续阻塞上限。因此，无条件阻塞 hook 会在每个步骤中强制 continuation，除非它自我限制。
- **类似 JSON 的 stdout 处理仍不完整**——以 `{` 开头的输出保留给结构化解码器。Claude Code 可把不完整对象和特定多行 JSON 输出当作纯文本，桥接尚不支持；完整 schema 验证与原生输出溢出存储也未实现。
- **通用 payload 与输出字段只支持部分功能**——已映射事件会省略 Claude Code 原本会提供的 `prompt_id`、`permission_mode` 与 `effort`，且 `transcript_path` 永不填充：它始终为空字符串，因为持久化 seam 不暴露产物路径，且默认使用 Zstandard 压缩的会话日志无法被 hook 脚本读取。`systemMessage` 会被记录 + 警告但不呈现；`continue: false` 与 `stopReason` 只用于活动提示、工具和即将结束轮次的监听器；`suppressOutput` 与 `terminalSequence` 不会被应用。
- **HTTP 兼容仍不完整**——已实现静态凭据名称限制，但尚未实现动态凭据代理、账户／托管策略发现、含凭据的基础 URL 分类及原生远程／TLS 处理。HTTP 响应验证覆盖受支持事件的字段，但尚未实现完整 `PermissionRequest` 输出联合及 `defer` 行为。宿主限制需要显式桥接配置，不会从 Claude 设置读取。
- **Handler 与配置只支持部分功能**——运行 shell 形态 command 与 HTTP handler。文件配置会跳过 `mcp_tool`、`prompt` 与 `agent` handler，本地代理初始化则拒绝它们；`args`、`async`、`asyncRewake`、`shell`、`if`、`once` 与 `statusMessage` 等 command handler 选项不会被遵循。匹配 handler 串行运行且不去重，而 Claude Code 会并行运行并对相同 handler 去重。一个进程级 `configPath` 会在加载时解析一次；尚未实现 Claude Code 的分层项目、用户、插件与策略发现以及实时重新加载。

<a id="dev-note"></a>
### 开发备注

<details>
<summary>维护者的工作上下文——点击展开</summary>

本开发备注是维护者的工作上下文：开放问题与尚未决定的探索方向。它明确不具权威性——已交付的行为、限制与既定理由以上文、包代码和相关 Agent Note 为准。

上述延期缺口包括按会话发现 hook 配置、stop 循环防护和不支持的 hook 处理器类型。官方 Claude Code 参考是补齐这些能力的基线。

</details>
