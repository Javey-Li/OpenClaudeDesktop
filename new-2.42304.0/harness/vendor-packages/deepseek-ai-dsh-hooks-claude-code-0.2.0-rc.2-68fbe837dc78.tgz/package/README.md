---
description: "Run your existing Claude Code hooks.json or settings hook config during agent runs — block prompts and tools, attach context, or force continuation — for users and maintainers of the bridge."
kind: "package-reference"
---

# @deepseek-ai/dsh-hooks-claude-code

English | [中文](README.zh.md)

## Summary

`dsh-hooks-claude-code` runs command and HTTP hooks from your existing Claude Code `hooks.json` or settings file during agent runs, without requiring a rewrite. Supported hooks can run when sessions, prompts, tools, stops, or subagents reach matching moments. They can block prompts or tool calls with model-visible reasons, add conversation context, halt the current activity, or force another model turn. Choose this package to reuse Claude Code command and HTTP hooks in the harness; use a native plugin for behavior that has no Claude Code equivalent.

## Table of Contents

- [Use this package](#use-this-package)
- [Understand the implementation](#understand-the-implementation)
- [Further Exploration](#further-exploration)
- [Model Experience](#model-experience)
- [Known Limitations and Deferred Work](#known-limitations-and-deferred-work)
- [Dev Note](#dev-note)

-----

<a id="use-this-package"></a>
## Use this package

Mount this package, point `configPath` at your hook config, and the hooks you already have start firing at the corresponding moments in agent runs. There is nothing else to set up before the first hook works.

### When to choose it

Use it when you own a Claude Code `hooks.json` (or a settings file whose `hooks` key holds the config) and its supported hooks should gate prompts, tools, and turns. Skip it for behavior with no Claude Code equivalent: a native plugin has the full harness API, while this bridge runs only the documented event and handler subset.

### Smallest working setup

```yaml
- name: '@deepseek-ai/dsh-hooks-claude-code'
  config:
    configPath: ./.claude/hooks.json
    pluginRoot: ./.claude/plugins/my-plugin
    projectDir: .
```

| Field | Default | Meaning |
|---|---|---|
| `configPath` | required | Path to a `hooks.json` or a settings file whose `hooks` key holds the config |
| `pluginRoot` | — | Replaces `${CLAUDE_PLUGIN_ROOT}` in command strings |
| `projectDir` | session workspace | Replaces `${CLAUDE_PROJECT_DIR}` and sets the `CLAUDE_PROJECT_DIR` env var |
| `defaultTimeoutMs` | event-specific | Override in milliseconds; otherwise `UserPromptSubmit` uses `30,000` and other supported events use `600,000`. Per-handler `timeout` in seconds wins. |
| `allowedHttpHookUrls` | unset | Host URL wildcard allowlist; `[]` blocks every HTTP hook, including local-agent handlers. Multiple bridge instances intersect their restrictions. |
| `httpHookAllowedEnvVars` | unset | Host header-variable allowlist, intersected with each handler’s `allowedEnvVars`; `[]` permits none. |
| `stderrSummaryMaxChars` | `500` | Character cap on the persisted `hook/result` stderr summary |

The generated [configuration catalog](../../../docs/config-catalog.md#deepseek-aidsh-hooks-claude-code) is the exhaustive source for every accepted field.

### What your hooks can do

| Your hook | When it runs | What it can do |
|---|---|---|
| `SessionStart` | when a session starts | attach context the model sees in that session |
| `UserPromptSubmit` | when the agent receives a prompt | block the prompt, stop the activity, or attach extra context |
| `PreToolUse` | before a tool runs | block the tool, ask for approval, or attach context |
| `PostToolUse` | after a tool succeeds | block the result with feedback, or attach extra context |
| `PostToolUseFailure` | after a dispatched tool fails | attach failure context or feedback |
| `Stop` | when the run is about to stop | force another step with a reason |
| `SubagentStart` | when a subagent starts | attach context to a still-running subagent (in-process only) |
| `SubagentStop` | when a subagent ends | observe only — cannot block or add context |

### HTTP handlers

A handler with `type: "http"` posts the event payload as JSON to `url`. Optional `headers`, `allowedEnvVars` and `timeout` configure the request. Only a 2xx response with valid hook JSON can change execution; an empty response means `{}`. HTTP status codes never use shell exit-code rules. Plain response text, malformed JSON, non-2xx responses, redirects, connection errors and timeouts produce nonblocking diagnostics. Requests do not follow redirects; cancellation covers response-body reading and discards late decisions. An `async: true` response envelope has no synchronous control effect.

Headers expand uppercase `$VAR` and `${VAR}` only when the handler permits the name and every configured host variable allowlist permits it. Known ordinary credential variables additionally need explicit host approval; CLI-internal credential names remain withheld. Missing or disallowed variables become empty text, and CR, LF and NUL are removed. Direct connections reject the CLI’s private and link-local address ranges, including mixed public/private DNS answers; loopback remains allowed. Proxied requests use the installed host proxy policy and leave target resolution to that proxy. Configure host allowlists on the bridge, not in untrusted agent frontmatter.

### Local agent definitions

`installClaudeAgentHooks` mounts parsed frontmatter directly in an unpublished child's scope. The spawn provider validates local definitions before publication, skips untrusted project hooks, and ignores plugin-agent hooks. User-agent hooks are trusted; project-agent hooks require `projects[exactProjectDirectory].hasTrustDialogAccepted: true` in the execution world's `~/.claude.json`. Ancestor-directory trust does not grant this permission. Invalid local event maps, matchers, timeouts, or unsupported handler types reject agent setup. See the [spawn provider](../../subagent/subagent-spawn-in-process/README.md).

Local `PreToolUse`, `PostToolUse`, and `PostToolUseFailure` run only for the child. Local `Stop` entries become `SubagentStop`, match the declared agent name, and can force another child step or halt it with `continue: false`. `stop_hook_active` is true after a hook has forced continuation in the same turn; `last_assistant_message` carries the latest assistant text. Handler effects, active commands and HTTP requests end with the child. Session, prompt, and subagent lifecycle observers are only installed by file-based configuration.

`continue: false` halts the active prompt, tool sequence, or stopping turn and takes precedence over blocking feedback or forced continuation. A pre-tool stop prevents dispatch; a post-tool stop preserves the final tool result before cancelling further work. `stopReason` is recorded as the hook cancellation reason, defaulting to `Execution stopped by hook` when absent or empty. It does not arm a halt for later user turns. `SessionStart` and detached lifecycle observers do not halt runs.

`PreToolUse.updatedInput` is validated against the visible tool schema and applied before audit logging, concurrency classification, approval and execution guards. Invalid input denies dispatch and ignores the remaining fields of that hook output. A deny/block output does not apply its replacement. Extra-key validation errors are ignored, matching the CLI validator; ordinary tool validation still runs. The authored assistant call stays unchanged while a durable correction carries original and accepted JSON. `allow` delegates to normal policy; `ask` requests approval of accepted arguments. Other events do not rewrite input.

### How hooks run and fail

Successful `SessionStart` and `UserPromptSubmit` stdout that does not start with `{` becomes logged model context, trimmed and framed as `<system-reminder>\n<Event[:matcher]> hook success: <text>\n</system-reminder>`. Other events require structured `additionalContext`. Empty stdout and unsuccessful, cancelled, or timed-out output add no plain context; cancelled and timed-out runs discard control fields even when a signal handler exits zero.

- Command hooks run in your project directory — the agent's session workspace — so `pwd` and relative paths in your hooks refer to your project, not the server's launch directory.
- Configured command hooks run as trusted host code outside the agent's file sandbox, including when the agent is read-only. They retain shell credential scrubbing, cancellation and timeouts. Register only trusted commands; local-agent definition trust checks still apply.
- `${CLAUDE_PLUGIN_ROOT}` and `${CLAUDE_PROJECT_DIR}` in command strings are replaced from your config, and `CLAUDE_PROJECT_DIR` is set for every hook process.
- One config applies to the whole process: it is read once at startup, and a relative `configPath` resolves from the directory that launched the process.
- Hooks on the same event run one after another, in config order.
- If the config cannot be read or parsed, the bridge logs a warning and runs no hooks — the agent still starts.
- A hook that fails to run (a bad command or a crash) is logged, and the agent continues.

-----

<a id="understand-the-implementation"></a>
## Understand the implementation

<details>
<summary>Implementation internals — click to expand</summary>

This section explains the design decisions behind the bridge and points at the code that realizes them; the observable behavior is fully covered in [Use this package](#use-this-package).

### Hook point mapping

Each supported event programs against one harness extension point: `SessionStart` adds context through awaited `agent/created` initialization before the first turn, `UserPromptSubmit` uses `agent/pre-step`; `PreToolUse` runs once during serial `tools/prepare-input` and enforces its decision in `tools/pre-execute`, `PostToolUse` and `PostToolUseFailure` use a waterfall that can block with feedback or add context to the downstream decision (`tools/post-execute`), and `Stop` is a serial listener whose blocking result forces another step through `steer()` (`agent/turn-stopping`). The two subagent events emit into the child lifecycle (`subagent/start`, `subagent/end`): start injects context into a live in-process child, stop observes only. Prompt and post-tool context delegates via `next()` before joining the downstream decision; pre-tool context is injected before the decision. Later listeners may still reject or rewrite. Blocking decisions map to `deny`, or `ask` for a pre-tool approval request. Post-tool hooks run only for dispatched bodies, so pre-tool denial does not trigger them. The per-event wiring lives in [`src/index.ts`](src/index.ts).

### Payloads and environment

The bridge builds each event's payload, sent on command stdin or as HTTP JSON, from a base of `session_id`, string-shaped `transcript_path`, `cwd`, and `hook_event_name` plus per-event fields. `transcript_path` stays in the payload for compatibility but is always `''`: the persistence seam exposes no artifact paths, and the default Zstandard-compressed session log is not readable by hook scripts. `CLAUDE_PROJECT_DIR` defaults per-run to the session workspace when `projectDir` is omitted, matching the directory the hook runs in; `${CLAUDE_PLUGIN_ROOT}` and `${CLAUDE_PROJECT_DIR}` substitution happens at config parse time.

### Matcher subjects and serial execution

Tool matchers accept the Harness name and its Claude alias (`PreToolUse` / `PostToolUse` / `PostToolUseFailure`); payloads use the Claude alias. Other matcher subjects are the session source (`SessionStart`), or the constant `agent_type` `general-purpose` (`SubagentStart` / `SubagentStop` — the subagent seam carries no per-kind label); `UserPromptSubmit` and `Stop` ignore matchers. Matched hooks run serially in config order, while independent tool invocations may overlap; event pairs correlate by `handlerId`, and the most-restrictive fold is order-independent (`deny > ask > allow`).

### Detached runs and disposal

File-configured `SubagentStart` and `SubagentStop` run detached. `SessionStart` is tracked for cleanup and awaited before the first turn. Each run chain is tracked, and disposing the bridge aborts still-running hook processes and HTTP requests, then drains the continuations before the dispose resolves (`createDetachedRuns` in `dsh-hook-protocol`).

### Design philosophy

- **A compatibility adapter, not a power tool.** The bridge exists to run the explicitly supported command and HTTP subset of an existing Claude Code config; bespoke behavior belongs in a native plugin on the same extension points.
- **Adding context is not a veto.** A context-only hook delegates via `next()` before folding its message into a downstream enter decision, so a later `agent/pre-step` or `tools/post-execute` listener can still reject or rewrite.
- **Containment at every failure.** Config read/parse failures and invalid matchers register nothing; a throwing detached inject is caught and logged instead of breaking session boot or the loop.
- **Dispose reaches quiescence.** Detached runs are tracked and drained on disposal so no hook process or late callback outlives the fiber.
- **One invocation's hooks run in config order.** Independent invocations may overlap. Handler IDs preserve invocation/result pairing when their events interleave. The decision fold is order-independent; command side effects and elapsed time can still differ from engines that run sibling handlers concurrently.

The [hook-bridges Agent Note](../../../.agents/notes/archived/feature/2026-06-30-hook-bridges.md) records the bridge design and the deferred gaps; the [hook-protocol-lib Agent Note](../../../.agents/notes/archived/feature/2026-06-30-hook-protocol-lib.md) records the shared-versus-per-dialect split.

### Source map

| File | Role |
|---|---|
| [`src/index.ts`](src/index.ts) | Plugin entry: config validation, listener registration, per-event payloads, decision mapping |
| [`src/config.ts`](src/config.ts) | Claude Code config parsing: supported events, matcher validation, command substitution |
| — | No runtime invariant companion is published; this bridge publishes hook-protocol session events, whose companion owns which invocation event each result cites. |

</details>

-----

<a id="further-exploration"></a>
## Further Exploration

Read these pages when the package-level contract is not enough. They move from the shared protocol to the bridge design and the extension points it programs against.

- [Hooks group map](../README.md) — the sibling group page and its package table.
- [Hook protocol library](../hook-protocol/README.md) — the shared hook rules this bridge applies.
- [Hook bridges Agent Note](../../../.agents/notes/archived/feature/2026-06-30-hook-bridges.md) — the bridge design, decision mapping, and deferred gaps.
- [Interception extension-points Agent Note](../../../.agents/notes/implemented/feature/2026-06-30-interception-extension-points.md) — the typed-Decision surface the bridge maps onto.
- [Generated configuration catalog](../../../docs/config-catalog.md#deepseek-aidsh-hooks-claude-code) — every accepted config field and its source declaration.

-----

<a id="model-experience"></a>
## Model Experience

### Hook-provided context

#### What the model sees

`SessionStart`, accepted prompt, pre-tool, post-tool, and live in-process subagent-start hooks can add source-attributed context messages; a blocking `Stop` hook adds its reason as next-step steering. Remote-child injection has no local target.

#### Token effect

No cost when hooks return no context. Hook text is data-dependent, logged, and resent in later conversation requests until compaction.

#### KV Cache effect

Append-only; newly visible content follows the reusable request prefix and does not invalidate existing KV-cache entries.

### Blocked prompt or tool outcome

#### What the model sees

Provider-supplied reasons pass through verbatim. When absent, a denied tool becomes `Error: blocked by PreToolUse hook`, blocked post-tool feedback is exactly `blocked by PostToolUse hook`, and a blocking stop adds steering exactly `continue: blocked by Stop hook` (local-agent stop: `continue: blocked by SubagentStop hook`); a blocked prompt is discarded with no model-visible message, ending the turn as `blocked`. `systemMessage` is logged or warned but is not model-visible. Accepted input rewrites add a sourced correction containing original and accepted JSON to the next request.

#### Token effect

Blocking a prompt removes that prompt's request tokens; denial or feedback adds the retained fallback or provider text; forced continuation pays another full request.

#### KV Cache effect

A blocked prompt sends no request and invalidates nothing. Denial, feedback, and forced-continuation context append after the reusable prefix without rewriting it.

## Known Limitations and Deferred Work

<a id="known-limitations-and-deferred-work"></a>


These limits describe what your Claude Code hooks cannot do through this bridge yet, and where behavior differs from the reference tool. They are current package constraints, not a task backlog.

- **Unsupported hook events** — `Setup`, `InstructionsLoaded`, `UserPromptExpansion`, `MessageDisplay`, `PermissionRequest`, `PostToolBatch`, `PermissionDenied`, `Notification`, `TaskCreated`, `TaskCompleted`, `StopFailure`, `TeammateIdle`, `ConfigChange`, `CwdChanged`, `FileChanged`, `WorktreeCreate`, `WorktreeRemove`, `PreCompact`, `PostCompact`, `SessionEnd`, `Elicitation`, and `ElicitationResult`. File config ignores these events before group parsing; local-agent frontmatter rejects them. The comparison baseline is Claude Code's [official hook-event reference](https://code.claude.com/docs/en/hooks#hook-events).
- **`SessionStart` is partial** — JSON `additionalContext` and successful plain stdout are consumed, but `initialUserMessage`, `sessionTitle`, `watchPaths`, `reloadSkills`, and `CLAUDE_ENV_FILE` are unsupported. Initialization awaits the hook before the first request; the payload omits optional fields such as `model`, `agent_type`, and `session_title`.
- **`UserPromptSubmit` is partial** — blocking, JSON `additionalContext`, and successful plain stdout work, but `sessionTitle`, and `suppressOriginalPrompt` are unsupported.
- **`PostToolUse` is partial** — blocking feedback and JSON `additionalContext` work, but `updatedToolOutput` and `updatedMCPToolOutput` are unsupported and `tool_response` is flattened to text.
- **File-configured `SubagentStart` and `SubagentStop` are partial** — both report a constant `agent_type` of `general-purpose` and use the child session id where Claude Code reports the parent session. Start context is best-effort and can only reach a live in-process child; stop is observe-only and cannot block the subagent or feed it context. Stop omits `agent_transcript_path`, `last_assistant_message`, `background_tasks`, and `session_crons` and always reports `stop_hook_active: false`.
- **`Stop` is partial** — blocking forces another model step; `stop_hook_active` and `last_assistant_message` are supplied, but `background_tasks` and `session_crons` are omitted, and the consecutive-block cap is not implemented. An unconditionally blocking hook therefore force-continues every step unless it self-limits.
- **JSON-like stdout handling is partial** — a leading `{` reserves output for the structured decoder. Claude Code can treat incomplete objects and certain multi-line JSON output as plain text; the bridge does not. Full schema validation and native output spill are not implemented.
- **Common payload and output fields are partial** — mapped event payloads omit `prompt_id`, `permission_mode`, and `effort` where Claude Code would provide them, and `transcript_path` is never populated: it is always the empty string, because the persistence seam exposes no artifact paths and the default Zstandard-compressed session log is not readable by hook scripts. `systemMessage` is logged + warned but not surfaced; `continue: false` and `stopReason` apply only to active prompt, tool, and stopping listeners; `suppressOutput` and `terminalSequence` are not applied.
- **HTTP compatibility is partial** — static credential-name restrictions are implemented, but dynamic credential brokers, account/managed policy discovery, credential-bearing base-URL classification and native remote/TLS handling are not. HTTP response validation covers the supported event fields but does not implement the complete `PermissionRequest` output union or `defer` behavior. Host restrictions require explicit bridge config; they are not read from Claude settings.
- **Handler and config support is partial** — shell-form command and HTTP handlers run. File config skips `mcp_tool`, `prompt`, and `agent` handlers, while local-agent setup rejects them; command-handler options such as `args`, `async`, `asyncRewake`, `shell`, `if`, `once`, and `statusMessage` are not honored. Matching handlers run serially and are not deduplicated, whereas Claude Code runs them in parallel and deduplicates identical handlers. One process-level `configPath` is parsed once at load; Claude Code's layered project, user, plugin, and policy discovery and live reload are not implemented.

<a id="dev-note"></a>
### Dev Note

<details>
<summary>Working context for maintainers — click to expand</summary>

This Dev Note is working context for maintainers: open questions and directions that are not decided. It is explicitly non-authoritative — shipped behavior, limits, and accepted rationale live in the sections above, the package code, and the linked Agent Notes.

The deferred gaps above include per-session hook-config discovery, a stop loop-guard, and unsupported hook handler kinds. The official Claude Code reference is the baseline for closing them.

</details>
