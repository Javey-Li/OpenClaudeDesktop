/** Claude HTTP hook configuration, kept separate from the shared command dialect.
 * @module @deepseek-ai/dsh-hooks-claude-code/http-types
 */
/** One HTTP handler from Claude hook settings or trusted agent frontmatter. */
export interface HttpHook {
    type: 'http';
    url: string;
    headers?: Record<string, string>;
    allowedEnvVars?: string[];
    timeoutSec?: number;
}
/** Host restrictions shared by file-configured and local-agent HTTP hooks. */
export interface HttpHookPolicy {
    /** Wildcard URL patterns; an empty list disables all HTTP hook destinations. */
    allowedHttpHookUrls?: string[] | undefined;
    /** Header variable allowlist; also authorizes ordinary credential variables. CLI-internal tokens remain withheld. */
    httpHookAllowedEnvVars?: string[] | undefined;
}
//# sourceMappingURL=http-types.d.ts.map