/** Validate hook-authored arguments without coercion, defaults, or remote schema loading. */
/**
 * Explain invalid rewritten input, excluding extra-key errors as Claude's hook validator does.
 * @param schema - the visible tool's JSON parameter schema.
 * @param value - arguments parsed from a command hook's JSON output.
 * @returns a validation reason, or undefined when the input is accepted.
 */
export declare function rewrittenInputError(schema: Record<string, unknown>, value: unknown): string | undefined;
//# sourceMappingURL=input.d.ts.map