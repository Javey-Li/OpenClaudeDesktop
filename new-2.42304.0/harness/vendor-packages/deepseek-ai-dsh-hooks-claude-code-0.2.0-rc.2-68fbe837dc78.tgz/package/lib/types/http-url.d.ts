/** Match URL components, with host/scheme/port wildcards and path/query globbing.
 * @param url - Destination URL; fragments and embedded credentials do not select a route.
 * @param pattern - Host policy pattern; a bare origin also admits its paths.
 * @returns Whether the destination matches the configured pattern.
 */
export declare function matchesHttpHookUrl(url: string, pattern: string): boolean;
//# sourceMappingURL=http-url.d.ts.map