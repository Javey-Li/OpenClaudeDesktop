import type { Context } from '@deepseek-ai/cordis';
import type { HookOutput, RunHookResult } from '@deepseek-ai/dsh-hook-protocol';
import type { HttpHook, HttpHookPolicy } from './http-types.ts';
/** Mount host restrictions for every HTTP handler under the same runtime root.
 * @param ctx - Owning plugin scope; disposal removes its restriction.
 * @param policy - Optional host URL and environment allowlists.
 */
export declare function installHttpHookPolicy(ctx: Context, policy: HttpHookPolicy): void;
/** Parse HTTP JSON without treating a status code or plain text as shell output.
 * @param status - HTTP response status; only 2xx responses can supply decisions.
 * @param body - Complete response body; an empty successful body means an empty JSON object.
 * @param point - Event receiving the response.
 * @returns An actionable bridge outcome or a diagnostic-only nonblocking result.
 */
export declare function decodeHttpHookOutput(status: number, body: string, point: string): HookOutput;
/** Execute a configured HTTP hook with root-owned restrictions and operation cancellation.
 * @param ctx - Runtime scope used to recover the host's HTTP restrictions.
 * @param hook - Validated HTTP handler.
 * @param options - Event payload, signal, event name and resolved event timeout.
 * @returns Decoded hook output and measured elapsed time; transport failures are nonblocking.
 */
export declare function runHttpHook(ctx: Context, hook: HttpHook, options: {
    payload: unknown;
    signal: AbortSignal;
    point: string;
    defaultTimeoutMs: number;
}): Promise<RunHookResult>;
//# sourceMappingURL=http.d.ts.map