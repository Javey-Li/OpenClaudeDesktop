import type { LookupAddress, LookupOptions } from 'node:dns';
/** Test the CLI's private/link-local ranges; loopback remains usable for local hooks.
 * @param address - A numeric IPv4 or IPv6 address.
 * @returns Whether a direct HTTP hook connection must be refused.
 */
export declare function blockedHttpHookAddress(address: string): boolean;
type LookupCallback = (error: NodeJS.ErrnoException | null, address: string | LookupAddress[], family?: number) => void;
/** Validate every DNS answer and use that same result for the connection.
 * @param hostname - Hostname being connected to.
 * @param options - Node connector options, including its all-addresses mode.
 * @param callback - Receives the validated addresses or a lookup error.
 */
export declare function lookupHttpHook(hostname: string, options: LookupOptions, callback: LookupCallback): void;
/** Post one hook payload without redirects and read its body before releasing the connection.
 * @param url - Hook URL; only HTTP and HTTPS are accepted.
 * @param headers - Prepared request headers.
 * @param body - Serialized hook event input.
 * @param signal - Cancels connection and response-body reading.
 * @returns HTTP status and the complete response text.
 */
export declare function postHttpHook(url: URL, headers: Record<string, string>, body: string, signal: AbortSignal): Promise<{
    status: number;
    body: string;
}>;
export {};
//# sourceMappingURL=http-network.d.ts.map