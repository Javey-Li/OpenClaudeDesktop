/** Expand only explicitly permitted header variables and remove line/control delimiters.
 * @param text - Configured header value with $VAR or ${VAR} references.
 * @param allowed - Handler variables intersected with every host allowlist.
 * @param approvedCredentials - Host-approved credential names; internal CLI credentials cannot be approved.
 * @param env - Owning process environment, read at invocation time.
 * @returns A header value with missing, disallowed or protected variables replaced by empty text.
 */
export declare function expandHttpHookHeader(text: string, allowed: ReadonlySet<string>, approvedCredentials: ReadonlySet<string>, env: NodeJS.ProcessEnv): string;
//# sourceMappingURL=http-env.d.ts.map