/**
 * The in-process SPAWN subagent backend: registers a {@link SubagentProvider} on
 * `ctx.subagents` that runs each child as a fresh child {@link Agent} on the same cordis
 * context (its own session, own system prompt, zero parent context). The cheapest transport,
 * reusing the agent factory's quiescent teardown.
 * @module @deepseek-ai/dsh-subagent-spawn-in-process
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import './skills.ts';
export declare const name = "subagent-spawn-in-process";
export declare const inject: string[];
/** Config: the registry name to register the provider under. */
export interface Config {
    /** Provider name on `ctx.subagents` (default `spawn`). */
    providerName: string;
    /** Maximum failed structured-output calls per child (default 5). */
    maxStructuredOutputRetries: number;
    /** Opt into Claude child-model precedence; omitted keeps ordinary provider routing. */
    claudeModelSelection?: {
        /** Child default; otherwise read CLAUDE_CODE_SUBAGENT_MODEL at plugin load. */
        defaultModel?: string;
        /** Ignore caller and definition models; otherwise read CLAUDE_CODE_SUBAGENT_MODEL_FORCE. */
        force?: boolean;
        /** Model aliases by LLM provider; ANTHROPIC_DEFAULT_*_MODEL overrides each tier. */
        aliases?: Record<string, {
            haiku?: string;
            sonnet?: string;
            opus?: string;
        }>;
    } | undefined;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map