/** Claude child-model selection before the shared driver resolves provider-owned effort. */
import type { Agent, AgentOptions } from '@deepseek-ai/dsh-agent';
import type { Config } from './index.ts';
type Selection = NonNullable<Config['claudeModelSelection']>;
type Tier = 'haiku' | 'sonnet' | 'opus';
interface ResolvedSelection extends Selection {
    environmentAliases: Partial<Record<Tier, string>>;
}
/**
 * Capture trusted launch settings when this provider is loaded.
 * @param config - optional Claude model-selection policy.
 * @param env - trusted process environment.
 * @returns a detached policy, or undefined for ordinary routing.
 */
export declare function resolveModelSelection(config: Selection | undefined, env: NodeJS.ProcessEnv): ResolvedSelection | undefined;
/**
 * Select a child model without retaining a route-owned effort after a model change.
 * @param parent - parent whose latest request owns inherited model selection.
 * @param requested - caller overrides with definition effort already applied.
 * @param definitionModel - agent-definition model, including explicit inherit.
 * @param selection - opt-in Claude precedence and provider alias mappings.
 * @returns model overrides for the shared in-process driver.
 */
export declare function resolveSpawnAgentOptions(parent: Agent, requested: AgentOptions, definitionModel: string | undefined, selection: ResolvedSelection | undefined): AgentOptions;
export {};
//# sourceMappingURL=model-selection.d.ts.map