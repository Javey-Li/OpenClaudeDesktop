---
description: "面向用户与维护者的进程内 spawn subagent 后端说明，用于选择、配置或排查全新子级委派。"
kind: "package-reference"
---

# @deepseek-ai/dsh-subagent-spawn-in-process

[English](README.md) | 中文

## 概述

`dsh-subagent-spawn-in-process` 是一个进程内 subagent 后端：它在当前进程中运行每个委派任务，子 agent（智能体）是一个全新子 `Agent`，复用宿主的 agent 工厂及 LLM（大语言模型）/工具服务。子 agent 以空对话开始，因此任务提示词必须自足；除非 `request.agentOptions` 覆盖，否则它继承父 agent 的工作目录、会话谱系、提供方、模型、推理强度与输出 token 上限。委派工具或 API 调用以 `spawn` 提供方名称找到它。需要成本最低的委派传输时选择它；需要子 agent 建立在父级已完成对话轮次之上时，请选择 fork 后端。

## 目录

- [使用本包](#use-this-package)
- [理解实现](#understand-the-implementation)
- [进一步探索](#further-exploration)
- [模型体验](#model-experience)
- [已知限制与延期工作](#known-limitations-and-deferred-work)
- [开发备注](#dev-note)

-----

<a id="use-this-package"></a>
## 使用本包

配置 `claudeModelSelection` 后，模型优先级为调用方 → agent 定义 → 配置或启动环境默认值 → 父任务。精确的 `inherit` 跳过低优先级默认值。继承模型取自父任务的最新请求，包含请求期间的模型切换。`force` 忽略调用方和定义中的模型；未指定默认模型时继承父任务。插件在加载时读取 `CLAUDE_CODE_SUBAGENT_MODEL` 和 `CLAUDE_CODE_SUBAGENT_MODEL_FORCE`，显式配置优先。定义中不区分大小写的 inherit 会被规范化；调用方的 `INHERIT` 仍是字面模型 ID。

不区分大小写的 haiku、sonnet 和 opus 别名依次通过 `ANTHROPIC_DEFAULT_HAIKU_MODEL`、`ANTHROPIC_DEFAULT_SONNET_MODEL`、`ANTHROPIC_DEFAULT_OPUS_MODEL` 和 `aliases[provider]` 解析。显式模型系列别名与父任务的 Claude 系列相同时保留父任务的具体版本。未知 ID 去除两端空白后原样传递。默认不会把 Claude 模型 ID 分配给其他提供方；部署方负责配置档位映射。省略 `claudeModelSelection` 保持普通路由。模型在创建子任务前完成选择，因此请求和子任务进度使用选定模型。

本提供方支持 `agentOptions.streamToolCalls: true`：模型响应尚未结束时即可记录并执行完整工具块。调用方必须为每个一次性子代理显式启用，选项不会从父级继承。请求重试和传输降级仍由独立策略决定。

agentType 在项目祖先及用户 .claude/agents 的嵌套 Markdown 中按声明名称查找，也支持已启用插件的命名空间及清单自定义文件。项目和用户定义必须有 name、description；插件定义可使用文件名。tools 和 disallowedTools 按括号外的逗号或空格拆分条目，转换 Claude 别名及带参数的工具名称，再与调用方限制取交集；未安装的定义工具会跳过，显式列表解析后无工具则拒绝启动。插件的 permissionMode、hooks 和 mcpServers 会按 Claude 规则忽略。声明的 skills 从注册表或 .claude/skills 预加载完整正文，保留资源基目录，只注入子代理且写入日志；缺失或禁用的技能会警告并跳过。精确技能名优先，其次匹配代理所属插件，再匹配其他插件的名称后缀。每次调用重新读取磁盘定义。调用方未指定 isolation 时使用代理定义的 worktree 隔离。 worktree 创建 detached Git 工作树，释放时删除未修改的树，保留修改、未跟踪文件及新提交。Bash 限制解析命令列表及管道中的每条命令，对原始文本和展开后的文本分别匹配精确、前缀及通配规则，支持字面量引号和可静态验证的重定向。未知展开、复合控制语法、解析错误及超过 10,000 字符的命令会被拒绝。语法加载在子代理发布前完成，每次检查结束后释放解析器及语法树。Bash 限制也会禁用替代执行工具与 MCP 工具。这些选项不会扩大父级沙箱及审批限制。

在需要把工作委派给全新进程内子 agent 的组合中挂载此后端。常用配置路径很明确：加载 subagent 服务与本后端，再把 `dsh-tool-subagent` 之类的委派工具指向 `spawn` 提供方。

代理定义还可提供 effort 和 maxTurns。effort 接受 Claude 命名级别、med 别名及整数值，将规范化标识传给所选 Lab 提供方；提供方不支持的级别会明确失败。调用方 effort 优先于定义，定义优先于继承的父级 effort。有效的正整数 maxTurns 限制模型迭代次数，也包括 hook 触发的继续执行；已准入工具完成后才阻止下一次请求。子代理保留最后输出并返回 stopReason=max-turns；在最后允许的迭代正常结束仍返回 completed。无效元数据会警告并忽略。

工具列表中的参数选择整个工具：`tools: Bash(echo:*)` 允许 Bash，`disallowedTools: Bash(echo:*)` 完全移除 Bash；这些参数不构成命令权限。命令限制应使用独立的 `bashCommandClamp` 选项。Clamp 条目解码转义括号和反斜线，要求非空且首尾无空白的内容，并拒绝 `Bash(*)`，因为 CLI 将其解析为没有命令规则的工具名。`Bash(**)` 是显式的全命令模式，普通解析器、沙箱、权限和调用方限制仍然生效。在实现子类型限制前，允许列表中的 `Agent(type)` 仍不可用；拒绝列表中的该条目会移除整个 Agent 工具。

本地代理的 mcpServers 条目接受已挂载的服务器名称，或仅含一个键的内联 stdio/HTTP 配置。已挂载的名称借用父代理可见的连接、工具、资源和指令，不转移所有权。其他名称依次查找 ~/.claude.json 中精确项目记录、最近的有效祖先 .mcp.json、用户 mcpServers 记录。项目文件要求 enabledMcpjsonServers 或 enableAllProjectMcpServers 授权，disabledMcpjsonServers 优先拒绝。用户设置可以授权；项目和本地设置仅在目录已被明确信任时可以授权。每次启动重新读取有大小限制的磁盘文件。磁盘配置的 command、args、env、URL 和 headers 对 ${NAME}、${NAME:-default} 进行一次展开；空值仍为空，缺失变量保留占位符并警告。内联字段保持字面量。

新客户端要求本机执行环境；内联客户端还要求代理定义来自已信任项目或用户目录。连接在子代理发布前启动，期限为十秒；子代理释放时等待进程退出。配置查找使用原项目目录，stdio 在所选工作树中运行。MCP 工具在普通定义 tools 筛选后加入，调用方允许／拒绝规则、disallowedTools、plan 和 Bash clamp 仍然生效。共享资源工具遵循普通定义及调用方选择，包括 ListMcpResources／ReadMcpResource 别名和带 Tool 后缀的名称。借用时与来源资源准入取交集，Bash 限制隐藏共享资源工具；被过滤的工具不会出现在 schema、PTC 绑定或资源说明中。工具列表更新及重连保留准入规则。无效配置或连接失败时警告并跳过；若显式 tools 列表最终没有可用工具，则拒绝启动。

### 何时选择

当子 agent 不需要父级对话、且可以接受在本进程内运行时，选择 spawn 后端。当子 agent 必须建立在已完成父级轮次之上时——fork 后端会提供这些历史——或必须在本进程之外运行时（进程外后端提供此能力），请避免使用它。由于子 agent 默认继承父级的工作目录与 LLM 选择，自足的提示词会按原样生效。

### 最小配置

先加载 subagent 服务与本后端，再为每个目标配置一个委派工具。这是暴露由 spawn 支撑的 `subagent` 工具的最小组合：

```yaml
- name: '@deepseek-ai/dsh-subagent'
- name: '@deepseek-ai/dsh-subagent-spawn-in-process'
- name: '@deepseek-ai/dsh-tool-subagent'
  config:
    provider: spawn
```

| 字段 | 默认值 | 含义 |
|---|---|---|
| `providerName` | `spawn` | 注册到 `ctx.subagents` 的提供方名称 |
| `maxStructuredOutputRetries` | `5` | 每个子代理最多允许的结构化输出失败次数 |

生成的[配置目录](../../../docs/config-catalog.zh.md#deepseek-aidsh-subagent-spawn-in-process)是每个受支持字段及其 JSDoc 的穷尽式真源。

### 一次委派会做什么

一次工具调用启动一个子 agent 并等待其结果：子 agent 在自有会话中工作，父级只接收其最终输出；若运行被取消、拒绝、被 token 上限截断或在启动时被拒，则收到出错的工具结果。被拒绝的启动不会留下已发布的子 agent；完成的运行在结果收集后即被 dispose（资源释放）。

-----

<a id="understand-the-implementation"></a>
## 理解实现

<details>
<summary>实现细节——点击展开</summary>

本节解释后端的构建方式以及[使用本包](#use-this-package)中行为的来源；共享机制属于进程内驱动器。

### 设计理念

职责划分如下：本后端只贡献提供方注册与「全新开始」的决定，其余全部运行机制——深度检查、子 agent 创建、按子 agent 定制、结构化输出、取消、结果读取与 dispose——都在 `dsh-subagent-in-process-driver` 中。agent 工厂的创建事务拥有未发布设置窗口及其回滚；发布之后，调用方拥有该运行。

### 源码地图

| 文件 | 职责 |
|---|---|
| [`src/index.ts`](src/index.ts) | 提供方注册：`Config` schema、能力声明、`start()` |
| — | 不发布运行时不变式伴生入口；本包没有独立事件序列或可变数据关系，相关约定在所属 seam 强制执行。 |

### 运行流程

启动请求先由 subagent 服务解析，然后共享驱动器校验深度、生成子会话 id、通过宿主 agent 工厂以调用方信号创建子 agent、在创建窗口内应用 persona、工具过滤器与结构化输出、发布子 agent、驱动一项任务、读取子 agent 自身的最终输出，最后完全停稳地 dispose 句柄。

### 所有权与作用域

子 agent 获得全新的扁平注册作用域：父级工具限制与权限绝不会被导入，工具所施加的过滤属于组合而非父级派生授权。后端声明包括 `agentOptions` 在内的已声明的启动时能力，因为它控制子 agent 的创建窗口，可以逐一强制执行。

</details>

-----

<a id="further-exploration"></a>
## 进一步探索

当包级约定不够用时阅读以下页面；它们从共享 subagent 模型进入兄弟后端与穷尽式配置。

- [Subagent 子系统](../../../docs/subsystems/subagent.zh.md)——启动请求、结果、实时运行与提供方约定。
- [dsh-subagent-in-process-driver](../subagent-in-process-driver/README.zh.md)——本后端调用的共享运行驱动器。
- [dsh-subagent-fork-in-process](../subagent-fork-in-process/README.zh.md)——以已完成父级轮次作初始内容的兄弟后端。
- [dsh-tool-subagent](../tool-subagent/README.zh.md)——指向该提供方的面向模型委派工具。
- [生成配置目录](../../../docs/config-catalog.zh.md#deepseek-aidsh-subagent-spawn-in-process)——每个受支持配置字段及其源声明。

-----

<a id="model-experience"></a>
## 模型体验

### 子 agent 请求

#### 模型看到什么

全新子 agent 在新对话中逐字接收任务内容，声明的技能指令先行注入，默认使用父级提供方、模型、推理强度、输出 token 上限与工作目录。配置的 persona 会在子 agent 作用域中遮蔽全局提示词文本；工具过滤器会从其 schema、可执行工具查找与 PTC mode SDK 绑定中移除指定的全局工具，但保留独立注册的指导内容。不包含任何父级对话消息；过滤属于组合，而非继承的权限授予。

#### Token 影响

子 agent 会为全新的独立上下文与历史消耗 token，不复制任何父级历史 token。persona 会改变该子 agent 反复使用的提示词成本；工具过滤器会改变其 schema 或生成 SDK 的成本。

#### KV Cache 影响

子 agent 的请求缓存与父级相互独立。子 agent 历史仅追加；persona、工具过滤、生成 SDK、提供方或模型变化会建立不同的子 agent 前缀。

### 父级工具结果（间接）

#### 模型看到什么

通过 `dsh-tool-subagent`，父级只接收子 agent 的最终输出，或非完成终止原因对应的出错结果；子 agent 的中间工作绝不会到达父级。

#### Token 影响

父级输入增加一个取决于数据的结果，并保留到上下文压缩（context compaction）为止。

#### KV Cache 影响

仅追加；新增可见内容位于可复用请求前缀之后，不会使现有 KV Cache 条目失效。

## 已知限制与延期工作

<a id="known-limitations-and-deferred-work"></a>


这些限制说明何时选择该后端是错误的；它们是当前包约束。

- **全新表示不含父级 transcript（文本记录）**——子 agent 继承 cwd、谱系、提供方、模型、推理强度、输出 token 上限及显式配置的 persona/工具限制，但不继承父级的任何对话；需要已完成轮次上下文时，请使用 fork 后端。

- **Claude 扩展** — 本地命令与 HTTP hooks 使用 [Claude 桥接](../../hooks/hooks-claude-code/README.zh.md#local-agent-definitions)，遵循精确目录信任检查及其余事件、输出限制。尚未实现旧版 SSE、OAuth、headersHelper、托管／strict／safe-mode MCP 策略及完整的 Claude 保留名称目录。磁盘发现的命名连接由子代理拥有，不跨子代理缓存；已挂载的名称优先于磁盘修改。尚不支持未信任且未被 Git 跟踪的本地设置授权、CLI 授权覆盖、设置中的环境变量、原生凭据变量清空及 CLAUDE_CONFIG_DIR。资源别名选择 Harness 工具；尚不支持 Claude 不指定服务器的聚合资源列表及目录资源读取。memory、其余元数据和技能 shell 替换尚未实现。技能预加载读取声明式正文，不执行其中嵌入的 shell 命令。

<a id="dev-note"></a>
### 开发备注

<details>
<summary>维护者的工作上下文——点击展开</summary>

无。

</details>
