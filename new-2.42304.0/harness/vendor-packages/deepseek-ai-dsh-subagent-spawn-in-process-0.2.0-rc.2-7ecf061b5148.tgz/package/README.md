---
description: "In-process spawn subagent backend for users and maintainers choosing, configuring, or debugging fresh-child delegation."
kind: "package-reference"
---

# @deepseek-ai/dsh-subagent-spawn-in-process

English | [中文](README.zh.md)

## Summary

`dsh-subagent-spawn-in-process` is an in-process subagent backend: it runs each delegated task in a fresh child agent that shares this process and its agent factory, LLM, and tool services. The child starts with an empty conversation, so a task prompt must stand alone; it inherits the parent's working directory, session lineage, provider, model, reasoning effort, and output-token limit unless `request.agentOptions` overrides them. A delegation tool or API call reaches it under the `spawn` provider name. Choose it for the cheapest delegation transport; choose the fork backend when the child must build on the parent's completed conversation turns.

## Table of Contents

- [Use this package](#use-this-package)
- [Understand the implementation](#understand-the-implementation)
- [Further Exploration](#further-exploration)
- [Model Experience](#model-experience)
- [Known Limitations and Deferred Work](#known-limitations-and-deferred-work)
- [Dev Note](#dev-note)

-----

<a id="use-this-package"></a>
## Use this package

With `claudeModelSelection` configured, model precedence is caller → agent definition → configured or launch-environment default → parent. Exact `inherit` bypasses lower-priority defaults. The inherited model comes from the parent’s latest request, including request-time switches. `force` ignores caller and definition models; without a default it inherits the parent. The plugin captures `CLAUDE_CODE_SUBAGENT_MODEL` and `CLAUDE_CODE_SUBAGENT_MODEL_FORCE` at load unless explicit config supplies those settings. A definition’s case-insensitive inherit value is normalized; a caller’s `INHERIT` remains a literal model ID.

The case-insensitive haiku, sonnet and opus aliases resolve through `ANTHROPIC_DEFAULT_HAIKU_MODEL`, `ANTHROPIC_DEFAULT_SONNET_MODEL` and `ANTHROPIC_DEFAULT_OPUS_MODEL`, then `aliases[provider]`. An explicit family alias retains the parent’s concrete Claude version when it belongs to that family. Unknown IDs pass through after trimming. No Claude model IDs are assigned to another provider by default; deployments supply their tier mappings. Omitting `claudeModelSelection` preserves ordinary routing. Model selection happens before child creation, so requests and child progress use the selected model.

This provider supports `agentOptions.streamToolCalls: true`. Complete tool blocks are recorded and executed while the model response remains open. The caller must opt in for each one-shot child; the option is not inherited from its parent. Request retry and transport fallback remain separate policies.

agentType resolves declared names in nested project-ancestor/user .claude/agents Markdown and enabled plugin namespaces, including custom manifest files. Project/user definitions require name and description; plugin files may use the filename. tools and disallowedTools split comma- or space-separated entries outside parentheses, normalize Claude aliases and argument-bearing tool names before intersecting caller restrictions, ignore unavailable definition selectors, and reject explicit lists that resolve to zero tools. Plugin permissionMode, hooks and mcpServers are ignored, matching Claude plugin-agent rules. Declared skills preload registry or .claude/skills bodies into logged child-only instruction messages, retaining resource bases; missing or disabled skills warn and skip. Exact skill names precede the agent plugin namespace and other plugin suffix matches. Each call rereads disk definitions. Agent worktree isolation applies when the caller omits isolation. worktree isolation creates a detached Git worktree, removes unchanged trees on disposal, and retains edits, untracked files or new commits. Bash clamps parse every command in lists and pipelines, match exact/prefix/wildcard rules against both raw and resolved spans, and permit literal quoting and statically verified redirects. Unknown expansions, compound control syntax, parse errors and commands longer than 10,000 characters are rejected. The grammar loads before child publication; each guarded call releases its parser and syntax tree. Clamps also disable alternate execution and MCP tools. These options never widen the parent sandbox/approval pin.

Mount this backend in a composition that delegates work to fresh in-process children. The common path is explicit: load the subagent service and this backend, then point a delegation tool such as `dsh-tool-subagent` at the `spawn` provider.

Agent definitions also supply effort and maxTurns. Effort accepts Claude named levels, the med alias and integer values, then passes the normalized identifier to the selected Lab provider; unsupported provider efforts fail explicitly. Caller effort overrides the definition, which overrides inherited parent effort. A valid positive maxTurns limits model iterations, including hook-driven continuation, after admitted tools finish. The child retains its last output with stopReason=max-turns; normal completion on the final permitted iteration remains completed. Invalid metadata warns and is omitted.

Tool-list arguments select the whole named tool: `tools: Bash(echo:*)` admits Bash, and `disallowedTools: Bash(echo:*)` removes Bash entirely. They do not create command permissions. Use the separate `bashCommandClamp` option for command restrictions. Clamp entries decode escaped parentheses and backslashes, require nonempty unpadded content, and reject `Bash(*)` because the CLI parses it as a bare tool rather than a command rule. `Bash(**)` is an explicit all-command pattern; the normal parser, sandbox, permission and caller restrictions still apply. An `Agent(type)` allow selector remains unavailable until subtype enforcement exists; a disallowed entry removes the whole Agent tool.

Local agent mcpServers entries accept a mounted server name or a one-key inline stdio/HTTP configuration. Mounted names borrow the parent-visible connection, tools, resources and instructions without transferring ownership. Other names search the exact project record in ~/.claude.json, nearest valid ancestor .mcp.json, then the user mcpServers record. Project files require enabledMcpjsonServers or enableAllProjectMcpServers; disabledMcpjsonServers wins. User settings may grant approval; project and local settings may grant it only for an explicitly trusted directory. Each start rereads bounded disk files. Disk command, args, env, URL and headers expand ${NAME} and ${NAME:-default} once; empty values stay empty and missing variables retain their placeholder with a warning. Inline fields remain literal.

New clients require a local execution world. Inline clients also require a trusted project definition or user definition. Connections start inside unpublished setup with a ten-second deadline, and child disposal drains their processes. Lookup uses the original project while stdio runs in the selected worktree. MCP tools are added after ordinary definition tools selection, while caller allow/deny rules, disallowedTools, plan and Bash clamps still apply. Shared resource helpers follow ordinary definition and caller selection, including the ListMcpResources/ReadMcpResource aliases and their Tool-suffixed names. Borrowing intersects source resource admission, Bash clamps hide shared resource helpers, and filtered helpers are absent from schemas, PTC bindings and resource guidance. List changes and reconnects retain admission rules. Invalid or failed connections warn and skip; an explicit tools list with no surviving tools rejects startup.

### When to choose it

Choose the spawn backend when the child needs no parent conversation and running in this process is acceptable. Avoid it when the child must build on completed parent turns — the fork backend seeds that history — or when the child must run outside this process, which the out-of-process backends provide. Because the child inherits the parent's working directory and LLM selection by default, a self-contained prompt behaves exactly as written.

### Minimal configuration

Load the subagent service and this backend, then configure one delegation tool per target. This is the smallest composition that exposes a `subagent` tool backed by spawn:

```yaml
- name: '@deepseek-ai/dsh-subagent'
- name: '@deepseek-ai/dsh-subagent-spawn-in-process'
- name: '@deepseek-ai/dsh-tool-subagent'
  config:
    provider: spawn
```

| Field | Default | Meaning |
|---|---|---|
| `providerName` | `spawn` | Provider name registered on `ctx.subagents` |
| `maxStructuredOutputRetries` | `5` | Maximum failed structured-output calls per child |

The generated [configuration catalog](../../../docs/config-catalog.md#deepseek-aidsh-subagent-spawn-in-process) is the exhaustive source for every accepted field and its JSDoc.

### What a delegation does

One tool call starts one child and waits for its result: the child works in its own session and the parent receives only its final output, or an errored tool result when the run is cancelled, refused, truncated by its token limit, or rejected at startup. A rejected start leaves no published child; a completed run is disposed after its result is collected.

-----

<a id="understand-the-implementation"></a>
## Understand the implementation

<details>
<summary>Implementation internals — click to expand</summary>

This section explains how the backend is built and where the behavior in [Use this package](#use-this-package) comes from; the shared mechanics belong to the in-process driver.

### Design concept

One separation: this backend contributes only the provider registration and the decision to start fresh, while every run mechanic — depth checking, child creation, per-child customization, structured output, cancellation, result reading, and disposal — lives in `dsh-subagent-in-process-driver`. The agent factory's creation transaction owns the unpublished setup window and its rollback; after publication the caller owns the run.

### Source map

| File | Role |
|---|---|
| [`src/index.ts`](src/index.ts) | Provider registration: `Config` schema, capability declaration, `start()` |
| — | No runtime invariant companion is published; this package exposes no independent event sequence or mutable data relation beyond contracts enforced at its owning seam. |

### Run flow

A start request resolves through the subagent service, then the shared driver validates depth, mints a child session id, creates the child through the host agent factory with the caller's signal, applies persona, tool filter, and structured output inside the creation window, publishes the child, drives one task, reads the child's own final output, and disposes the handle quiescently.

### Ownership and scope

The child gets a fresh flat registration scope: parent tool restrictions and authority are never imported, and the filter the tool applies is composition, not a parent-derived grant. The backend advertises the declared start-time capabilities, including `agentOptions`, because it controls the child's creation window and can enforce each one.

</details>

-----

<a id="further-exploration"></a>
## Further Exploration

Read these pages when the package-level contract is not enough; they move from the shared subagent model to the sibling backends and exhaustive configuration.

- [Subagent subsystem](../../../docs/subsystems/subagent.md) — start requests, results, live runs, and the provider contract.
- [dsh-subagent-in-process-driver](../subagent-in-process-driver/README.md) — the shared run driver this backend calls.
- [dsh-subagent-fork-in-process](../subagent-fork-in-process/README.md) — the sibling backend that seeds completed parent turns.
- [dsh-tool-subagent](../tool-subagent/README.md) — the model-facing delegation tool that reaches this provider.
- [Generated configuration catalog](../../../docs/config-catalog.md#deepseek-aidsh-subagent-spawn-in-process) — every accepted config field and its source declaration.

-----

<a id="model-experience"></a>
## Model Experience

### Child-agent request

#### What the model sees

The fresh child receives the task content verbatim in a new conversation, preceded by any declared skill instructions, with the parent provider, model, reasoning effort, output-token limit, and working directory by default. A configured persona shadows global prompt text in the child's scope; a tool filter removes named global tools from its schemas, executable lookup, and PTC mode SDK bindings while leaving independently registered guidance. No parent conversation message is included; the filter is composition, not an inherited authority grant.

#### Token effect

The child pays for a new independent context and history, and no parent-history token is duplicated. A persona changes the child's repeated prompt cost; a tool filter changes its schema or generated SDK cost.

#### KV Cache effect

The child's request cache is independent of the parent's. Child history grows append-only, while persona, tool-filter, generated-SDK, provider, or model changes establish a different child prefix.

### Parent tool result, indirectly

#### What the model sees

Through `dsh-tool-subagent`, the parent receives only the child's final output or an errored result for a non-completed stop reason; intermediate child work never reaches it.

#### Token effect

Parent input grows by one data-dependent result, retained until compaction.

#### KV Cache effect

Append-only; newly visible content follows the reusable request prefix and does not invalidate existing KV-cache entries.

## Known Limitations and Deferred Work

<a id="known-limitations-and-deferred-work"></a>


These limits define when the backend is the wrong choice; they are current package constraints.

- **Fresh means no parent transcript** — the child inherits cwd, lineage, provider, model, reasoning effort, output-token limit, and explicitly configured persona or tool restrictions, but none of the parent's conversation; use the fork backend when completed-turn context is required.

- **Claude extensions** — local command and HTTP hooks use the [Claude bridge](../../hooks/hooks-claude-code/README.md#local-agent-definitions), including its exact-directory trust checks and remaining event/output limits. Legacy SSE, OAuth, headersHelper, managed/strict/safe-mode MCP policies and the complete Claude reserved-name catalog are not implemented. Disk-created named connections are child-owned rather than cached across children; mounted names take precedence over disk edits. Untrusted untracked local-settings approval, CLI approval overrides, settings-sourced environment values, native credential-variable blanking and CLAUDE_CONFIG_DIR remain unsupported. Resource aliases select Harness helpers; Claude aggregate resource listing without a server and directory-resource reads remain unsupported. Memory, remaining metadata and skill shell substitutions are not implemented. Skill preloading reads declarative bodies and never executes embedded shell commands.

<a id="dev-note"></a>
### Dev Note

<details>
<summary>Working context for maintainers — click to expand</summary>

None.

</details>
