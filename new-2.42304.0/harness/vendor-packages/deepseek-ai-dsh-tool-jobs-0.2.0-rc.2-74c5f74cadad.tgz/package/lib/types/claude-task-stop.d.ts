/** Claude Code task cancellation over the owner-scoped job registry. */
import type { Context } from '@deepseek-ai/cordis';
import { JobId } from '@deepseek-ai/dsh-jobs';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
/**
 * Construct TaskStop while sharing notice suppression with the generic controller.
 * @param ctx - Controller context with its job registry.
 * @param stopped - Jobs whose cancellation was already delivered through a tool result.
 * @param waitCap - Maximum cooperative cleanup wait in milliseconds.
 * @returns Strict TaskStop with task_id and deprecated shell_id inputs.
 */
export declare function claudeTaskStop(ctx: Context, stopped: Set<JobId>, waitCap: number): ToolDefinition;
//# sourceMappingURL=claude-task-stop.d.ts.map