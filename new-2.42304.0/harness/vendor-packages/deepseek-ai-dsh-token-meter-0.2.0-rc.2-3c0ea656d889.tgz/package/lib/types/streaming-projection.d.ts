/** Price reconstruction of one streamed assistant's advertised surface nodes. */
import type { SessionEvent, SessionSeq } from '@deepseek-ai/dsh-session';
/** One validated merge's selected nodes and role-framing correction.
 * @param nodes - currently retained message estimates before applying the merge.
 * @param event - validated decision identifying every segment of one response.
 * @returns selected estimates, their sequence identities, merged tokens, and the framing adjustment.
 */
export declare function planStreamingTokens<Node extends {
    seq: SessionSeq;
    heuristicTokens: number;
}>(nodes: readonly Node[], event: SessionEvent<'assistant/stream-merge'>): {
    selected: Node[];
    sequences: ReadonlySet<SessionSeq>;
    tokens: number;
    delta: number;
};
//# sourceMappingURL=streaming-projection.d.ts.map