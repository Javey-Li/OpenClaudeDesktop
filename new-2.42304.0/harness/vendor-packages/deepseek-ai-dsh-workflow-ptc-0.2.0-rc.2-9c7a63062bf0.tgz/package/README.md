---
description: "Run workflow orchestration through the shared sandboxed PTC Node process runtime, with workflow hooks, subagent routing and caller-owned cancellation."
kind: "package-reference"
---

# @deepseek-ai/dsh-workflow-ptc

English | [中文](README.zh.md)

## Summary

Run JavaScript workflows in fresh Node processes under the calling Session's file sandbox policy. Scripts keep the `agent()`, `parallel()`, `pipeline()`, `phase()` and `log()` hooks while subagents perform delegated work. The same execution provider serves PTC and workflows, including the opt-in Ralph loop. Runs have no overall elapsed deadline; cancellation stops the managed process and disposes child agents. The selected sandbox and subprocess providers determine enforcement and cleanup limits.

## Table of Contents

- [Use this package](#use-this-package)
- [Understand the implementation](#understand-the-implementation)
- [Further Exploration](#further-exploration)
- [Model Experience](#model-experience)
- [Known Limitations and Deferred Work](#known-limitations-and-deferred-work)
- [Dev Note](#dev-note)

-----

<a id="use-this-package"></a>
## Use this package

The engine preserves optional display titles separately from workflow names and accepts empty string phase titles. CLI source normalization belongs to tool-workflow; direct engine metadata still rejects unknown fields.

Mount this engine in a composition that provides subagents, token-meter, session projections, sandbox policy and the [Node PTC runtime](../../ptc-runtime/ptc-runtime-node/README.md). It supplies workflow execution for `dsh-tool-workflow` and for `dsh-tool-ralph` when explicitly enabled. Ralph remains disabled in shipped defaults. The engine rejects non-TypeScript PTC providers when it loads. Python PTC compositions must disable the `workflow-ptc`, `tool-workflow` and any enabled `tool-ralph` rows.

### Minimal configuration

With those dependencies available, mount the engine and its model-facing consumer:

```yaml
- name: '@deepseek-ai/dsh-workflow-ptc'
- name: '@deepseek-ai/dsh-tool-workflow'
```

| Field | Default | Meaning |
|---|---|---|
| `journalDirectory` | `<DSH_HOME>/workflows` | Private sidecar root, partitioned by hashed Session identity. |
| `sessionMirror` | `false` | Retain private source and invocation backups in the owning Session log. |
| `provider` | `spawn` | Host-side subagent provider used by `agent()` calls. |
| `maxConcurrentAgents` | `0` | Concurrent `agent()` ceiling; `0` resolves from available CPU parallelism. |
| `maxTotalAgents` | `1000` | Total `agent()` calls one run may start. |
| `maxItemsPerCall` | `4096` | Items accepted by one `parallel()` or `pipeline()` call. |
| `syncTimeoutMs` | `5000` | VM timeout for the script's initial synchronous slice, in milliseconds. |

An owning consumer may set `WorkflowStartRequest.subagentProvider` and lower `WorkflowStartRequest.maxTotalAgents` for one run. Script hooks cannot change either choice. Process heap, output, control and termination limits belong to the Node PTC provider; the engine adds no overall elapsed timer. The generated [configuration catalog](../../../docs/config-catalog.md#deepseek-aidsh-workflow-ptc) defines accepted engine fields.

The Node PTC provider's `maxPendingCalls` also limits workflow concurrency: child startup, result waits and disposal use those slots. Progress batches use at most one additional slot. Leave headroom when setting `maxConcurrentAgents`.

### Results and failures

Workflow children enable streaming tool execution when their subagent provider advertises `streamToolCalls`. Complete calls may run before the response finishes; partial arguments never run. Provider stream recovery retains already executed results. A response failure after an accepted conclusion returns a failed child with no structured value, and a late rate-limit error cannot recreate a child that has already handled tools.

`pipeline()` accepts promised items and stops processing an item when a stage returns `null`. `parallel()` requires a function in every slot. `phase()` and `log()` stringify primitives and render objects/functions without calling their conversion hooks. Local child activity emits `workflow/agent-progress`, throttled by `progressIntervalMs` (default 250 ms). Tool activity, streaming output and provider usage update these snapshots; cancellation removes subscriptions and pending timers. `tokens` sums disjoint input/cache/output usage, while `outputTokens` remains the output budget measure.

A child ending at its definition’s maxTurns or stopped by its own hook returns retained text or an accepted structured value. Missing structured output rejects the script call; a normally completed child still has a completed lifecycle. Provider API failures return null with a failed lifecycle, while exhausted structured validation rejects with a failed lifecycle. Failed schema calls are not reused from the journal. Caller cancellation still aborts the workflow.

Providers advertising outputSchemaCompletion receive response completion for schema calls: all tools in the current response run, and the last valid structured result wins. The retry cap still stops later calls when no valid result exists. Other providers retain their declared structured-output behavior.

The script runs as strict JavaScript with top-level `await`; root `args` is copied into the script realm as JSON data. Metadata describes the run and is not a script variable. Every `agent()` call uses the configured subagent provider and the run's fixed parent. The final sanitized return value becomes the run result; an ordinary child failure resolves `agent()` to `null`.

Compilation rejects imports, `await using` and identifiers beginning with `__wRg$` before publishing work. Async returns, yields and awaits use a captured guest Promise resolver. `for await` and async-generator delegation resolve both iterator steps and their values, including completion and early-return values; invalid iterator objects, methods or results throw TypeError. Iterator methods are captured when iteration starts.

Invalid metadata, script bodies or routes fail before publication. Combinators snapshot every array slot after yielding, including holes as undefined, and validate all functions before invoking any item. Empty arrays bypass admission and stage checks; nonempty calls reject exhausted agent or output limits. Individual item exceptions become null; uncaught exceptions outside combinators and PTC process or confinement failures fail the run.

Host hooks return Promises in the calling script realm. Their failures expose frozen null-prototype records with name, message, stack and toString; host error codes and custom fields are absent. Agent data and completed combinator results are copied into root-script objects, preserving cycles and repeated references within one copy. Copies omit function-valued object properties, symbols and __proto__, replace unreadable or function-valued array slots with undefined, and reject nested arrays above 4096 entries. Pipeline stages retain the original item identity until the final copy. Dropped helper rejections are consumed; timer callbacks discard synchronous exceptions.

### Determinism, resume and saved scripts

`Date.now()`, `Math.random()`, `Date()` and `new Date()` without arguments throw. Pass timestamps or deterministic seeds through `args`; explicit dates such as `new Date(args.timestamp)` remain available. Constructor aliases cannot recover the ambient clock. Built-in constructors, prototypes and namespaces are frozen; ordinary own fields such as Error subclass names remain assignable. Dynamic string evaluation and WebAssembly are unavailable. These restrictions guide authors and do not turn the VM into a security boundary.

Phase titles, including empty strings, identify one group per attempt. Metadata declarations announce groups without changing the current phase. phase(title) sets that current phase; an explicit agent phase belongs only to its invocation. First reservation assigns the one-based index and child kind, even for an empty child. Announcements deduplicate and precede queue waits; concurrent source resolution can reserve child groups in either completion order. Events, agent membership and output files carry those same indices. Progress consumers sort displayed groups by index and preserve missing membership for unphased agents.

Uncached agent calls publish queue observations synchronously before waiting for a slot. The guest drains those observations before requesting a child; publication updates the same output row. Startup failure retains the queued identity and error without fabricating a child. Cached calls publish completed rows in invocation order, before subsequent phase calls, without queue timestamps. The host verifies their journal key and child identity before publishing events; verification failure prevents later child startup and fails the run. Labels collapse whitespace and preserve explicit empty strings; absent labels use the first 60 UTF-16 units of the prompt, avoiding split surrogate pairs. JSON label and phase options use string conversion; nullish values select the default label or current phase.

New run IDs use wf_ followed by twelve UUID characters. IDs are opaque; the journal reader also accepts earlier UUID IDs. Resumed runs retain that ID and mint a separate attemptId. Resume is refused until the previous execution and its children have settled. Each attempt writes a separate v2 invocation journal, selected by an atomically replaced current.json; older journals remain available and legacy journal.jsonl files remain readable. Each run saves its full script; an explicit resolved scriptPath is returned unchanged without writing the source file. Resume requires the same Session and provider. An interrupted started call reruns while completed siblings after it remain reusable. A recorded failure or changed invocation invalidates the suffix. Labels, phases and stall thresholds do not affect cache keys; hits spend no new tokens. Old v1 journals remain readable but their results recompute under the new call keys.

Each attempt creates an empty private `<attemptId>.output` file beside its invocation journal. After child cleanup, successful completion publishes flushed, two-space JSON containing summary, agentCount, logs, optional result, workflowProgress, totalTokens and totalToolCalls, without a final newline. An undefined return omits result; explicit null remains null. Failed and cancelled runs keep empty output; their errors remain in the completion event. Phase rows retain one-based reserved indices, deduplicate titles and mark child groups with kind:child. Agent rows retain measured activity and bounded prompt/result previews. Unavailable provider measurements and their aggregate totals are omitted; cached calls add no usage. Model rendering caps never truncate the result in this file. Publication failure fails the run without advertising its output file. Read the published path to inspect diagnostics.

### Budget and nested scripts

`budgetTotal` compares admission against live output usage from the parent turn, including the main agent and sibling workflows. Direct starts outside a turn use an independent pool. Null/absent is unlimited; zero disables admission checks while remaining is zero. The host checks actual usage before startup and after queue waits; script snapshots refresh at `budgetRefreshMs`. Running requests may overshoot. Positive budgets require remote providers to report output usage.

`workflow(name, args?)` or `workflow({scriptPath}, args?)` loads registered definitions or uses the host `resolveWorkflow` callback, with one nested level. Other selector shapes reject with TypeError. A child retains the workflow function, but calling it returns a rejected Promise. Children share slots, counts, the agent-call journal chain and budget. Only agent prompts and execution options affect that chain; unused child source or argument changes do not invalidate it.

Nested arguments use the child VM copier and accept cycles, BigInt and symbols without JSON serialization. Nested return objects retain child prototypes; agent and combinator results retain root prototypes. Use Array.isArray instead of realm-sensitive instanceof checks. Child logs carry a [name] prefix. Inner phase calls are ignored, and every child agent uses the reserved ▸ name group, then ▸ name #2 for the next call. A group appears only when its first agent is admitted, or when a root phase uses that reserved title. All scripts share timer IDs: child return or failure leaves timers active until root settlement clears them.

The original budget object and wrapped timer functions are shared by all scripts in one run. Properties attached to budget functions or timers are visible to parent and sibling scripts; rebinding a global affects only that script. Other hook wrappers remain local to each script, and no hook properties survive into another run.

Local spawn supports effort, Claude-format agentType, Git worktrees, disallowedTools and bashCommandClamp. Other providers must reject unsupported capabilities. Active members support skip/retry; no activity triggers up to five retries after 600000 ms by default, with stall detection suspended during tools. Rate limits share a deadline with two waits by default. Matching-prefix followers wait for the first response or at most 5000 ms.

Workflow children always exclude `Agent`/`Task`, `Workflow`, and `SendUserMessage`, including Harness delegation, fork and Ralph equivalents. Agent definitions and later scoped registrations cannot reopen them. Providers must support `toolFilter` and enforce its exact-name `exclude` list before publishing a child; unsupported providers fail before startup. Script-level `workflow()` nesting remains available.

Root agent calls retain the first copy of an own data-property schema object, even if later calls mutate that object. Accessor and proxy options bags do not enter the root reference cache. Each child script retains its own schema references, including accessor bags, before forwarding to the root. Use a new schema object to change the requested output; new root runs and new child invocations start fresh.

### File policy and cancellation

The engine resolves the calling Session's standing file policy and cwd for PTC execution. The VM retains the documented helper API, but it is not a security boundary: code that reaches Node remains subject to the selected OS file policy. The program-visible environment is empty. Network access is not restricted by the file policy.

The workflow requests `timeoutMs: null` from PTC. Its initial VM slice still has `syncTimeoutMs`, and a caller's abort signal still applies, including an enclosing tool deadline. Cancellation immediately aborts the PTC process and pending or active subagents. The caller must dispose every run and await child cleanup; there is no separate workflow cleanup timer.

-----

With sessionMirror enabled, each flushed start/result record is also appended as workflow-ptc/mirror to the owning Session. Backup failure warns without failing the primary run. The host-only workflowMirror projection retains the latest attempt and ignores inherited records from other Sessions. Resume restores a missing journal and matching private source from this projection; it never overwrites an existing file, repairs a corrupt journal, or recreates external user scripts. Durable recovery after restart requires retained Session persistence. This backend is local Session storage, not Claude account storage.

<a id="understand-the-implementation"></a>
## Understand the implementation

`sourceDirectories(parent)` exposes only the Session partition beneath journalDirectory. The Workflow tool uses this directory to admit returned private script paths, including after a reload. An explicit external source does not add its directory to this grant.

<details>
<summary>Implementation internals — click to expand</summary>

The workflow engine owns orchestration; the PTC provider owns process launch, OS confinement, framed transport and managed process cleanup.

### Design concept

One self-contained guest program runs the existing VM and workflow helpers inside a PTC Node process. Host bindings connect that program to `ctx.subagents` and workflow observers. The engine captures the runtime and subagent services when a run starts, so an accepted run retains its dependencies through engine unload.

### Source map

| File | Role |
|---|---|
| [`src/index.ts`](src/index.ts) | Engine configuration, request validation and run creation |
| [`src/host.ts`](src/host.ts) | PTC execution, child ownership, settlement and disposal |
| [`src/guest.ts`](src/guest.ts) | Guest adapter over PTC host bindings |
| [`src/guest-source.ts`](src/guest-source.ts) | Self-contained guest program source |
| [`src/runtime.ts`](src/runtime.ts) | VM evaluation, helper contracts and combinators |
| [`src/intrinsics.ts`](src/intrinsics.ts) | Guest clock guards and frozen JavaScript intrinsics |
| [`src/compiler.ts`](src/compiler.ts) | Script admission and guest-local async value resolution |
| [`src/boundary.ts`](src/boundary.ts) | Guest callbacks, value copies and host failure records |
| [`src/result.ts`](src/result.ts) | Final values, console formatting and failure diagnostics |
| [`src/realm.ts`](src/realm.ts) | Lossless-JSON materialization across VM realms |
| [`src/meta.ts`](src/meta.ts) | Metadata validation and normalization |
| — | No runtime invariant companion is published; the workflow service owns event pairing and PTC owns managed-process observations. |

### Values and child ownership

Root results copy enumerable data without prototype methods or toJSON. Functions, unreadable properties, symbol keys and __proto__ are omitted; arrays retain dense undefined slots until JSON transport writes null. Undefined and symbol properties disappear, and nonfinite numbers render as null. Root undefined remains absent, distinct from explicit null. Root functions, BigInt, symbols, cycles and arrays above 4096 entries fail. Nested workflow returns use the VM copier without root JSON validation, allowing the parent to consume BigInt or cyclic data before returning its own result. Input validation and the generic PTC transport retain their lossless-JSON contract.

Console methods render string arguments directly and other values as JSON when possible, with guest string conversion for empty objects and functions. Unsupported values use type labels; warn and error add their level prefix. Script failures read string name, message and stack independently; they never call arbitrary toString methods. Diagnostics retain five stack frames capped at 500 characters each and shorten long text with a counted middle marker.

The host tracks pending provider starts separately from published children. A shared abort signal closes both paths; a child that becomes ready after cancellation is disposed. Each published child's disposal is shared by all cleanup paths. In-flight host bindings remain the workflow adapter's responsibility after PTC stops the program.

### Cancellation and outcomes

The first accepted terminal outcome owns the run result. Cancellation stops the process immediately rather than waiting for a guest acknowledgement. Process settlement and child cleanup remain separate obligations; public disposal waits for both. Existing workflow start/end pairing and child lifecycle projection remain intact.

</details>

-----

<a id="further-exploration"></a>
## Further Exploration

Use these references for the shared execution guarantees and workflow contracts.

- [Workflow subsystem](../../../docs/subsystems/workflow.md) — request, result and event definitions.
- [Workflow service](../workflow/README.md) — caller-owned runs and cleanup.
- [Node PTC runtime](../../ptc-runtime/ptc-runtime-node/README.md) — file policy, process limits and deployment choices.
- [workflow tool](../tool-workflow/README.md) — model-facing scripted orchestration.
- [Ralph tool](../tool-ralph/README.md) — opt-in fixed fresh-agent iteration.
- [Workflow sandbox reuse](../../../.agents/notes/implemented/architecture/2026-09-13-workflow-ptc-sandbox-reuse.md) — execution ownership and tradeoffs.

-----

<a id="model-experience"></a>
## Model Experience

### Child-agent requests

#### What the model sees

Every script `agent()` call sends its computed prompt inside a host-written attribution frame, with every computed line indented. Origin framing relays user requests up to 4000 characters and assistant/automated context up to 2000 characters. It sends the framed prompt and optional model or structured-output schema to a subagent provider. Each child sees that provider's own context; phase and log narration stays on observer events.

#### Token effect

Each child consumes its own model context. Cooperative concurrency, total-agent and item caps limit ordinary script fan-out; child histories do not join the parent history directly.

#### KV Cache effect

The parent request cache stays independent. Matching child prefixes share a bounded warmup wait; reuse still depends on the model provider accepting a byte-identical prefix.

### Parent tool result, indirectly

#### What the model sees

The tool consumer presents the final JSON value and child count, or a workflow failure. Intermediate child outputs remain available to the script. Script parsing, helper misuse, child infrastructure failures and PTC execution failures produce errors; ordinary unstructured child failures and provider API failures produce null. Missing structured output and exhausted validation reject; scripts can catch those errors, while parallel and pipeline convert uncaught item errors to null. Explicit skips return null.

#### Token effect

The engine adds no direct parent tokens. PTC bounds the outer program result, and the tool consumer owns its model-facing rendering and retention.

#### KV Cache effect

Append-only; newly visible content follows the reusable request prefix.

## Known Limitations and Deferred Work

<a id="known-limitations-and-deferred-work"></a>

These limits qualify workflow execution and cleanup.

- **File confinement and cleanup inherit provider limits** — the Node PTC and subprocess providers define enforcement completeness and the managed process range.
- **Resource accounting** — the host enforces child admission and concurrency, but in-flight model requests may overshoot the run output-token allowance.
- **No overall elapsed deadline** — a run can remain active until it completes, fails or is cancelled. Caller deadlines still apply.
- **Child cleanup follows provider contracts** — the adapter awaits disposal and pending starts without a separate abandonment timer.
- **The VM is not a security boundary** — withheld globals guide script authors; OS policy governs code that reaches Node.
- **Cross-realm errors fail `instanceof Error` inside scripts** — branch on stable fields such as `name` and `message`.

<a id="dev-note"></a>
### Dev Note

<details>
<summary>Working context for maintainers — click to expand</summary>

None.

</details>
