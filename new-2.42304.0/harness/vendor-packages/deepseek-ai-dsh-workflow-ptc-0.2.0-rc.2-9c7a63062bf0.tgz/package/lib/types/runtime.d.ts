/**
 * Workflow VM hooks, child callbacks, ordinary concurrency limits and result serialization.
 * PTC owns process confinement and cancellation. Combinators await all items and contain
 * per-item errors as null; uncaught errors outside combinators fail the script.
 * @module @deepseek-ai/dsh-workflow-ptc/runtime
 */
import type { WorkflowAgentAdmissionInfo, WorkflowAgentEndInfo, WorkflowAgentInfo, WorkflowAgentProgressInfo, WorkflowMeta, WorkflowPhaseInfo, WorkflowResult } from '@deepseek-ai/dsh-workflow';
import type { ChildPort, WorkerInit, WorkerLimits, JournalEntry } from './types.ts';
/** The observers the execution reports progress through (the session posts them to the host). */
export interface ExecutionObserver {
    phase(title: string, phase: WorkflowPhaseInfo): void;
    log(message: string): void;
    agentAdmission?(info: WorkflowAgentAdmissionInfo): void;
    agentStart(info: WorkflowAgentInfo): void;
    agentProgress?(info: WorkflowAgentProgressInfo): void;
    agentEnd(info: WorkflowAgentEndInfo): void;
}
/**
 * One script execution inside the confined Node process. The host owns
 * cancellation and cleanup of any dropped child work.
 */
interface ExecutionState {
    started: number;
    activeSlots: number;
    slotWaiters: (() => void)[];
    resume: JournalEntry[] | undefined;
    spent: number;
    previousKey: string;
}
/** One VM execution sharing admission and cancellation with any nested workflow. */
export declare class WorkflowExecution {
    private readonly limits;
    private readonly observer;
    private readonly children;
    private readonly init;
    private readonly childPhase?;
    /** 1-based count of `agent()` calls started (the `agentsStarted` result field). */
    private readonly state;
    private currentPhase;
    private readonly context;
    private readonly boundary;
    private readonly timers;
    private nextTimer;
    private readonly compiled;
    private readonly root;
    private readonly sharedGlobals;
    private readonly childCounts;
    private readonly phases;
    private readonly schemas;
    constructor(meta: WorkflowMeta, body: string, args: unknown, limits: WorkerLimits, observer: ExecutionObserver, children: ChildPort, init?: Pick<WorkerInit, 'resume' | 'depth' | 'budget' | 'workflows'>, shared?: ExecutionState, parent?: WorkflowExecution, childPhase?: string | undefined);
    /**
     * Run the script and materialize its JSON return value.
     * @returns A completed or error result; script failures never reject.
     */
    drive(): Promise<WorkflowResult>;
    /**
     * Attach a no-op rejection consumer WITHOUT changing what the caller
     * receives: if the script drops the promise, a host rejection cannot become
     * an unhandled rejection that kills the process; if
     * the script does await it, it still observes the rejection.
     */
    private contain;
    /** Acquire one concurrency slot in FIFO order. */
    private acquireSlot;
    private releaseSlot;
    /** The `agent(prompt, opts)` hook. */
    private agent;
    /** Materialize + validate the `agent()` options bag from the realm. */
    private readAgentOptions;
    /** Execute one registered child script with the same slots, call count, journal prefix and budget. */
    private nested;
    /** Validate the dense task snapshot before invocation; each task failure becomes null. */
    private parallel;
    /** The `pipeline(items, ...stages)` hook: per-item stage chains, NO cross-stage barrier. */
    private pipeline;
    private snapshotItems;
    private assertAdmission;
    private announcePhase;
    /** The `phase(title)` hook: sets the current label for subsequent `agent()` calls and notifies observers. */
    private phase;
    /** The `log(message)` hook: narration to observers. */
    private log;
    private displayValue;
}
export {};
//# sourceMappingURL=runtime.d.ts.map