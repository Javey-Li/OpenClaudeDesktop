/** Host-owned attribution for script-computed tasks and optional origin context. */
import type { WorkflowStartRequest } from '@deepseek-ai/dsh-workflow';
/** Render computed text as script output, never as user consent or instructions from the host.
 * @param prompt - Computed task text; each line is indented beneath the host frame.
 * @param origin - Optional host-owned context; user requests over 4000 characters and other fields over 2000 are omitted.
 * @returns Framed task with explicitly attributed origin context.
 */
export declare function frameComputedTask(prompt: string, origin: WorkflowStartRequest['origin']): string;
//# sourceMappingURL=prompt-frame.d.ts.map