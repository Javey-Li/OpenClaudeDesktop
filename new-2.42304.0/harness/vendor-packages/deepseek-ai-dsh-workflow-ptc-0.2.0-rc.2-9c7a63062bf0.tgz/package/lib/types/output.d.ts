/** Complete Claude Workflow output files, independent of transcript rendering limits. */
/** Native phase record; reserved child groups retain their index before announcement. */
export interface OutputPhase {
    type: 'workflow_phase';
    index: number;
    title: string;
    kind?: 'child';
}
/** One execution's phase identity, shared by root and child scripts. */
export declare class WorkflowPhases {
    private readonly phases;
    private readonly announced;
    /** Reserve an index without displaying the phase.
     * @param title - Normalized phase title, including an empty title.
     * @param kind - Kind on the first reservation; later calls preserve it.
     * @returns Stable one-based phase record.
     */
    reserve(title: string, kind?: 'child'): OutputPhase;
    /** Announce a reserved phase once, before its first agent enters the queue.
     * @param title - Normalized phase title.
     * @param emit - Receives the first announcement only.
     * @returns Stable one-based index.
     */
    announce(title: string, emit: (phase: OutputPhase) => void): number;
}
/** Observed agent fields; providers leave unavailable measurements absent. */
export interface OutputAgent {
    label?: string;
    phaseIndex?: number;
    phaseTitle?: string;
    agentId?: string;
    agentType?: string;
    isolation?: string;
    model?: string | undefined;
    state?: 'start' | 'done' | 'error' | 'skipped';
    startedAt?: number;
    queuedAt?: number;
    attempt?: number;
    cached?: boolean;
    lastToolName?: string;
    lastToolSummary?: string;
    promptPreview?: string | undefined;
    promptFramed?: boolean;
    lastProgressAt?: number;
    tokens?: number;
    toolCalls?: number;
    durationMs?: number;
    resultPreview?: string | undefined;
    error?: string;
}
/** Normalize explicit labels, or truncate the prompt to 60 UTF-16 units before collapsing whitespace.
 * @param prompt - Agent prompt before task framing.
 * @param label - Explicit display label; nullish values use the prompt.
 * @returns Display label without an ellipsis or split surrogate pair.
 */
export declare function workflowLabel(prompt: string, label?: unknown): string;
/** Trim diagnostic previews to 400 UTF-16 units without splitting a surrogate pair.
 * @param value - A JSON-compatible result or prompt.
 * @returns Nonempty preview, absent for nullish or blank values.
 */
export declare function workflowPreview(value: unknown): string | undefined;
/** Accumulates ordered native diagnostic records for one execution attempt. */
export declare class WorkflowOutput {
    private readonly summary;
    private readonly logs;
    private readonly phases;
    private readonly agents;
    private readonly progress;
    private readonly announced;
    constructor(summary: string);
    /** Reserve a group without displaying it until it contains work.
     * @param title - Normalized phase title.
     * @param kind - Child Workflow marker, when applicable.
     * @returns Stable one-based index.
     */
    reservePhase(title: string, kind?: 'child'): number;
    /** Announce a phase once, preserving first-appearance order.
     * @param title - Normalized phase title.
     * @param kind - Child Workflow marker, when applicable.
     * @param details - Execution-assigned identity when supplied by a runtime.
     * @returns Stable one-based index.
     */
    phase(title: string, kind?: 'child', details?: {
        index: number;
        kind?: 'child';
    }): number;
    /** Retain the script's already formatted log line.
     * @param message - Complete Workflow log message.
     */
    log(message: string): void;
    /** Merge observations for one admitted call without reordering its row.
     * @param index - One-based invocation sequence.
     * @param fields - Available agent observations; undefined fields are omitted from JSON.
     */
    agent(index: number, fields: OutputAgent): void;
    /** Render full successful output; failures and cancellation leave an empty file.
     * @param result - Settled script outcome after child cleanup.
     * @returns Pretty JSON without a trailing newline, or an empty string.
     */
    render(result: {
        stopReason: string;
        value?: unknown;
        agentsStarted: number;
    }): string;
}
//# sourceMappingURL=output.d.ts.map