import type { ChildStartRequest, JournalEntry } from './types.ts';
/** Hash a JSON input without copying prompts into guest initialization.
 * @param value - JSON value to hash with stable object key ordering.
 * @returns Hexadecimal SHA-256 digest.
 */
export declare function digest(value: unknown): string;
/** Derive a call's journal key from its raw computed prompt and normalized options.
 * @param request - Computed prompt, options and nested execution scope.
 * @returns Digests used to compare one settled journal entry.
 */
export declare function callKey(request: ChildStartRequest): Pick<JournalEntry, 'promptHash' | 'optsHash'>;
//# sourceMappingURL=call-key.d.ts.map