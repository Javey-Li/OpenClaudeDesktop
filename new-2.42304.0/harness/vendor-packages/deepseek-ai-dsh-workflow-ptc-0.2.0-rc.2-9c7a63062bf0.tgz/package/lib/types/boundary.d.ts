/**
 * Guest-local callbacks, value copies and host-call error records.
 * Process confinement remains the responsibility of the PTC provider.
 * @module @deepseek-ai/dsh-workflow-ptc/boundary
 */
/** String-only failure fields read in the script VM. */
export interface WorkflowErrorInfo {
    name: string;
    message: string;
    stack: string;
}
/** Helpers created in one workflow's VM; values never share copies across calls. */
export interface WorkflowBoundary {
    /**
     * Read an object-valued schema in this VM, containing failed getters.
     * @param options - A child agent options bag.
     * @returns The original schema reference, or undefined.
     */
    readSchema(options: unknown): object | undefined;
    /**
     * Copy enumerable data into this VM, preserving aliases and cycles.
     * @param value - Data to copy.
     * @returns Guest data; functions become undefined.
     */
    clone(value: unknown): unknown;
    /**
     * Convert a value inside the VM, containing failed conversion hooks.
     * @param value - Value to stringify.
     * @returns Its string or a fixed unprintable label.
     */
    toString(value: unknown): string;
    /**
     * Read failure fields independently without invoking toString.
     * @param error - Thrown value.
     * @returns Name, message and stack strings.
     */
    errorInfo(error: unknown): WorkflowErrorInfo;
    /**
     * Invoke a callback from this VM's stack with VM-owned arguments.
     * @param callback - Guest callback.
     * @param args - Arguments passed without cloning.
     * @returns The unassimilated callback result.
     */
    call(callback: (...args: unknown[]) => unknown, ...args: unknown[]): unknown;
    /**
     * Resolve in this VM and box the value to prevent host re-assimilation.
     * @param value - Value or thenable.
     * @returns A null-prototype record containing the settled value.
     */
    settle(value: unknown): Promise<{
        value: unknown;
    }>;
    /**
     * Wrap a host hook in a guest Promise and consume dropped rejections.
     * @param callback - Host hook with normalized errors.
     * @returns A guest callable with a rejection observer.
     */
    asyncWrap(callback: (...args: unknown[]) => unknown): (...args: unknown[]) => Promise<unknown>;
    /**
     * Read dense slots without consulting custom iteration methods.
     * @param value - Array-like input.
     * @param maximum - Maximum supported length.
     * @returns One slot per index; failed reads become undefined.
     */
    snapshot(value: unknown, maximum: number): unknown[];
}
/** Install after intrinsic hardening; evaluate once for each script VM. */
export declare const WORKFLOW_BOUNDARY_SOURCE: string;
/** First schema copies are retained by reference within one script's agent hook. */
export declare class WorkflowSchemaMemo {
    private readonly values;
    /**
     * Copy root options and retain own data-property schema references.
     * @param options - Original script options.
     * @param copy - The root options copier.
     * @param isProxy - The runtime's proxy detector; proxy bags do not memoize.
     * @returns Copied options with the first schema copy for this reference.
     */
    root(options: unknown, copy: (value: unknown) => unknown, isProxy: (value: object) => boolean): unknown;
    /**
     * Retain a child's first schema copy before forwarding to the root hook.
     * @param options - Original child options, including accessor/proxy bags.
     * @param boundary - The child's copier and schema reader.
     * @returns Copied options with the schema reference retained for this child.
     */
    child(options: unknown, boundary: Pick<WorkflowBoundary, 'clone' | 'readSchema'>): unknown;
}
/**
 * Expose a synchronous host hook with no inherited host methods.
 * @param callback - Host implementation; thrown values become immutable error records.
 * @returns A callable with a null prototype.
 */
export declare function wrapWorkflowHostCall(callback: (...args: unknown[]) => unknown): (...args: unknown[]) => unknown;
/**
 * Normalize asynchronous host failures before creating a guest Promise wrapper.
 * @param callback - Host implementation whose result may be a Promise.
 * @returns A callable with a null prototype and immutable rejection records.
 */
export declare function wrapWorkflowHostAsync(callback: (...args: unknown[]) => unknown): (...args: unknown[]) => Promise<unknown>;
//# sourceMappingURL=boundary.d.ts.map