/** Parse workflow bodies and normalize asynchronous values inside the script realm. */
/** Capture the guest Promise resolver before script code can replace global bindings. */
export declare const WORKFLOW_ASYNC_INIT_SOURCE = "Object.defineProperty(globalThis, '__wRg$resolve', {\n  value: Promise.resolve.bind(Promise), writable: false, enumerable: false, configurable: false,\n})";
/**
 * Compile a body into a strict async expression with guest-local value resolution.
 * @param body - JavaScript following the separately decoded metadata declaration.
 * @returns JavaScript to compile with node:vm after installing WORKFLOW_ASYNC_INIT_SOURCE.
 * @throws SyntaxError for invalid JavaScript, reserved identifiers, imports or await-using declarations.
 */
export declare function compileWorkflowBody(body: string): string;
//# sourceMappingURL=compiler.d.ts.map