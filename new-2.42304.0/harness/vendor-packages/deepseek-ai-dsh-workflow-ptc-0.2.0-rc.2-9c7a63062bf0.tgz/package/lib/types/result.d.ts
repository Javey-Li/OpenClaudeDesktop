/**
 * Workflow result conversion, console formatting and script failure text.
 * @module @deepseek-ai/dsh-workflow-ptc/result
 */
import type { WorkflowBoundary, WorkflowErrorInfo } from './boundary.ts';
/**
 * Copy a completed root result and validate its JSON rendering without invoking source toJSON methods.
 * @param value - Settled script value.
 * @param boundary - Helpers belonging to the script VM.
 * @returns Host data; undefined, nonfinite numbers and undefined properties survive until JSON transport.
 */
export declare function workflowResultValue(value: unknown, boundary: WorkflowBoundary): unknown;
/**
 * Format console arguments with guest-owned property reads and conversion hooks.
 * @param values - Values passed to one console method.
 * @param boundary - Helpers belonging to the script VM.
 * @returns Space-separated text, including empty fields for undefined and symbols.
 */
export declare function workflowConsoleText(values: unknown[], boundary: WorkflowBoundary): string;
/**
 * Collapse long diagnostics while retaining counts from prior truncation markers.
 * @param text - Diagnostic field or rendered failure.
 * @returns Text retaining both ends and complete UTF-16 pairs.
 */
export declare function truncateWorkflowDiagnostic(text: string): string;
/**
 * Render a script failure's string fields, retaining at most five bounded stack frames.
 * @param info - Fields read inside the script VM without calling arbitrary toString methods.
 * @returns A diagnostic whose header and total text are each capped with retained ends.
 */
export declare function workflowErrorText(info: WorkflowErrorInfo): string;
//# sourceMappingURL=result.d.ts.map