/** Session-owned backup records and their host-only incremental projection. */
import { z } from 'zod';
import { SessionId } from '@deepseek-ai/dsh-session';
import { WorkflowAttemptId, WorkflowRunId } from '@deepseek-ai/dsh-workflow';
import type { JournalEntry } from './types.ts';
/** Private reusable source; external user files have no backup source entry. */
export interface WorkflowMirrorSource {
    fileName: string;
    script: string;
}
/** Latest execution data retained independently of the private journal directory. */
export interface WorkflowMirrorSnapshot {
    attemptId: WorkflowAttemptId;
    provider: string;
    source?: WorkflowMirrorSource;
    entries: JournalEntry[];
}
/** A committed backup update attributed to its original owning Session. */
export interface WorkflowMirrorData {
    sessionId: SessionId;
    runId: WorkflowRunId;
    attemptId: WorkflowAttemptId;
    record: {
        kind: 'start';
        provider: string;
        source?: WorkflowMirrorSource;
    } | {
        kind: 'entry';
        entry: JournalEntry;
    };
}
/** Host-only projection; inherited events never grant a child Session recovery rights. */
export interface WorkflowMirrorState {
    owner: SessionId;
    runs: Record<string, WorkflowMirrorSnapshot>;
}
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /** Private workflow recovery data; not model-visible or a user instruction. */
        'workflow-ptc/mirror': WorkflowMirrorData;
    }
}
declare module '@deepseek-ai/dsh-session-projection/types' {
    interface SessionProjectionStateMap {
        /** Latest same-Session workflow source and invocation backups. */
        workflowMirror: WorkflowMirrorState;
    }
}
/** Reconstruct only the latest attempt; late entries from earlier attempts stay isolated. */
export declare const workflowMirrorDefinition: {
    key: "workflowMirror";
    stateVersion: number;
    stateSchema: z.ZodType<WorkflowMirrorState, unknown, z.core.$ZodTypeInternals<WorkflowMirrorState, unknown>>;
    init: (header: import("@deepseek-ai/dsh-session").SessionHeader) => {
        owner: SessionId;
        runs: {};
    };
    apply: (state: NoInfer<WorkflowMirrorState>, event: import("@deepseek-ai/dsh-session").SessionEvent) => WorkflowMirrorState;
};
//# sourceMappingURL=mirror.d.ts.map