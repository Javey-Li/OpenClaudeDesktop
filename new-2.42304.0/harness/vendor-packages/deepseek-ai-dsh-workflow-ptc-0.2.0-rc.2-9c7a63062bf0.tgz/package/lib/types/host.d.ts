/** Workflow child ownership and progress over the shared sandboxed PTC executor. */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { PtcRuntime } from '@deepseek-ai/dsh-ptc-runtime';
import type { SandboxExecutionPolicy } from '@deepseek-ai/dsh-sandbox';
import type SubagentRuntime from '@deepseek-ai/dsh-subagent';
import type { WorkflowMeta, WorkflowResult, WorkflowRun, WorkflowRunId, WorkflowStartRequest } from '@deepseek-ai/dsh-workflow';
import { Journal } from './journal.ts';
import type { ExecutionObserver } from './runtime.ts';
import type { WorkerInit } from './types.ts';
/**
 * Holder-owned workflow. Cancellation stops the program immediately; settlement waits for
 * its managed process and every admitted child startup/disposal. Engine unload does not
 * invalidate the captured runtime or subagent handles.
 */
export declare class PtcWorkflowRun implements WorkflowRun {
    private readonly ctx;
    private readonly subagents;
    private readonly runtime;
    readonly id: WorkflowRunId;
    readonly meta: WorkflowMeta;
    private readonly parent;
    private readonly init;
    private readonly provider;
    private readonly policy;
    private readonly observer;
    private readonly signal?;
    private readonly journal?;
    private readonly origin?;
    private readonly progressIntervalMs;
    private readonly stallMs;
    private readonly maxStallRetries;
    private readonly resolveWorkflow?;
    private readonly rateLimitRetries;
    private readonly rateLimitDelayMs;
    private readonly sharedBudget?;
    readonly result: Promise<WorkflowResult>;
    private readonly controller;
    private readonly children;
    private readonly pending;
    private readonly liveAgents;
    private readonly output;
    private readonly outputAgents;
    private readonly admissions;
    private started;
    private spent;
    private readonly projections;
    private readonly warmup;
    private rateLimitWaits;
    private rateLimitUntil;
    private activeSlots;
    private readonly waiters;
    private readonly accepted;
    private resumeCutoff;
    readonly scriptPath: string;
    readonly transcriptDir?: string;
    get outputFile(): string | undefined;
    readonly attemptId?: Journal['attemptId'];
    private terminal;
    private cancelReason;
    private disposed;
    private readonly externalAbort;
    private readonly unsubscribe;
    constructor(ctx: Context, subagents: SubagentRuntime, runtime: PtcRuntime, id: WorkflowRunId, meta: WorkflowMeta, parent: Agent, init: WorkerInit, provider: string, policy: SandboxExecutionPolicy, observer: ExecutionObserver, signal?: AbortSignal | undefined, journal?: Journal | undefined, origin?: WorkflowStartRequest['origin'], progressIntervalMs?: number, stallMs?: number, maxStallRetries?: number, resolveWorkflow?: WorkflowStartRequest['resolveWorkflow'], rateLimitRetries?: number, rateLimitDelayMs?: number, sharedBudget?: {
        spent(): number;
        charge(tokens: number): void;
        observe(read: () => number): () => void;
    } | undefined, warmupWaitMs?: number, warmupTtlMs?: number);
    /**
     * Stop the script and abort pending and published children.
     * @param reason - Human-readable cancellation cause; the first request wins.
     */
    cancel(reason?: string): void;
    /**
     * Cancel unfinished work and await the program and child cleanup.
     * @returns One shared completion promise for repeated disposal calls.
     */
    dispose(): Promise<void>;
    /** Apply a user action to a currently running attempt. */
    controlMember(seq: number, action: 'skip' | 'retry'): boolean;
    private armStall;
    private requireActive;
    private childFor;
    private touch;
    private usage;
    private publishProgress;
    private track;
    private bindings;
    private child;
    private reply;
    private admit;
    private currentSpent;
    private unsettledUsage;
    private slot;
    private releaseSlot;
    private outputAgent;
    private acceptCachedChild;
    private startChild;
    private childResult;
    private settleChild;
    private disposeChild;
    private onProgress;
    private admission;
    private endAgent;
    private cancelled;
    private drive;
}
//# sourceMappingURL=host.d.ts.map