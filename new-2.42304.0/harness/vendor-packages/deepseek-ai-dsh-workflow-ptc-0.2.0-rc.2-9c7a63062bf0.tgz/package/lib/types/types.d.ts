/**
 * Workflow guest inputs and the child callbacks consumed by its VM helpers.
 * PTC transfers initialization data, requests and results as lossless JSON.
 * @module @deepseek-ai/dsh-workflow-ptc/types
 */
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { StructuredOutputSchema } from '@deepseek-ai/dsh-subagent';
import type { WorkflowMeta } from '@deepseek-ai/dsh-workflow';
/**
 * Ordinary script limits enforced by the guest helpers.
 */
export interface WorkerLimits {
    /** Concurrent `agent()` ceiling (already auto-resolved; ≥ 1). */
    maxConcurrentAgents: number;
    /** Total `agent()` calls per run (the runaway-loop backstop). */
    maxTotalAgents: number;
    /** Items accepted by one `parallel()`/`pipeline()` call. */
    maxItemsPerCall: number;
    /** VM timeout for the script's initial synchronous slice. */
    syncTimeoutMs: number;
}
/** The initialization data returned by the host before the script runs. */
export interface WorkerInit {
    /** The validated meta block (plain data off the start request, validated host-side). */
    meta: WorkflowMeta;
    /** The plain-JS script body, exactly as the start request carried it. */
    body: string;
    /** The run's `args` value, copied through the PTC JSON channel. */
    args?: unknown;
    /** The guest helper limits. */
    limits: WorkerLimits;
    resume?: {
        runId: string;
        entries: JournalEntry[];
    };
    depth?: number;
    budget?: {
        total: number | null;
        spent?: number;
        refreshMs?: number;
    };
    workflows?: Record<string, {
        script: string;
        meta: WorkflowMeta;
    }>;
}
/** One `agent()` child request after the guest validates script options. */
export interface ChildStartRequest {
    /** Guest invocation identity; checked and counted by the host. */
    seq?: number;
    /** Complete normalized options used to compare journal entries. */
    options?: AgentOptions;
    /** Nested source identity, empty for top-level calls. */
    scope?: string;
    /** Hash of all preceding invocation identities, independent of completion order. */
    previousKey?: string;
    effort?: AgentOptions['effort'];
    isolation?: 'worktree';
    agentType?: string;
    /** The child's prompt text. */
    prompt: string;
    /** The structured-output schema, if the call passed one (already subset-checked). */
    schema?: StructuredOutputSchema;
    /** The per-child provider override, if the call passed one. */
    provider?: string;
    /** The per-child model override, if the call passed one. */
    model?: string;
}
/**
 * The JSON projection of a child's `SubagentResult`. The
 * seam's `stopReason` union is merge-extensible, so it degrades to `string`
 * on the wire. Completed, max-turns, and hook-stopped results retain their output.
 */
export interface ChildResult {
    /** The child's final assistant output blocks. */
    output: ContentBlock[];
    /** The structured value, present iff the request carried a schema AND the provider honored it. */
    structured?: unknown;
    /** Why the child run ended; completed, max-turns, and hook-stopped retain their output. */
    stopReason: string;
    budgetSpent?: number;
    tokens?: number;
    outputTokens?: number;
    error?: string;
    /** Provider-owned terminal failure classification, separate from display text. */
    failure?: {
        code: string;
        status?: number;
    };
    durationMs?: number;
}
/**
 * The guest handle for one published child, reduced to what the VM helpers consume.
 */
export interface ChildHandle {
    /** The child agent's id (minted host-side by the subagent seam). */
    readonly id: string;
    /**
     * Resolves with the child's terminal {@link ChildResult}; REJECTS only when
     * the host reports an infrastructure fault; a child that
     * failed for its own reasons resolves with a non-`completed` stop reason.
     */
    readonly result: Promise<ChildResult>;
    /** Ask the host to dispose the child; resolves on the host's ack. */
    dispose(): Promise<void>;
}
/**
 * Child callbacks independent of the PTC transport.
 */
export interface ChildPort {
    /** Refresh turn-wide output usage while parallel children are still running. */
    readBudget?(): Promise<number>;
    /**
     * Start one child agent on the host (the `agent()` hook's start half).
     * @param request - the prompt and validated options.
     * @returns the published child handle; rejects when synchronous start or the
     *   provider's asynchronous start fails.
     */
    startAgent(request: ChildStartRequest): Promise<ChildHandle>;
    /** Queue host verification before the cached call's ordered lifecycle observations. */
    cachedAgent?(request: ChildStartRequest): void;
    /** Resolve a nested name or explicit path through the host's registry. */
    resolveWorkflow?(source: {
        name?: string;
        scriptPath?: string;
    }): Promise<{
        script: string;
        meta: WorkflowMeta;
    }>;
}
/** One settled agent call, indexed by invocation order rather than completion order. */
export interface JournalEntry {
    seq: number;
    promptHash: string;
    optsHash: string;
    value: unknown;
    childId: string;
    outcome: 'started' | 'completed' | 'failed';
}
/** The script-visible options after validation. */
export interface AgentOptions {
    label?: string;
    phase?: string;
    schema?: StructuredOutputSchema;
    provider?: string;
    model?: string;
    effort?: 'low' | 'medium' | 'high' | 'xhigh' | 'max';
    isolation?: 'worktree';
    agentType?: string;
    stallMs?: number;
    disallowedTools?: string[];
    bashCommandClamp?: string[];
}
//# sourceMappingURL=types.d.ts.map