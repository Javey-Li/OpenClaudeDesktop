/** Per-workflow cache of leaders whose first response warms a shared prompt prefix. */
export declare class PrefixWarmup {
    private readonly waitMs;
    private readonly ttlMs;
    private readonly entries;
    constructor(waitMs: number, ttlMs: number);
    /** Followers wait for the leader's first response, bounded by the configured window.
     * @param key - Stable prompt-prefix identity shared by matching child requests.
     * @param signal - Cancels a follower's wait.
     * @returns Idempotent completion callback; false evicts a leader that received no response.
     */
    enter(key: string, signal: AbortSignal): Promise<(responded: boolean) => void>;
}
//# sourceMappingURL=warmup.d.ts.map