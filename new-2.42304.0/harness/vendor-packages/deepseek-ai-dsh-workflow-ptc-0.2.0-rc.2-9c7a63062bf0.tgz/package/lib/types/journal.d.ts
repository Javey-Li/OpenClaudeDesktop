import { WorkflowAttemptId } from '@deepseek-ai/dsh-workflow';
import type { WorkflowMeta } from '@deepseek-ai/dsh-workflow';
import type { JournalEntry } from './types.ts';
import type { WorkflowMirrorData, WorkflowMirrorSnapshot } from './mirror.ts';
/** A new run's private script and append-only call results. */
export declare class Journal {
    /** Absolute path of the reusable script, including its literal meta header. */
    readonly scriptPath: string;
    /** Private directory retaining every execution journal for this run. */
    readonly directory: string;
    /** Complete settled output; absent until its flushed file has been published. */
    outputFile?: string;
    /** Isolates this execution from earlier holders of the same run. */
    readonly attemptId: WorkflowAttemptId;
    private readonly file;
    private readonly mirror;
    constructor(root: string, sessionId: string, runId: string, script: string, meta: WorkflowMeta, provider: string, sourcePath?: string, mirror?: {
        publish: (attempt: WorkflowAttemptId, record: WorkflowMirrorData['record']) => void;
        sourceFileName?: string | undefined;
    });
    /** Append call start or settlement durably, including null child failures.
     * @param entry - Validated lossless JSON result and call identity.
     */
    append(entry: JournalEntry): void;
    /** Save complete terminal output independently of model rendering caps.
     * @param text - Complete diagnostic JSON, or empty output for a failed or cancelled run.
     */
    finish(text: string): void;
    /** Load the invocation chain including interrupted starts; an interrupted final line is ignored.
     * @param root - Configured private journal root.
     * @param sessionId - Required owning Session identity.
     * @param runId - Previous run identity.
     * @param provider - Required subagent provider route.
     * @returns Contiguous settled calls starting at sequence one.
     * @throws WorkflowError when the journal is missing, malformed or owned elsewhere.
     */
    static resume(root: string, sessionId: string, runId: string, provider: string): JournalEntry[];
    /** Restore missing private files from the latest retained same-Session execution.
     * @param root - Configured host journal directory.
     * @param sessionId - Owner whose projection supplied the backup.
     * @param runId - Validated run identity.
     * @param provider - Required child-provider route.
     * @param snapshot - Latest retained attempt, absent when mirroring was unavailable.
     * @param requestedFileName - Matching private source requested by the caller, never an arbitrary target path.
     * @param warn - Receives nonfatal script restoration failures.
     */
    static restore(root: string, sessionId: string, runId: string, provider: string, snapshot: WorkflowMirrorSnapshot | undefined, requestedFileName: string | undefined, warn: (error: unknown) => void): void;
}
//# sourceMappingURL=journal.d.ts.map