---
description: "通过共享的沙箱化 PTC Node 进程运行时执行工作流编排，保留工作流钩子、subagent 路由和调用方拥有的取消能力。"
kind: "package-reference"
---

# @deepseek-ai/dsh-workflow-ptc

[English](README.md) | 中文

## 概述

在全新 Node 进程中按调用 Session 的文件沙箱策略运行 JavaScript 工作流。脚本保留 `agent()`、`parallel()`、`pipeline()`、`phase()` 和 `log()` 钩子，委派的工作由 subagent 完成。同一个执行提供方服务 PTC 与工作流，包括需显式启用的 Ralph 循环。运行没有整体经过时间截止；取消会停止受管进程并释放子 agent。所选沙箱与子进程提供方决定强制能力和清理限制。


## 目录

- [使用本包](#use-this-package)
- [理解实现](#understand-the-implementation)
- [进一步探索](#further-exploration)
- [模型体验](#model-experience)
- [已知限制与延期工作](#known-limitations-and-deferred-work)
- [开发备注](#dev-note)

-----

<a id="use-this-package"></a>
## 使用本包

引擎将可选显示标题与工作流名称分别保留，并接受空字符串阶段标题。CLI 来源规范化由 tool-workflow 负责；直接传入引擎的元数据仍拒绝未知字段。

在提供 subagent、沙箱策略和 [Node PTC 运行时](../../ptc-runtime/ptc-runtime-node/README.zh.md)的组合中挂载本引擎。它为 `dsh-tool-workflow` 及显式启用时的 `dsh-tool-ralph` 提供工作流执行。Ralph 在已发布默认组合中保持禁用。引擎在加载时拒绝非 TypeScript 的 PTC 提供方。Python PTC 组合必须禁用 `workflow-ptc`、`tool-workflow` 以及任何已启用的 `tool-ralph` 条目。

### 最小配置

上述依赖可用后，挂载引擎及其面向模型的消费方：

```yaml
- name: '@deepseek-ai/dsh-workflow-ptc'
- name: '@deepseek-ai/dsh-tool-workflow'
```

| 字段 | 默认值 | 含义 |
|---|---|---|
| `journalDirectory` | `<DSH_HOME>/workflows` | 保存同会话恢复记录与脚本的目录。 |
| `sessionMirror` | `false` | 在所属 Session 日志中保留私有脚本和调用备份。 |
| `provider` | `spawn` | `agent()` 调用使用的宿主侧 subagent 提供方。 |
| `maxConcurrentAgents` | `0` | 并发 `agent()` 上限；`0` 根据可用 CPU 并行度解析。 |
| `maxTotalAgents` | `1000` | 一次运行最多启动的 `agent()` 调用数。 |
| `maxItemsPerCall` | `4096` | 一次 `parallel()` 或 `pipeline()` 调用接受的条目数。 |
| `syncTimeoutMs` | `5000` | 脚本最初同步片段的 VM 超时时间，单位为毫秒。 |

负责运行的消费方可以为一次运行设置 `WorkflowStartRequest.subagentProvider` 并降低 `WorkflowStartRequest.maxTotalAgents`。脚本钩子不能更改这两项选择。进程堆、输出、控制通信和终止限制由 Node PTC 提供方负责；引擎不增加整体经过时间定时器。生成的[配置目录](../../../docs/config-catalog.zh.md#deepseek-aidsh-workflow-ptc)定义可接受的引擎字段。

Node PTC 提供方的 `maxPendingCalls` 也限制工作流并发：子 agent 启动、结果等待与资源释放会占用这些名额。进度批次至多再占用一个名额。设置 `maxConcurrentAgents` 时应预留余量。

### 结果与失败

subagent 提供方声明 `streamToolCalls` 时，Workflow 子代理会启用流式工具执行。完整调用可在响应结束前运行；未完成的参数不会执行。提供方流恢复保留已经执行的结果。已接受终结结果后发生响应失败，会返回失败子代理且不保留结构化值；子代理已经处理工具后，迟到的限流错误不会重新创建子代理。

`pipeline()` 接受 Promise 条目；某阶段返回 `null` 后，该条目不再进入后续阶段。`parallel()` 要求每个槽位都是函数。`phase()` 与 `log()` 将基本值转成字符串，对对象及函数使用类型标记，不调用其转换钩子。本地子代理通过 `workflow/agent-progress` 发出工具活动、流式输出活动和用量，`progressIntervalMs` 默认 250 毫秒。取消时移除订阅与待发送计时器。`tokens` 合计互不重叠的输入、缓存与输出用量，`outputTokens` 单独计入输出预算。

子代理达到定义的 maxTurns 或被自身 hook 停止时，返回保留文本或已接受的结构化值。缺失结构化输出会拒绝脚本调用；正常结束的子代理仍保留完成生命周期。提供方 API 失败以失败生命周期返回 null，而结构化校验次数耗尽以失败生命周期拒绝。结构化失败调用不会从日志中复用。调用方取消仍会中止工作流。

提供方声明 outputSchemaCompletion 能力时，结构化调用会完成当前响应中的全部工具，并采用最后一个有效结果。没有有效结果且达到重试上限时，后续调用仍会停止。其他提供方保留各自声明的结构化输出行为。

脚本以严格模式 JavaScript 执行，支持顶层 `await`；根脚本的 `args` 作为 JSON 数据复制到脚本 realm。元数据描述运行，不是脚本变量。每次 `agent()` 调用使用配置的 subagent 提供方及运行固定的父级。最终经清理的返回值成为运行结果；普通子 agent 失败使 `agent()` 以 `null` 兑现。

编译在发布工作前拒绝导入、`await using` 和以 `__wRg$` 开头的标识符。异步 return、yield 和 await 使用预先捕获的 guest Promise 解析函数。`for await` 与异步生成器委托会解析迭代步骤及其值，包括完成和提前返回的值；无效的迭代器对象、方法或结果抛出 TypeError。迭代方法在开始迭代时捕获。

无效元数据、脚本或路由在发布前拒绝。组合器让出执行后快照每个数组槽位，空洞转为 undefined；执行前校验所有函数。空数组跳过准入与阶段校验，非空调用在代理数或输出预算耗尽时拒绝。逐项异常转为 `null`；组合器外未捕获的异常、PTC 进程或约束故障使运行失败。

宿主钩子返回调用脚本环境内的 Promise。调用失败时暴露冻结的无原型记录，仅含 name、message、stack 和 toString；宿主错误码及自定义字段不向脚本提供。代理数据与组合器最终结果复制为根脚本环境内的对象，同一次复制保留循环与重复引用。复制时略过对象的函数属性、符号键和 __proto__，将无法读取或函数值的数组槽位替换为 undefined，并拒绝超过 4096 项的嵌套数组。流水线阶段在最终复制前保留原始项的引用身份。未处理的钩子拒绝会被消费；计时器回调丢弃同步异常。

### 确定性、恢复与保存的脚本

`Date.now()`、`Math.random()`、`Date()` 和无参 `new Date()` 会抛错；时间或种子由 `args` 传入。显式日期仍可使用，构造器别名不能恢复隐式时钟。内建构造器、原型与命名空间被冻结；Error 子类名称等普通自有字段仍可赋值。动态字符串求值和 WebAssembly 不可用。这些限制指导脚本作者，不使 VM 成为安全边界。

阶段标题（包括空字符串）在每次执行中标识一个分组。元数据声明会公告分组，但不改变当前阶段。phase(title) 设置当前阶段；agent 的显式阶段只属于本次调用。首次预留分配从一开始的编号和 child kind，空子工作流也会预留。公告会去重并先于排队等待；并发源码解析可能以任一完成顺序预留子分组。事件、agent 归属和输出文件传递同一编号。进度消费者按编号排序显示分组，对未指定阶段的 agent 保持归属缺省。

未命中缓存的 agent 调用在等待并发槽位前同步发布排队观察。guest 先发送完这些观察，再请求子代理；发布后更新同一输出行。启动失败保留排队标识和错误，不伪造子代理。缓存调用按调用顺序发布完成行，先于后续阶段调用，不生成排队时间。宿主发布事件前校验调用日志键和子代理标识；校验失败会阻止后续子代理启动，并使运行失败。标签合并空白并保留显式空字符串；缺省标签取提示词前 60 个 UTF-16 单元，避免拆开代理项对。JSON 标签与阶段选项使用字符串转换；空值选择默认标签或当前阶段。

新运行 ID 使用 wf_ 加 UUID 的前十二个字符。ID 是不透明标识符；日志读取器也接受早期 UUID ID。恢复保留运行 ID，并生成独立的 attemptId。上次执行及其子代理完全结束前，恢复会被拒绝。每次执行写独立的 v2 调用日志，由原子替换的 current.json 选择；早期日志保留，旧 journal.jsonl 仍可读取。每次运行保存完整脚本；显式解析的 scriptPath 原样返回，不改写源文件。恢复仅限同会话、同提供方；已记录开始但被中断的调用会重跑，其后已完成的兄弟调用仍可命中缓存。失败或发生变化的调用会使后缀失效。标签、阶段及停滞阈值不影响缓存，命中缓存不消耗新 token。旧 v1 日志可读取，但新调用键使其结果重算。

每次执行在调用日志旁创建空的私有 `<attemptId>.output` 文件。子代理清理后，成功运行发布已刷盘、使用两个空格缩进且不带末尾换行的 JSON，包含 summary、agentCount、logs、可选 result、workflowProgress、totalTokens 和 totalToolCalls。返回 undefined 时省略 result；显式 null 保留为 null。失败和取消运行保留空文件，错误仍由完成事件传递。阶段行保留从一开始的预留编号，按标题去重，并通过 kind:child 标记子工作流。代理行保留实测活动与有长度限制的提示词及结果预览。提供者未报告的用量及对应合计字段会被省略；缓存调用不增加用量。模型渲染限制不截断文件中的结果。发布失败会将运行标记为失败，且不公开其输出文件。使用 Read 读取发布路径可查看诊断信息。

### 预算与嵌套脚本

`budgetTotal` 在父级轮次内计算主代理与兄弟工作流的实时输出用量；轮次外的直接运行使用独立预算。null/省略表示无限，零关闭启动限制（余额仍为零）。宿主在启动及出队时校验实际用量，脚本快照按 `budgetRefreshMs` 刷新。预算只限制新调用，在途请求可能超额。正预算要求远程提供方报告输出用量。

`workflow(name, args?)` 或 `workflow({scriptPath}, args?)` 使用注册定义或宿主 `resolveWorkflow` 回调加载子脚本，最多一层。其他选择器形状以 TypeError 拒绝。子脚本保留 workflow 函数，但调用它会返回被拒绝的 Promise。子脚本共享槽位、计数、代理调用日志链与预算。只有代理提示和执行选项影响此链；未使用的子脚本代码或参数变化不会使其失效。

嵌套参数使用子 VM 复制器，接受循环、BigInt 和符号，不经 JSON 序列化。嵌套返回对象保留子级原型；代理和组合器结果保留根级原型。使用 Array.isArray，避免依赖 realm 的 instanceof 判断。子日志带有 [name] 前缀。内部 phase 调用被忽略，每个子代理使用预留的 ▸ name 分组，下次调用为 ▸ name #2。分组在首个代理通过准入时出现；根脚本使用该预留标题的 phase 调用也会公告分组。所有脚本共享计时器 ID：子脚本返回或失败不会清除计时器，根脚本结束时统一清除。

同一运行中的所有脚本共享原始 budget 对象及包装后的计时器函数。附加到预算函数或计时器上的属性对父级及兄弟脚本可见；重新赋值全局变量只影响当前脚本。其他钩子包装函数属于各自脚本，钩子属性不会进入另一运行。

本地 spawn 支持 `effort`、Claude 格式 `agentType`、Git worktree、`disallowedTools` 和 `bashCommandClamp`。不支持选项的其他提供方必须显式拒绝。活动成员支持跳过及重试；无活动默认 600000 毫秒后最多重试 5 次，工具仍在执行时暂停停滞检测。限流共享等待截止，默认两次等待。相同提示前缀的跟随者等待首个响应或最多 5000 毫秒。

Workflow 子代理始终排除 `Agent`/`Task`、`Workflow` 与 `SendUserMessage`，包括 Harness 中对应的委派、fork 与 Ralph 工具。代理定义及后续作用域注册不能重新开放这些工具。提供方必须支持 `toolFilter`，并在发布子代理前执行其中按精确名称匹配的 `exclude` 列表；不支持时在启动前报错。脚本层 `workflow()` 嵌套仍然可用。

根脚本的 agent 调用会保留自有数据属性中 schema 对象的首次副本；后续修改同一对象不会更新该副本。访问器或代理选项对象不会进入根层引用缓存。每个子脚本在转发到根层前独立保留 schema 引用，包含访问器选项对象。需要改变输出要求时应创建新的 schema 对象；新的根运行与子调用分别使用新的缓存。

### 文件策略与取消

引擎为 PTC 执行解析调用 Session 的常设文件策略与 cwd。VM 保留文档说明的辅助 API，但它不是安全边界：触达 Node 的代码仍受所选 OS 文件策略约束。程序可见的环境为空。文件策略不限制网络访问。

工作流向 PTC 请求 `timeoutMs: null`。最初的 VM 片段仍受 `syncTimeoutMs` 限制，调用方的中止信号仍然生效，包括外层工具的截止。取消立即中止 PTC 进程及待启动或活跃的 subagent。调用方必须释放每次运行并等待子 agent 清理；不另设工作流清理定时器。

-----

启用 sessionMirror 后，每条已刷盘的开始或结果记录也会作为 workflow-ptc/mirror 追加到所属 Session。备份失败只告警，不使主运行失败。仅宿主可见的 workflowMirror 投影保留最新执行，忽略从其他 Session 继承的记录。恢复会使用该投影重建缺失日志和匹配的私有脚本；已有文件不会覆盖，损坏日志不会修复，外部用户脚本不会重建。重启后恢复依赖保留的 Session 持久数据。此后端使用本地 Session 存储，不使用 Claude 账户存储。

<a id="understand-the-implementation"></a>
## 理解实现

`sourceDirectories(parent)` 仅暴露 journalDirectory 下该 Session 的分区。Workflow 工具使用此目录准入返回的私有脚本路径，重新加载后也适用。显式外部源文件不会把所在目录加入该授权。

<details>
<summary>实现细节——点击展开</summary>

工作流引擎负责编排；PTC 提供方负责进程启动、OS 约束、分帧传输与受管进程清理。

### 设计理念

一个自包含的 guest 程序在 PTC Node 进程中运行既有 VM 与工作流辅助函数。Host 绑定将该程序连接到 `ctx.subagents` 和工作流观察器。引擎在运行启动时捕获运行时与 subagent 服务，因此已接受的运行在引擎卸载后仍保有依赖。

### 源码地图

| 文件 | 职责 |
|---|---|
| [`src/index.ts`](src/index.ts) | 引擎配置、请求校验与运行创建 |
| [`src/host.ts`](src/host.ts) | PTC 执行、子 agent 归属、结算与资源释放 |
| [`src/guest.ts`](src/guest.ts) | 基于 PTC Host 绑定的 guest 适配器 |
| [`src/guest-source.ts`](src/guest-source.ts) | 自包含 guest 程序源码 |
| [`src/runtime.ts`](src/runtime.ts) | VM 求值、辅助函数约定与组合器 |
| [`src/intrinsics.ts`](src/intrinsics.ts) | 脚本时钟限制与冻结的 JavaScript 内建对象 |
| [`src/compiler.ts`](src/compiler.ts) | 脚本准入与 guest 内的异步值解析 |
| [`src/boundary.ts`](src/boundary.ts) | 脚本回调、值复制和宿主失败记录 |
| [`src/result.ts`](src/result.ts) | 最终值、控制台格式与失败诊断 |
| [`src/realm.ts`](src/realm.ts) | 跨 VM realm 的无损 JSON 物化 |
| [`src/meta.ts`](src/meta.ts) | 元数据校验与规范化 |
| — | 不发布运行时不变式伴生入口；工作流服务负责事件配对，PTC 负责受管进程观测。 |

### 值与子 agent 归属

根脚本结果复制可枚举数据，不执行原型方法或 toJSON。函数、不可读属性、符号键和 __proto__ 被略过；数组保留密集的 undefined 槽位，JSON 传输时写为 null。undefined 和 symbol 属性消失，非有限数呈现为 null。根 undefined 保持缺失，与显式 null 不同。根函数、BigInt、symbol、循环及超过 4096 项的数组会失败。嵌套工作流返回值使用 VM 复制器，不做根结果的 JSON 校验，父脚本可以先处理 BigInt 或循环数据，再返回自己的结果。输入校验与通用 PTC 传输仍遵循无损 JSON 契约。

Console 方法直接呈现字符串参数，其他值尽量写为 JSON；空对象和函数可在脚本环境内做字符串转换。不支持的值使用类型标签，warn 和 error 添加级别前缀。脚本失败独立读取字符串 name、message 和 stack，不调用任意 toString 方法。诊断保留五条堆栈帧，每条最多 500 字符；长文本使用标注截断字符数的中间标记。

Host 分别跟踪待完成的提供方启动与已发布子 agent。共享中止信号关闭这两条路径；取消后才就绪的子 agent 会被释放。每个已发布子 agent 的资源释放由所有清理路径共享。PTC 停止程序后，进行中的 Host 绑定仍由工作流适配器负责。

### 取消与结果

第一个被接受的终态拥有运行结果。取消立即停止进程，不等待 guest 确认。进程结算与子 agent 清理仍是两项独立义务；公开资源释放操作等待两者。既有工作流开始／结束配对与子 agent 生命周期投影保持不变。

</details>

-----

<a id="further-exploration"></a>
## 进一步探索

共享执行保证与工作流约定见以下参考。

- [工作流子系统](../../../docs/subsystems/workflow.zh.md)——请求、结果和事件定义。
- [工作流服务](../workflow/README.zh.md)——调用方拥有的运行与清理。
- [Node PTC 运行时](../../ptc-runtime/ptc-runtime-node/README.zh.md)——文件策略、进程限制与部署选择。
- [workflow 工具](../tool-workflow/README.zh.md)——面向模型的脚本编排。
- [Ralph 工具](../tool-ralph/README.zh.md)——需显式启用的固定全新 agent 迭代。
- [工作流沙箱复用](../../../.agents/notes/implemented/architecture/2026-09-13-workflow-ptc-sandbox-reuse.zh.md)——执行归属与取舍。

-----

<a id="model-experience"></a>
## 模型体验

### 子 agent 请求

#### 模型看到什么

脚本每次调用 `agent()`，都会由宿主将提示词逐行缩进并加上计算任务来源框架，再发送给 subagent 提供方，并附带可选模型、effort 或结构化输出 schema。每个子 agent 看到该提供方自己的上下文；phase 与 log 叙述只留在观察器事件中。

#### Token 影响

每个子 agent 消耗自己的模型上下文。协作式并发、agent 总数与条目上限限制普通脚本的扇出；子 agent 历史不会直接加入父级历史。

#### KV Cache 影响

与父级请求缓存及同级子 agent 相互独立。每个子 agent 只能在自己的提供方、模型、提示词和 schema 下复用逐字节相同的前缀。

### 父级工具结果（间接）

#### 模型看到什么

工具消费方呈现最终 JSON 值与子 agent 数量，或工作流失败。中间子 agent 输出仍可供脚本使用。脚本解析、辅助函数误用、子 agent 基础设施失败与 PTC 执行失败会产生错误；普通非结构化子 agent 失败及提供方 API 失败产生 null。缺失结构化输出与校验耗尽会拒绝；脚本可以捕获这些错误，parallel 和 pipeline 将未捕获的逐项错误转为 null。显式跳过返回 null。

#### Token 影响

引擎不直接向父级增加 token。PTC 限制外层程序结果，工具消费方负责其面向模型的渲染与保留。

#### KV Cache 影响

仅追加；新增可见内容位于可复用请求前缀之后。

## 已知限制与延期工作

<a id="known-limitations-and-deferred-work"></a>

这些限制界定工作流执行与清理。

- **文件约束与清理继承提供方限制**——Node PTC 与子进程提供方定义强制能力完整度和受管进程范围。
- **启动限额不能中断在途模型输出**——宿主检查并发、调用数和当前输出 token；已经启动的模型请求可能超出预算。
- **没有整体经过时间截止**——运行可以持续到完成、失败或取消。调用方截止仍然适用。
- **子 agent 清理遵循提供方约定**——适配器等待资源释放与待完成启动，不另设放弃等待的定时器。
- **VM 不是安全边界**——不提供的全局变量用于指导脚本作者；OS 策略约束触达 Node 的代码。
- **跨 realm 错误在脚本内无法通过 `instanceof Error`**——根据 `name` 与 `message` 等稳定字段分支。

<a id="dev-note"></a>
### 开发备注

<details>
<summary>维护者的工作上下文——点击展开</summary>

无。

</details>
