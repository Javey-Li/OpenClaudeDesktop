---
description: "Read Claude project settings, enabled plugin component paths, and Markdown metadata."
kind: "package-library"
---

# dsh-claude-code-config

English | [中文](README.zh.md)

## Summary

This library reads declarative Claude configuration through the caller's execution-world filesystem. It loads no plugin executable code and registers no Cordis service. Workflow and subagent providers use the same plugin enablement and install selection.

## Table of Contents

- [Lookup](#lookup)
- [Model Experience](#model-experience)
- [Known Limitations and Deferred Work](#known-limitations-and-deferred-work)
- [Dev Note](#dev-note)

<a id="lookup"></a>
## Lookup

`claudeReadAllowed` reads user (including mapped CLAUDE_CONFIG_DIR), project and local settings, bounded at 2 MiB each. It checks Read deny and ask selectors against every lexical/canonical spelling before granting cwd, additionalDirectories, private directories, explicit Read/Edit allow, or bypass access. A bare Read allow does not grant paths outside working directories. Path patterns use gitignore semantics: // is absolute, ~/ is home, / is relative to the settings source, and other patterns use cwd. Deny/ask negations remain source-local. blockReadsOutsideWorkingDirectories also limits bypass and private-directory grants. Unreadable or malformed settings reject admission. `parseClaudeToolSelector` shares argument-selector parsing with the subagent provider.

`claudeDirectories` returns project-ancestor roots before the mapped user root. `claudePluginSources` merges user, project, and project-local `enabledPlugins` settings, selects a matching local/project/user installation, and returns each component's default directory plus manifest paths. Components are `workflows`, `agents`, and `skills`; manifest paths must remain inside the installed plugin root. Every call rereads configuration, honors cancellation, and limits each JSON file to 1 MiB. JSON parse and containment failures reject the lookup.

`parseClaudeMarkdown` reads JSON-compatible YAML frontmatter and a trimmed instruction body. Callers own file-size limits, component metadata validation, traversal, and name precedence. No invariant companion is published because the library has no retained state or registry contribution to compare.

`harnessToolName` normalizes Claude tool aliases; `claudeToolName` returns the canonical Claude name for hook payloads. Unknown names pass through unchanged.

## Model Experience

None, as this library only reads configuration; consumers own all model-visible instructions and tools.

#### KV Cache effect

The library makes no model requests or cache changes. Its consumers decide when configuration changes alter their request content.

## Known Limitations and Deferred Work

- Read admission does not load managed, CLI, session, or tool-narrowing rule sources; ancestor/git-root settings policy and native rule validation edge cases are not implemented. Private directory ownership is supplied by the consumer.
- Discovery covers installed-registry plugins enabled in user or current-project settings. Managed enterprise policy, command-line plugin directories, built-in plugin catalogs, and synchronized account plugins require their own configuration sources.

<a id="dev-note"></a>
### Dev Note

<details>
<summary>Working context for maintainers — click to expand</summary>

None.

</details>
