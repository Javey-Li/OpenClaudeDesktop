---
description: "读取 Claude 项目设置、已启用插件的组件路径和 Markdown 元数据。"
kind: "package-library"
---

# dsh-claude-code-config

[English](README.md) | 中文

## 概述

此库通过调用方执行环境的文件系统读取 Claude 声明式配置，不加载插件可执行代码，也不注册 Cordis 服务。Workflow 与子代理提供方共享插件启用状态和安装版本选择。

## 目录

- [查找](#lookup)
- [Model Experience](#model-experience)
- [Known Limitations and Deferred Work](#known-limitations-and-deferred-work)
- [开发备注](#dev-note)

<a id="lookup"></a>
## 查找

`claudeReadAllowed` 读取用户（含映射后的 CLAUDE_CONFIG_DIR）、项目和本地设置，每个文件限 2 MiB。它先针对所有词法路径和规范路径检查 Read deny、ask 选择器，再应用 cwd、additionalDirectories、私有目录、显式 Read/Edit allow 或 bypass 授权。裸 Read allow 不授予工作目录外的读取权限。路径规则遵循 gitignore 语义：// 表示绝对路径，~/ 表示主目录，/ 相对设置来源，其余模式相对 cwd。deny/ask 的否定规则只影响同一来源。blockReadsOutsideWorkingDirectories 也限制 bypass 和私有目录授权。设置不可读或格式错误会拒绝准入。`parseClaudeToolSelector` 与子代理提供方共用带参数选择器解析。

`claudeDirectories` 按项目祖先目录、已映射的用户目录顺序返回根目录。`claudePluginSources` 合并用户、项目及项目本地的 `enabledPlugins` 设置，选择匹配的 local/project/user 安装，返回组件默认目录及清单路径。支持 `workflows`、`agents`、`skills` 组件；清单路径必须位于插件安装根目录内。每次调用重新读取配置、响应取消，并将每个 JSON 文件限制在 1 MiB 内。JSON 解析错误或路径越界会使查找失败。

`parseClaudeMarkdown` 读取兼容 JSON 的 YAML frontmatter，并去除指令正文两端空白。调用方负责文件大小限制、组件元数据验证、目录遍历及名称优先级。此库没有需要比对的保留状态或注册项，因此不发布 invariant 附属入口。

`harnessToolName` 转换 Claude 工具别名；`claudeToolName` 返回 hook payload 使用的规范 Claude 名称。未知名称原样保留。

## Model Experience

无。此库只读取配置；消费者负责所有模型可见指令及工具。

#### KV Cache effect

此库不发出模型请求或修改缓存。消费者决定配置变化何时影响请求内容。

## Known Limitations and Deferred Work

- Read 准入尚不加载托管、CLI、会话或工具收窄规则来源；尚未实现祖先/Git 根目录设置策略及原生规则校验的边缘情况。私有目录归属由消费者提供。

- 查找范围为用户或当前项目设置启用、并记录在安装注册表中的插件。企业托管策略、命令行插件目录、内置插件目录和账户同步插件需要各自的配置来源。

<a id="dev-note"></a>
### 开发备注

<details>
<summary>维护者工作上下文——点击展开</summary>

无。

</details>
