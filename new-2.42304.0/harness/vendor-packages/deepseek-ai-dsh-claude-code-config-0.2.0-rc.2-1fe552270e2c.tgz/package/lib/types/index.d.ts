import type FileSystem from '@deepseek-ai/dsh-fs';
/** Resolve enabled plugin component paths through the execution-world filesystem.
 * @param fs - Filesystem of the caller's execution world.
 * @param component - Manifest component whose default and additional paths are returned.
 * @param cwd - Project directory for scoped installs and settings overrides.
 * @param signal - Cancels configuration reads.
 * @returns Enabled component paths with their plugin namespace and root; no executable module is loaded.
 */
export declare function claudePluginSources(fs: FileSystem, component: 'workflows' | 'agents' | 'skills', cwd: string | undefined, signal: AbortSignal): Promise<{
    path: string;
    namespace: string;
    root: string;
}[]>;
/** Find project-ancestor and user component roots, in lookup order.
 * @param fs - Execution-world filesystem and host-path mapper.
 * @param component - Claude configuration directory name.
 * @param cwd - Project directory from which ancestor lookup begins.
 * @returns Unique component paths; the user path is omitted when not mapped into this world.
 */
export declare function claudeDirectories(fs: FileSystem, component: 'agents' | 'skills' | 'workflows', cwd?: string): string[];
/** Parse bounded Markdown configuration without evaluating YAML tags or body content.
 * @param source - UTF-8 Markdown text already bounded by the caller's read limit.
 * @returns Frontmatter metadata and the trimmed instruction body.
 */
export declare function parseClaudeMarkdown(source: string): {
    metadata: Record<string, unknown>;
    content: string;
};
/** Translate a Claude tool selector into its Harness global name.
 * @param name - Claude alias or a provider's existing tool name.
 * @returns Harness name; unknown names pass through unchanged.
 */
export declare function harnessToolName(name: string): string;
/** Translate a Harness tool name for Claude hook matching and payloads.
 * @param name - Harness or external tool name.
 * @returns Canonical Claude alias when known, otherwise the original name.
 */
export declare function claudeToolName(name: string): string;
export { parseClaudeToolSelector } from './tool-selector.ts';
export { claudeReadAllowed } from './read-permission.ts';
//# sourceMappingURL=index.d.ts.map