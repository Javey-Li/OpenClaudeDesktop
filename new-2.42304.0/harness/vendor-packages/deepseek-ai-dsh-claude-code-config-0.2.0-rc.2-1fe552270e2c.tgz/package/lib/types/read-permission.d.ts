import type FileSystem from '@deepseek-ai/dsh-fs';
/** Apply Read deny/ask rules before directory, explicit rule, or bypass grants.
 * @param fs - Calling execution world's filesystem; host paths are mapped before use.
 * @param paths - Absolute lexical and resolved spellings of the same target; every spelling must pass.
 * @param options - Caller-owned directories, permission mode, cwd, and cancellation signal.
 * @returns Whether the file is readable without another permission prompt. Bare Read allow does not grant outside-directory access.
 */
export declare function claudeReadAllowed(fs: FileSystem, paths: readonly string[], options: {
    cwd: string;
    signal: AbortSignal;
    additionalDirectories: readonly string[];
    privateDirectories: readonly string[];
    bypassPermissions: boolean;
}): Promise<boolean>;
//# sourceMappingURL=read-permission.d.ts.map