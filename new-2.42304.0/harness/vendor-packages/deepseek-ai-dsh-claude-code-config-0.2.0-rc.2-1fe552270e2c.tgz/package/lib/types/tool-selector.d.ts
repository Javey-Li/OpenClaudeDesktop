/** Parse the tool spelling and optional argument text in a Claude tool selector. */
/** Read Tool(argument) syntax without interpreting arguments as execution permissions.
 * @param selector - One selector after frontmatter list splitting.
 * @returns The tool spelling and decoded content; malformed calls retain their complete spelling.
 */
export declare function parseClaudeToolSelector(selector: string): {
    toolName: string;
    ruleContent?: string;
};
//# sourceMappingURL=tool-selector.d.ts.map