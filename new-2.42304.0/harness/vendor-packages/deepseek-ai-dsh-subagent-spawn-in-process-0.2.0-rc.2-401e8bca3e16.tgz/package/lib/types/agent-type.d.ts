import type { Context } from '@deepseek-ai/cordis';
/** Resolved instructions and supported start options from one Markdown definition. */
export interface AgentTypeDefinition {
    persona: string;
    model?: string;
    effort?: string;
    maxTurns?: number;
    tools?: string[];
    disallowedTools?: string[];
    permissionMode?: string;
    skills?: string[];
    isolation?: 'worktree';
    pluginRoot?: string;
    hooks?: unknown;
    mcpServers?: unknown[];
}
/** Split comma/space-separated selectors, retaining separators inside parentheses; a wildcard selects the complete list.
 * @param value - YAML array or comma/space-separated field value.
 * @returns Nonempty selectors, or an empty list for an invalid field.
 */
export declare function agentSelectors(value: unknown): string[];
/** Read project ancestors before user and enabled plugin definitions.
 * @param ctx - Parent context supplying the execution-world filesystem.
 * @param name - Declared agent name, namespaced plugin name, or supported built-in name.
 * @param cwd - Parent working directory from which ancestor lookup begins.
 * @param signal - Cancels definition reads before child publication.
 * @returns Persona and supported routing and tool restrictions; rejects missing definitions.
 */
export declare function loadAgentType(ctx: Context, name: string, cwd: string, signal: AbortSignal): Promise<AgentTypeDefinition>;
//# sourceMappingURL=agent-type.d.ts.map