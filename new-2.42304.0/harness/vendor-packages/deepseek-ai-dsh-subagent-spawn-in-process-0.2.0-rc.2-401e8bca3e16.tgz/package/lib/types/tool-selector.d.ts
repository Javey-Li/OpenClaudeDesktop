/** Share Claude selector parsing with settings consumers. */
export { parseClaudeToolSelector as parseToolSelector } from '@deepseek-ai/dsh-claude-code-config';
//# sourceMappingURL=tool-selector.d.ts.map