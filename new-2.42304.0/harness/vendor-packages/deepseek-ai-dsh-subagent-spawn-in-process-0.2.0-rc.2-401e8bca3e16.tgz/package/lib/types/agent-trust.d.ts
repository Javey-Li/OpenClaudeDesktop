import type { Context } from '@deepseek-ai/cordis';
/** Check the exact definition folder; neither ancestors nor noninteractive mode grant trust.
 * @param ctx - Parent context with the execution-world filesystem.
 * @param directory - Project folder containing the selected .claude/agents directory.
 * @param signal - Cancels trust-file reads before child publication.
 * @returns Whether Claude's projects entry explicitly trusts this folder.
 */
export declare function isAgentDirectoryTrusted(ctx: Context, directory: string, signal: AbortSignal): Promise<boolean>;
//# sourceMappingURL=agent-trust.d.ts.map