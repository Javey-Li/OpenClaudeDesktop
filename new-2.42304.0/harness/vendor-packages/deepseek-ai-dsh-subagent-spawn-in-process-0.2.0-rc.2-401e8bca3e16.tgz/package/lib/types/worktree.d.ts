import type { Context } from '@deepseek-ai/cordis';
/** Create an execution-world worktree and retain any edits or commits on cleanup.
 * @param ctx - Parent context supplying the subprocess service.
 * @param cwd - Working directory inside the Git repository.
 * @param signal - Cancels Git discovery and worktree creation.
 * @returns Detached worktree directory and cleanup that removes only an unchanged tree.
 */
export declare function createAgentWorktree(ctx: Context, cwd: string, signal: AbortSignal): Promise<{
    cwd: string;
    cleanup(): Promise<void>;
}>;
//# sourceMappingURL=worktree.d.ts.map