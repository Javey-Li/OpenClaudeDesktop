import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        /** Attribution only; replay preserves the recorded body without the producer.
         * @persistenceAttribution
         */
        'subagent-skill-preload': {
            kind: 'subagent-skill-preload';
            form: 'instructions';
            name: string;
        };
    }
}
/** Resolve registry, Claude project/user, and enabled plugin skills for one child.
 * @param ctx - Unpublished child's registration context.
 * @param child - Agent receiving durable instruction messages.
 * @param names - Skills declared by the selected agent definition.
 * @param agentType - Selected agent name, including its optional plugin namespace.
 * @param cwd - Definition lookup directory, retained when the child uses a worktree.
 * @param signal - Cancels loading before child publication.
 */
export declare function preloadAgentSkills(ctx: Context, child: Agent, names: readonly string[], agentType: string, cwd: string, signal: AbortSignal): Promise<void>;
//# sourceMappingURL=skills.d.ts.map