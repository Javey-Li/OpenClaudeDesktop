/** One prepared clamp; the caller installs it in a child-scoped final guard. */
export type BashClamp = (command: string) => string | undefined;
/** Validate rules and load the grammar before publishing the child. No shell is executed.
 * @param rules - case-sensitive Bash(command) permission rules, or no clamp.
 * @param signal - the child creation signal.
 * @returns a synchronous final guard, or undefined for an absent/empty clamp.
 */
export declare function prepareBashClamp(rules: readonly string[] | undefined, signal: AbortSignal): Promise<BashClamp | undefined>;
//# sourceMappingURL=bash-clamp.d.ts.map