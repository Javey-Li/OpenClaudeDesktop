/** Mount Claude agent MCP declarations in the unpublished child's effect scope. */
import type { Context } from '@deepseek-ai/cordis';
import type { Config } from '@deepseek-ai/dsh-mcp-client';
import type { McpResourceToolName } from '@deepseek-ai/dsh-mcp-resources';
/** A borrowed server namespace or a validated connection owned by this child. */
export interface AgentMcpServer {
    name: string;
    config?: Config;
    source?: Context;
}
/** Resolve mounted names or disk declarations and validate inline transports without starting a process.
 * @param ctx - Parent context with the inherited tool and filesystem services.
 * @param entries - Trust-filtered local-agent frontmatter entries.
 * @param cwd - Original project directory for disk discovery and approval.
 * @param signal - Cancels discovery before child publication.
 * @param executionCwd - Child directory used by new stdio connections, including an isolated worktree.
 * @returns Valid declarations in input order; invalid, unavailable and unsupported entries warn and skip.
 */
export declare function resolveAgentMcpServers(ctx: Context, entries: readonly unknown[], cwd: string, signal: AbortSignal, executionCwd?: string): Promise<AgentMcpServer[]>;
/** Await child-owned clients before the first request; borrowed namespaces retain their existing owner.
 * @param ctx - Unpublished child's effect scope.
 * @param servers - Resolved declarations, including borrowed namespaces without config.
 * @param acceptTool - Monotonic caller/definition admission applied on every discovery.
 * @param signal - Cancels startup; every newly created transport is drained before rejection.
 * @param resourceTools - Ordinary tool selection for shared MCP resource operations.
 * @returns Readiness after all initial connections settle; individual connection failures warn and skip.
 */
export declare function installAgentMcpServers(ctx: Context, servers: readonly AgentMcpServer[], acceptTool: (name: string) => boolean, signal: AbortSignal, resourceTools: readonly McpResourceToolName[]): Promise<void>;
//# sourceMappingURL=agent-mcp.d.ts.map