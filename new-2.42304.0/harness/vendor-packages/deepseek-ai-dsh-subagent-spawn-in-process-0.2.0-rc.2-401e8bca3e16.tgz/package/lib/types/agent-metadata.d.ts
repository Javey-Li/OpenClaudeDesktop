/** Parse Claude agent effort and model-iteration limits from Markdown metadata. */
/** Resolve named efforts, the med alias, and integer effort values.
 * @param value - Raw frontmatter field.
 * @returns Provider-facing effort identifier, or undefined for an invalid value.
 */
export declare function agentEffort(value: unknown): string | undefined;
/** Resolve Claude's positive integer maxTurns field, including numeric strings.
 * @param value - Raw frontmatter field; numeric strings accept exponent/grouped notation and decimal integer prefixes.
 * @returns Maximum model iterations, or undefined for an invalid value.
 */
export declare function agentMaxTurns(value: unknown): number | undefined;
//# sourceMappingURL=agent-metadata.d.ts.map