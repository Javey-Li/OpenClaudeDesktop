import { type McpResourceToolName } from '@deepseek-ai/dsh-mcp-resources';
import type { Context } from '@deepseek-ai/cordis';
import type { ToolRestriction } from '@deepseek-ai/dsh-tools';
import type { AgentTypeDefinition } from './agent-type.ts';
import type { BashClamp } from './bash-clamp.ts';
/** Match a Claude tool alias, exact name, or MCP server/prefix selector, ignoring argument text for tool admission.
 * @param rule - One selector from an agent definition or caller restriction.
 * @param name - Public Harness tool name.
 * @returns Whether the selector names this tool.
 */
export declare function matchesAgentTool(rule: string, name: string): boolean;
/** Admit a declared MCP tool under caller restrictions and definition denials.
 * @param name - Public MCP tool name.
 * @param filter - Caller allow/deny selectors, independent of definition tools.
 * @param definition - Agent definition whose disallowedTools still apply.
 * @returns Whether the MCP client may register this tool.
 */
export declare function acceptsAgentMcpTool(name: string, filter?: ToolRestriction, definition?: AgentTypeDefinition): boolean;
/** Resolve shared resource operations under ordinary definition and caller selectors.
 * @param filter - Caller allow/deny selectors.
 * @param definition - Agent tools and disallowedTools declarations.
 * @returns Canonical resource names allowed before any child-owned server is registered.
 */
export declare function agentMcpResourceTools(filter?: ToolRestriction, definition?: AgentTypeDefinition): McpResourceToolName[];
/** Install child-scoped name restrictions and a final command guard.
 * @param ctx - Unpublished child's tool registration scope.
 * @param filter - Allowed and denied global tool names, including Claude aliases.
 * @param clamp - Prepared Bash command guard, or no additional Bash restriction.
 * @param readOnly - Whether the agent definition limits the child to reading.
 * @param definition - Optional Claude agent selectors, resolved independently before intersection.
 * @param mcpServers - Declared namespaces added after ordinary definition tool selection.
 */
export declare function installWorkflowToolPolicy(ctx: Context, filter: ToolRestriction | undefined, clamp: BashClamp | undefined, readOnly: boolean, definition?: AgentTypeDefinition, mcpServers?: readonly string[]): void;
//# sourceMappingURL=tool-policy.d.ts.map