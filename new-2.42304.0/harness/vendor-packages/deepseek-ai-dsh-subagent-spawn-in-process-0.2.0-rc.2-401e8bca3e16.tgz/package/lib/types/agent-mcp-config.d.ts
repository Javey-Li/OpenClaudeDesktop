import type { Context } from '@deepseek-ai/cordis';
/** Read local, approved project-ancestor and user declarations in precedence order.
 * @param ctx - Parent execution-world context.
 * @param cwd - Original project directory, before worktree isolation.
 * @param signal - Cancels bounded configuration reads.
 * @returns A lookup of candidates; connection validation decides which candidate survives.
 */
export declare function readAgentMcpConfigs(ctx: Context, cwd: string, signal: AbortSignal): Promise<(name: string) => unknown[]>;
/** Expand disk-config command, arguments, environment, URL and header strings once.
 * @param ctx - Diagnostics owner; no expanded value is logged.
 * @param name - MCP server identity for missing-variable warnings.
 * @param config - Untrusted connection object; non-string fields remain for schema validation.
 * @returns A copy with native-style substitutions; missing variables retain their placeholder.
 */
export declare function expandAgentMcpConfig(ctx: Context, name: string, config: Record<string, unknown>): Record<string, unknown>;
//# sourceMappingURL=agent-mcp-config.d.ts.map