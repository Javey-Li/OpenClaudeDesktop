/** Claude Code's background launch value and model rendering. */
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { InferValue } from '@deepseek-ai/dsh-tools';
import type { WorkflowRun, WorkflowResult } from '@deepseek-ai/dsh-workflow';
/** Local Workflow launch fields; task identity controls this attempt, run identity controls resume. */
export declare const CLAUDE_LAUNCH_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly properties: {
        readonly status: {
            readonly type: "string";
            readonly const: "async_launched";
            readonly required: true;
        };
        readonly taskId: {
            readonly type: "string";
            readonly required: true;
        };
        readonly taskType: {
            readonly type: "string";
            readonly const: "local_workflow";
            readonly required: true;
        };
        readonly workflowName: {
            readonly type: "string";
            readonly required: true;
        };
        readonly runId: {
            readonly type: "string";
            readonly required: true;
        };
        readonly summary: {
            readonly type: "string";
            readonly required: true;
        };
        readonly transcriptDir: {
            readonly type: "string";
        };
        readonly scriptPath: {
            readonly type: "string";
        };
    };
};
/**
 * Render an accepted background launch with saved-file and resume instructions.
 * @param value - Validated local launch result.
 * @returns The model-visible launch acknowledgment.
 */
export declare function renderClaudeLaunch(value: InferValue<typeof CLAUDE_LAUNCH_SCHEMA>): ContentBlock[];
/**
 * Deliver the return value and recovery instructions in a task notification.
 * @param input - Settled run, originating tool call, task identity and rendering cap.
 * @returns Automated-event text for the job controller's durable delivery.
 */
export declare function renderClaudeCompletion(input: {
    taskId: string;
    callId: string;
    run: WorkflowRun;
    result: WorkflowResult;
    args: unknown;
    maxResultChars: number;
}): string;
//# sourceMappingURL=claude-output.d.ts.map