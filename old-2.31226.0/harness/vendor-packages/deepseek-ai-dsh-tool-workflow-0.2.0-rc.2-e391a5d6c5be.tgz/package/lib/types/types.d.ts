/**
 * Browser-safe durable workflow-record events written by the model-facing
 * workflow tool into its calling parent Session.
 *
 * @module @deepseek-ai/dsh-tool-workflow/types
 */
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { WorkflowAgentAdmissionInfo, WorkflowAgentOutcome, WorkflowAgentProgressInfo, WorkflowRunId, WorkflowStopReason, WorkflowAttemptId } from '@deepseek-ai/dsh-workflow/types';
/** Opens one durable top-level workflow run record. */
export interface ToolWorkflowRunStartData {
    readonly runId: WorkflowRunId;
    /** Execution identity; absent in legacy records. */
    readonly attemptId?: WorkflowAttemptId;
    readonly name: string;
    /** Optional display title; legacy records fall back to name. */
    readonly title?: string;
    readonly description?: string;
    readonly phases?: string[];
    readonly scriptPath?: string;
}
/** Queue and pre-publication failure observations for one workflow invocation. */
export interface ToolWorkflowAgentAdmissionData extends WorkflowAgentAdmissionInfo {
    readonly runId: WorkflowRunId;
    /** Execution identity; absent in legacy records. */
    readonly attemptId?: WorkflowAttemptId;
}
/** Records one workflow member after its child Session is published. */
export interface ToolWorkflowAgentStartData {
    readonly runId: WorkflowRunId;
    /** Execution identity; absent in legacy records. */
    readonly attemptId?: WorkflowAttemptId;
    readonly seq: number;
    readonly label: string;
    readonly phase?: string;
    /** Execution-assigned phase index; absent in legacy records. */
    readonly phaseIndex?: number;
    readonly childId: SessionId;
    readonly cached?: boolean;
    readonly model?: string;
    readonly progressSupported?: boolean;
}
/** Observed activity for a previously started workflow member. */
export interface ToolWorkflowAgentProgressData extends WorkflowAgentProgressInfo {
    readonly runId: WorkflowRunId;
    /** Execution identity; absent in legacy records. */
    readonly attemptId?: WorkflowAttemptId;
}
/** Settles one previously started workflow member. */
export interface ToolWorkflowAgentEndData {
    readonly runId: WorkflowRunId;
    /** Execution identity; absent in legacy records. */
    readonly attemptId?: WorkflowAttemptId;
    readonly seq: number;
    readonly outcome: WorkflowAgentOutcome;
    readonly tokens?: number;
    readonly outputTokens?: number;
    readonly error?: string;
    readonly durationMs?: number;
}
/** Settles one workflow run after its live resources reach quiescence. */
export interface ToolWorkflowRunEndData {
    readonly runId: WorkflowRunId;
    /** Execution identity; absent in legacy records. */
    readonly attemptId?: WorkflowAttemptId;
    readonly stopReason: WorkflowStopReason;
    readonly error?: string;
}
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /**
         * Opens one top-level workflow record.
         * @param data - stable run identity and display name.
         */
        'tool-workflow/run-start': ToolWorkflowRunStartData;
        /** A script phase, retained even when it launches no agents. */
        'tool-workflow/phase': {
            readonly runId: WorkflowRunId;
            readonly attemptId?: WorkflowAttemptId;
            readonly title: string;
            readonly index?: number;
            readonly kind?: 'child';
        };
        /** Queue registration or failure before a child exists. */
        'tool-workflow/agent-admission': ToolWorkflowAgentAdmissionData;
        /**
         * Records one published workflow member.
         * @param data - run identity, member sequence, display identity, and child Session.
         */
        'tool-workflow/agent-start': ToolWorkflowAgentStartData;
        /** Observed child activity and cumulative usage, retained for replay. */
        'tool-workflow/agent-progress': ToolWorkflowAgentProgressData;
        /**
         * Records one member settlement.
         * @param data - run identity, paired member sequence, and outcome.
         */
        'tool-workflow/agent-end': ToolWorkflowAgentEndData;
        /**
         * Closes one workflow record after cleanup.
         * @param data - stable run identity and terminal reason.
         */
        'tool-workflow/run-end': ToolWorkflowRunEndData;
    }
}
//# sourceMappingURL=types.d.ts.map