/** Bind explicit script reads to the calling Agent's visible tools and application permissions. */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
/** Application-owned Read availability and outside-directory grants. Explicit settings rules still apply. */
export interface WorkflowReadPolicy {
    readAvailable: boolean;
    bypassPermissions: boolean;
    additionalDirectories: readonly string[];
}
declare module '@deepseek-ai/cordis' {
    interface Events {
        /**
         * Resolve application Read policy before an explicit Workflow source read.
         * @mode waterfall
         * @param agent - Agent requesting scriptPath, including nested Workflow resolution.
         * @param next - Delegates to earlier listeners; the default grants only ordinary working-directory reads.
         */
        'tool-workflow/read-policy'(agent: Agent, next: () => Promise<WorkflowReadPolicy>): Promise<WorkflowReadPolicy>;
    }
}
/** Create a Read admission callback that rereads permissions for each path check.
 * @param ctx - Tool registration context with tools and workflowEngine injected.
 * @param parent - Agent that owns this Workflow invocation.
 * @param scriptPath - Original model path for a recoverable admission error.
 * @param signal - Cancels configuration and canonical-directory reads.
 * @returns A callback that rejects before any script content is read.
 */
export declare function workflowReadAdmission(ctx: Context, parent: Agent, scriptPath: string, signal: AbortSignal): (paths: readonly string[]) => Promise<void>;
//# sourceMappingURL=read-policy.d.ts.map