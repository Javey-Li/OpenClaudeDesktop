/** Refuse Workflow network paths before resolution and return the absolute lexical spelling.
 * @param path - Model-supplied scriptPath.
 * @param cwd - Calling execution world's absolute working directory, when known.
 * @returns The lexical absolute path, or the original relative path when cwd is absent.
 */
export declare function workflowScriptPath(path: string, cwd?: string): string;
//# sourceMappingURL=script-path.d.ts.map