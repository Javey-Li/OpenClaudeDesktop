import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
/**
 * Enforce the published CLI's seven input fields and always start an owned job.
 * @param tool - Harness tool with its lifecycle and output projections.
 * @returns Tool exposing the CLI input schema while retaining Harness job ownership.
 */
export declare function withClaudeInputs(tool: ToolDefinition): ToolDefinition;
//# sourceMappingURL=claude-input.d.ts.map