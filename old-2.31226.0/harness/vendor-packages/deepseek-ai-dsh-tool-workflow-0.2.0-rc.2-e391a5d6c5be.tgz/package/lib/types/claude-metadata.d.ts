import type { WorkflowMeta } from '@deepseek-ai/dsh-workflow';
/** Decode a CLI metadata header without evaluating expressions or script code.
 * @param source - Complete script with its required first metadata export.
 * @param validateBody - False allows header-only discovery for the native static-literal subset.
 * @returns Normalized annotations and the body following the declaration.
 */
export declare function parseClaudeWorkflowScript(source: string, validateBody?: boolean): {
    script: string;
    meta: WorkflowMeta;
};
//# sourceMappingURL=claude-metadata.d.ts.map