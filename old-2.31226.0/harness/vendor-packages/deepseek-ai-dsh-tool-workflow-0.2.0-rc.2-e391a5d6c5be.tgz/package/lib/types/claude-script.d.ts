import type { WorkflowMeta } from '@deepseek-ai/dsh-workflow';
/** Locate the end of the leading metadata object without parsing the body.
 * @param source - Complete workflow script.
 * @returns UTF-16 offset immediately after the metadata object's closing brace.
 */
export declare function metadataEnd(source: string): number;
/** Strip a leading literal meta declaration without evaluating any JavaScript.
 * @param source - Complete workflow script with an optional literal metadata export.
 * @param validateBody - False reads only the leading metadata for registry discovery.
 * @returns Body preserving original line positions, plus the parsed metadata when present.
 */
export declare function parseClaudeCodeScript(source: string, validateBody?: boolean): {
    script: string;
    meta?: WorkflowMeta;
};
//# sourceMappingURL=claude-script.d.ts.map