/** Built-in research orchestration for the Claude-compatible source catalog. */
/** Plain JavaScript executed by the same confined engine as user-authored workflows. */
export declare const deepResearchScript: string;
//# sourceMappingURL=builtin-research.d.ts.map