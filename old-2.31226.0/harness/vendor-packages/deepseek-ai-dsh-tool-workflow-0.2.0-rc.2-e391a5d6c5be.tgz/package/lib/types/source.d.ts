import type FileSystem from '@deepseek-ai/dsh-fs';
import type { WorkflowMeta } from '@deepseek-ai/dsh-workflow';
/** Sources accepted at the tool boundary; an explicit path takes precedence. */
export interface WorkflowSourceInput {
    script?: string;
    scriptPath?: string;
    name?: string;
}
/** Filesystem lookup limits and directories, supplied by the tool configuration. */
export interface WorkflowSourceConfig {
    maxScriptBytes: number;
    workflowDirectories: string[];
    /** Claude Code requires a header and resolves names before inline scripts. */
    inputMode?: 'harness' | 'claude-code';
}
/** Resolve a path, inline body, or registered meta.name without evaluating metadata.
 * @param fs - Optional execution-world filesystem; inline and built-in bodies need no service.
 * @param input - Model-supplied source selector.
 * @param config - Read ceiling and additional registry directories.
 * @param signal - Caller cancellation during filesystem reads.
 * @param cwd - Calling Session's working directory.
 * @param authorize - Owner's Read admission, called before resolution and again with the canonical path before reading bytes.
 * @returns The parsed body and optional literal metadata.
 */
export declare function resolveWorkflowSource(fs: FileSystem | undefined, input: WorkflowSourceInput, config: WorkflowSourceConfig, signal: AbortSignal, cwd?: string, authorize?: (paths: readonly string[]) => Promise<void>): Promise<{
    script: string;
    meta?: WorkflowMeta;
    scriptPath?: string;
}>;
//# sourceMappingURL=source.d.ts.map