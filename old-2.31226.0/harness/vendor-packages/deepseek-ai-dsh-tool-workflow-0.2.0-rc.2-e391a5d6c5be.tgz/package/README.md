---
description: "The model-facing workflow tool: run a JavaScript orchestration script that fans out subagents, for users and maintainers choosing or configuring model-driven orchestration."
kind: "package-reference"
---

# @deepseek-ai/dsh-tool-workflow

English | [中文](README.zh.md)

## Summary

`dsh-tool-workflow` lets a model run JavaScript orchestration that delegates to many subagents and returns a final JSON value. Use it only when the user explicitly requests a workflow or large multi-agent orchestration; prefer plain subagent calls for one or two delegations. Foreground execution waits for all work; cancellation or abnormal completion returns an error rather than partial success. `run_in_background: true` returns an owned job id immediately and exposes live output. Deployments can rename the tool with `toolName` and cap rendered results with `maxResultChars`.

## Table of Contents

- [Use this package](#use-this-package)
- [Understand the implementation](#understand-the-implementation)
- [Further Exploration](#further-exploration)
- [Model Experience](#model-experience)
- [Known Limitations and Deferred Work](#known-limitations-and-deferred-work)
- [Dev Note](#dev-note)

Resuming through the PTC engine retains runId and creates a new attemptId. Route observer events and durable records by attemptId when present; legacy records use runId. Stop the prior execution and await cleanup before resuming. Explicit script paths are retained for editing and rerunning.

-----

Resume calls prepareResume before resolving the selected source. In claude-code mode, explicit paths pass lexical network checks and Read admission before restoration, then normal descriptor and resolved-target checks before execution. Recovery availability belongs to the engine.

<a id="use-this-package"></a>
## Use this package

The `workflow` tool runs a model-authored orchestration script that fans work out across many subagents and returns the script's final JSON value. Use it only when the user explicitly asks for a workflow or for large multi-agent orchestration — an audit over many files, a migration, multi-angle research; for one or two delegations, prefer plain subagent calls.

### Calling the tool

CLI metadata accepts static template strings and an optional meta.title for display. It drops mistyped optional annotations and phase entries without string titles, preserves empty phase titles, and rejects expressions or reserved object keys even in ignored fields. Full parsing uses strict JavaScript; header-only discovery falls back to full parsing for syntax outside the native static subset. The harness input mode retains its separate parser.

The CLI catalog includes deep-research without disk configuration. Valid user and project scripts override the built-in; invalid overrides retain it. The built-in scopes a string question, pipelines searches and deduplicated fetches, ranks up to 25 claims, and requests three independent verifier votes per claim. Two refutations reject a claim; insufficient votes remain unverified. Synthesis returns citations, caveats, source counts and vote results. High-relevance sources can exceed the nominal 15-fetch budget. Child providers need usable web search and fetch tools for live research.

In claude-code mode, explicit scriptPath reads require Read in the calling Agent’s scoped tool catalog. The tool applies [Claude Read settings](../../settings/claude-code-config/README.md#lookup) before opening the source, then rechecks the resolved target before reading bytes. UNC, NT namespace and automount paths are refused before filesystem resolution. The tool-workflow/read-policy waterfall supplies application Read availability, bypass mode and added directories; listeners delegate with next(). Without a listener, only ordinary cwd/private reads and settings grants apply. Private directories come from workflowEngine.sourceDirectories(parent), mapped into the active filesystem. Inline and registered-name invocations do not require Read. Direct resolveWorkflowSource callers supply their own authorize callback when they need Agent permission checks.

`inputMode: claude-code` exposes only script, name, description, title, args, scriptPath and resumeFromRunId. Every accepted call starts an owned background job; enableRunInBackground must remain enabled. Description and title are ignored. Scripts require a leading literal metadata export. Nonempty paths take precedence over names, and names over inline scripts; an explicit inline script is validated even when another source supplies the executed body. Empty path/name selectors are absent. Names and paths reject control/invisible characters; inline scripts reject control characters except tabs and line feeds, and are limited to 524288 UTF-16 code units. Resume IDs must match `^wf_[a-z0-9-]{6,}$` and require a source selector. Registry entries use .js files, including readable symlinks. Discovery skips unreadable or oversized entries and reads metadata without parsing bodies; a broken overriding body keeps the earlier definition, while a sole broken definition reports its syntax error at invocation. CLI file decoding replaces invalid UTF-8 bytes, with the byte cap enforced before decoding. Cancellation still aborts discovery. The engine still receives separate body and metadata. The default inputMode, harness, retains the extended inputs below.

An explicit `scriptPath` takes precedence over inline `script`; `name` resolves a literal `meta.name` when both are absent. File sources use `ctx.fs` and the calling Session directory. Registry lookup checks configured `workflowDirectories`, then project and user `.claude/workflows`; duplicate names in one directory fail. The default `maxScriptBytes` is 1048576. Saved files contain the metadata header and body, so the returned path can be used directly for another run. Inline execution needs no filesystem service.

Member activity is persisted as `tool-workflow/agent-progress` between start and end. Its token total includes input, cache and output; `outputTokens` separately reports budget consumption. Providers without activity telemetry set `progressSupported: false`, allowing clients to avoid false stall warnings.

The model submits: `meta` (identity data: `name`, `description`, and optional `whenToUse` and `phases`), `script` (inline plain JavaScript body — an optional leading `export const meta = {...}` literal is parsed as JSON5 data and stripped here; its parameter description carries the body rules and the tool description carries the hook contract), `args` (any optional JSON value exposed verbatim to the script), `resumeFromRunId`, `budgetTotal`, named `workflows`, and `run_in_background` (optional; present only while `enableRunInBackground` holds).

A script with no return value omits the result field and Return value section; explicit null remains a JSON result. CLI task notifications likewise omit the result tag for absent values.

A foreground success returns the envelope `{ kind: 'foreground', runId, agentsStarted, result }`, rendered to the model as `workflow "<name>" completed (<count> agent<optional-s>).` followed by `Return value:` and the pretty-printed JSON. A workflow that cannot start — a script parse or meta validation failure — returns an error the model can correct from. Cancellation and execution failures return `Error: workflow run was cancelled` or `Error: workflow run failed: <error>`; partial output is never reported as success.

A separate `meta` field is optional when the script declares a literal header. Executable metadata expressions are rejected without evaluation. The engine still receives separate body and meta data. Successful envelopes also include `scriptPath` when the engine supplies it. Durable member records retain optional cached, model, output-token and duration fields; failed run records retain the error.

### What to expect during a run

Foreground mode waits and disposes the run. Default background mode returns a job identifier immediately; the job owns the run and its cleanup. Intermediate child conversations do not join parent history.

### Background runs

Omitting `run_in_background` starts a background job by default. Set it to false or configure `defaultRunInBackground: false` for synchronous callers. Name lookup checks project ancestors and user workflows; enabled plugin workflows use the `plugin:name` namespace and include manifest paths. Nested name/path calls use the same resolver.

`run_in_background: true` returns `{ kind: 'background', jobId, runId }` immediately: the run is registered on `ctx.jobs` as an owned `workflow` job, so the session-header job list streams its `phase()`, `log()`, and member lifecycle lines live from the job's output ring, and the row's progress line tracks the current phase. No tool-step signal reaches the run — `job_kill`, the list's stop control, and owner teardown are what cancel it. Settlement is the job's settlement: a completed run carries the same rendered return value as the job's result (the completion notice announces it, the model's first `job_output` after settlement carries it once), a cancelled run settles `killed` with the kill reason, and a failed run settles `failed` with the script's failure message. Without a live job registry and a controller serving the caller the call fails, naming the missing composition pieces.

`inputMode: claude-code` publishes the callable, unadvertised `RunWorkflow` alias. Set `toolName: Workflow` for the canonical CLI name. Successful calls return `{ status: "async_launched", taskId, taskType: "local_workflow", workflowName, runId, summary, transcriptDir?, scriptPath? }`; task identity addresses this execution and run identity addresses resume. The launch text names the saved file and transcript directory. Completion delivers a `<task-notification>` containing the final result or failure, originating tool call, recovery instructions and the complete output file when supplied by the engine. Enable `claudeCodeTaskStop` on `dsh-tool-jobs` for native cancellation inputs. Generic Harness mode retains its foreground/background envelopes.

### Config

| Field | Default | Meaning |
|---|---|---|
| `toolName` | `workflow` | The model-facing tool name to register. |
| `maxResultChars` | `50000` | Rendered-result ceiling; longer JSON is truncated with a notice. |
| `enableRunInBackground` | `true` | Expose `run_in_background`; disabled calls are also rejected. |

The generated [configuration catalog](../../../docs/config-catalog.md#deepseek-aidsh-tool-workflow) is the exhaustive source for every accepted field.

CLI scriptPath reads require a single-link regular file with a nonzero identity. The filesystem provider verifies the canonical path against the open descriptor before reading; readable symbolic links still work. Registry discovery and the default harness mode retain their ordinary byte-read behavior.

-----

<a id="understand-the-implementation"></a>
## Understand the implementation

<details>
<summary>Implementation internals — click to expand</summary>

This section explains how the consumer is split from the engine and how the run lifecycle and records work; observable behavior is fully covered in [Use this package](#use-this-package).

### Design concept

The consumer owns the model-facing schema, the `tool:<toolName>` system-prompt guidance, and the result envelope; script parsing, execution, caps, and cancellation live behind `ctx.workflowEngine`, while the PTC engine shares Node process confinement with `run_code`. Usage guidance ships with the tool plugin as a prompt section, never in the deployment persona.

### Run lifecycle

`execute` starts the run and awaits `run.result` inside a `try/finally` that always disposes the run. `exec.signal` is bridged to `run.cancel()`, including the already-aborted-before-start case. A non-`completed` stop reason maps to an `isError` result reporting the reason; completion renders `{ kind, runId, agentsStarted, result }`, with the Native renderer truncating only that projection at `maxResultChars`.

### Background lifecycle

A background call registers the run through `jobs.start` inside the job starter, so a synchronous engine rejection registers nothing and admission preflight runs before the engine spawns. The job's `done` chains from `run.result`: dispose (a disposal failure is warned, never rejected into the registry), stop the mirrors, then map the stop reason onto the job outcome. The ring mirror (`src/record.ts`) subscribes `workflow/phase`, `workflow/log`, and member events once per plugin and routes them into the tracked runs' `JobHandle` faces (`append` for lines, `updateProgress` for the phase); a straggling event after settlement finds no tracked run, and an append against a settled job drops inside the registry.

### Durable session records

For a root transport execution (`exec.parent` absent), the tool projects the run into the calling Agent's Session with log-only events: run-start after `start()` returns, phase changes, member activity, starts and endings filtered by `run.id`, then run-end only after the result is available and disposal reaches quiescence. Nested transport calls execute normally but write no record. The first failed Session append disables later recording for that run with one warning, leaving either no record or a legal continuous prefix without changing the tool result or cleanup. The package invariant rejects duplicate starts, unpaired members, terminal events with open members, and updates after run-end on both cold load and live append, while accepting missing terminal suffixes.

The engine's `workflow/phase` events persist as `tool-workflow/phase`; the session log records phases and run and member lifecycle for transcript replay. `workflow/log` remains transient. A background run's lines reach a human through the job observation record instead, which is transient by design.

Phase records preserve the optional execution-assigned index and child kind; member starts preserve phaseIndex. The invariant requires indexed members to reference a matching announced phase and rejects changes to phase identity. Legacy records without these fields remain valid. See the [phase migration guide](../../../docs/upgrade-guide/v0.2.0-rc.2/workflow-phase-identity/guide.md).

Queue and pre-publication failure events persist as tool-workflow/agent-admission. Replay preserves their original row order; agent-start attaches the actual child to that row. A run may close with queued rows that never published a child. New readers accept older logs without admission records; older readers that do not recognize this required event reject new logs. See the [admission migration guide](../../../docs/upgrade-guide/v0.2.0-rc.2/workflow-admissions/guide.md).

### Render intent

Decided up front per the [render-intent Agent Note](../../../.agents/notes/implemented/architecture/2026-07-02-tool-render-intent-union.md): a `generic` card titled `workflow: <meta.name>`, read from `args.meta.name` with a generic fallback for a legacy script header — presentation is a pure function of args — with the script text carried as `rawInput`. The result keeps the generic card.

### Source map

| File | Role |
|---|---|
| [`src/index.ts`](src/index.ts) | Plugin entry: tool registration, run lifecycle, background job registration, recorder wiring |
| [`src/record.ts`](src/record.ts) | Background runs' live-progress mirror into the job's output ring |
| [`src/types.ts`](src/types.ts) | The log-only record event payloads and their `SessionEventMap` declaration |
| [`src/invariant.ts`](src/invariant.ts) | Invariant companion: durable workflow-record protocol validation |

</details>

-----

<a id="further-exploration"></a>
## Further Exploration

Read these pages when the tool-level contract is not enough. They move from the shared workflow model to the engine and the comparable delegation tool.

- [Workflow subsystem](../../../docs/subsystems/workflow.md) — the seam contract, start request, and event payloads.
- [Workflow seam](../workflow/README.md) — the run and result vocabulary behind the tool.
- [PTC workflow engine](../workflow-ptc/README.md) — the engine that executes the scripts.
- [subagent tool](../../subagent/tool-subagent/README.md) — the plain-delegation alternative for one or two children.
- [Group map](../README.md) — the workflow capability family and its packages.
- [Dynamic workflows Agent Note](../../../.agents/notes/implemented/feature/2026-07-05-dynamic-workflows.md) — the seam design and its decisions.

-----

<a id="model-experience"></a>
## Model Experience

### System prompt

#### What the model sees

Every parent request in this plugin's registration scope receives the workflow guidance below. A scoped tool restriction can hide the schema without removing this independently registered guidance.

##### Workflow guidance

```markdown
Use the <toolName> tool ONLY when the user explicitly asks for a workflow or for large multi-agent orchestration: you write a JavaScript script (the tool description documents the exact format) that fans work out across many subagents with phases and structured results. For one or two delegations, prefer plain subagent calls.
```

#### Token effect

Small fixed guidance cost per request while the plugin is active.

#### KV Cache effect

Prefix-stable while the plugin scope and guidance text are unchanged. Activation or disposal may invalidate reuse from this prompt section.

### Tool schema

#### What the model sees

When visible, the generated default [`workflow` schema](../../../docs/tool-catalog.md#deepseek-aidsh-tool-workflow) carries the complete JavaScript hook and metadata contract; `toolName` can rename the definition, and the model submits script, metadata, and optional args.

#### Token effect

Substantial fixed schema cost on each request where the tool is visible.

#### KV Cache effect

Prefix-stable while `toolName`, definition, and visibility are unchanged. Renaming, plugin lifecycle, or scoped restrictions may invalidate reuse from this schema.

### Tool-call history and result

#### What the model sees

The full model-written script, metadata, and args remain in the assistant tool call. With a returned value, a foreground success is exactly `workflow "<name>" completed (<count> agent<optional-s>).`, newline, `Return value:`, newline, and pretty-printed data-dependent JSON; a cap adds `… [truncated: <omitted> more characters]` on a new line. A background acceptance is exactly `workflow "<name>" started in the background as job <jobId>. Its return value arrives with the completion notice; check on it with job_output, stop it with job_kill.`, and the same rendered value later reaches the model through the job's completion notice and `job_output`. Failures are exactly `Error: workflow run was cancelled`, optionally suffixed ` (<error>)`, `Error: workflow run failed: <error-or-unknown error>`, or defensively `Error: workflow run ended abnormally (<reason>)`; a call without an owning agent becomes `Error: workflow tool requires a calling agent (exec.agent was undefined)`. Intermediate child messages are omitted.

#### Token effect

Call tokens can be large and remain until compaction. Result rendering is capped by `maxResultChars`; child-model tokens are separate from the parent's retained context.

#### KV Cache effect

Append-only; newly visible content follows the reusable request prefix and does not invalidate existing KV-cache entries.

## Known Limitations and Deferred Work

<a id="known-limitations-and-deferred-work"></a>


These limits define what the tool does not yet support. They are current constraints, not a task backlog.

- **A background run reports no intermediate value to the model** — `job_output` before settlement returns status only; the return value arrives whole at completion, and cancellation still discards partial output.
- **Native result text is bounded** — the canonical workflow result stays complete, while JSON beyond `maxResultChars` is truncated in the model-facing projection rather than stored behind a retrieval handle.
- **Workflow policy is fixed per tool registration** — provider selection, caps, and tool name are deployment config, not model-call arguments.
- **Durable records are top-level and observational** — nested PTC mode dispatches are not recorded, and a recording failure intentionally degrades to an incomplete prefix rather than changing execution.

<a id="dev-note"></a>
### Dev Note

<details>
<summary>Working context for maintainers — click to expand</summary>

This Dev Note is working context for maintainers: open directions that are not decided. It is explicitly non-authoritative — shipped behavior, limits, and accepted rationale live in the sections above, the package code, and the linked Agent Notes.

Open directions: recording nested dispatches beyond the top level.

</details>
