---
description: "面向模型的工作流工具：运行扇出 subagent 的 JavaScript 编排脚本，供选择或配置模型驱动编排的用户与维护者阅读。"
kind: "package-reference"
---

# @deepseek-ai/dsh-tool-workflow

[English](README.md) | 中文

## 概述

`dsh-tool-workflow` 让模型运行 JavaScript 编排，将工作委派给多个 subagent，并返回最终 JSON 值。仅当用户明确要求工作流或大型多 agent（智能体）编排时使用；一两项委派应优先使用普通 subagent 调用。前台执行等待所有工作结束；取消或异常完成返回错误，而不是部分成功。`run_in_background: true` 立即返回自有任务 id，并提供实时输出。部署方可以用 `toolName` 重命名工具，用 `maxResultChars` 限制渲染结果。


## 目录

- [使用本包](#use-this-package)
- [理解实现](#understand-the-implementation)
- [进一步探索](#further-exploration)
- [模型体验](#model-experience)
- [已知限制与延期工作](#known-limitations-and-deferred-work)
- [开发备注](#dev-note)

通过 PTC 引擎恢复时保留 runId，并生成新的 attemptId。观察事件与持久记录在存在 attemptId 时按它关联，旧记录使用 runId。恢复前须停止上次执行并等待清理完成。显式脚本路径会保留，供编辑和重跑。

-----

恢复调用先执行 prepareResume，再解析所选来源。在 claude-code 模式中，显式路径先通过词法网络检查与 Read 准入才可恢复，执行前仍进行正常文件描述符及解析目标检查。恢复能力由引擎提供。

<a id="use-this-package"></a>
## 使用本包

`scriptPath` 优先于内联 `script`；两者都缺省时，`name` 按字面量 `meta.name` 查找注册脚本。文件读取使用 `ctx.fs`，相对路径基于调用 Session 的目录。查找顺序是配置的 `workflowDirectories`、项目 `.claude/workflows`、用户 `.claude/workflows`；同目录重名报错。`maxScriptBytes` 默认 1048576。保存的文件包含元数据与正文，可直接用返回路径重跑。`args` 支持任意 JSON 值，内联脚本不要求文件系统服务。

`tool-workflow/agent-progress` 在成员开始和结束之间持久记录活动。`tokens` 包含输入、缓存与输出，`outputTokens` 单独表示预算消耗。不支持活动遥测的提供方设置 `progressSupported: false`，客户端据此避免误报停滞。

`workflow` 工具运行由模型编写的编排脚本，把工作扇出到多个 subagent，并返回脚本的最终 JSON 值。仅当用户明确要求工作流或大型多 agent 编排时使用——例如跨多个文件的审计、一次迁移、多角度研究；一两项委派时优先使用普通 subagent 调用。

### 调用工具

CLI 元数据支持静态模板字符串，以及用于显示的可选 meta.title。类型错误的可选注解和 title 不是字符串的阶段会被省略，空字符串阶段标题会保留；即使位于忽略字段内，表达式和保留对象键仍被拒绝。完整解析采用严格 JavaScript；超出原生静态子集的语法会使仅头部发现退回完整解析。harness 输入模式保留独立解析器。

CLI 目录内置 deep-research，无需磁盘配置。有效的用户或项目脚本可覆盖内置定义，无效覆盖则保留它。内置流程将字符串问题拆为搜索角度，流水执行搜索、去重和抓取，排序后最多核验 25 条结论，每条请求三个独立核验票。两票反驳会否定结论，票数不足则保持未核验。综合阶段返回引用、限制、来源计数和投票结果。高相关来源可超出名义上的 15 次抓取预算。实际研究需要子 Agent 提供方具备可用的网络搜索和抓取工具。

claude-code 模式下，显式 scriptPath 读取要求调用 Agent 的作用域工具目录包含 Read。工具打开源文件前应用 [Claude Read 设置](../../settings/claude-code-config/README.zh.md#lookup)，读取字节前再次检查解析后的目标。UNC、NT 命名空间及自动挂载路径会在文件系统解析前被拒绝。tool-workflow/read-policy waterfall 提供应用的 Read 可用性、bypass 模式和附加目录；监听器须调用 next() 委托。没有监听器时，仅使用普通 cwd/私有目录准入和设置授权。私有目录来自 workflowEngine.sourceDirectories(parent)，并映射到当前文件系统。内联和注册名称调用不要求 Read。直接调用 resolveWorkflowSource 时，如需 Agent 权限检查，调用者须提供 authorize 回调。

`inputMode: claude-code` 仅公开 script、name、description、title、args、scriptPath 和 resumeFromRunId。所有合法调用都启动所属后台任务，必须启用 enableRunInBackground。Description 和 title 被忽略。脚本必须以字面量元数据导出开头。非空路径优先于名称，名称优先于内联脚本；即使执行其他来源，也先校验显式提供的内联脚本。空路径和空名称视为未提供。名称与路径拒绝控制和不可见字符；内联脚本拒绝制表符与换行符以外的控制字符，长度上限为 524288 个 UTF-16 代码单元。恢复 ID 必须匹配 `^wf_[a-z0-9-]{6,}$`，且必须同时提供脚本来源。注册表接收 .js 文件及可读符号链接。发现时跳过不可读或超大条目，只解析元数据而不检查正文；覆盖项正文语法错误时保留先前定义，唯一的错误定义则在调用时报告语法错误。CLI 文件解码替换无效 UTF-8 字节，字节上限在解码前检查。取消仍会中止发现。引擎仍分别接收脚本体和元数据。默认 inputMode 为 harness，保留下述扩展参数。

工具层接受开头的 `export const meta = {...}`，用 JSON5 解析字面量并剥离声明，绝不执行表达式；有此声明时可省略单独的 meta。引擎依旧只接收分离的 body 与 meta。工具增加 `resumeFromRunId`、`budgetTotal`、命名 `workflows`，成功结果可返回 `scriptPath`。持久记录补充阶段事件及可选的缓存、model、token、耗时和失败原因，重开会话后可恢复展示。

模型提交 `script` 及选项：`meta`（若 script 含字面量导出则可省略的身份数据：`name`、`description`，以及可选的 `whenToUse` 与 `phases`）、`script`（内联 JavaScript 正文，可包含字面量 `export const meta` 头部；其参数描述携带脚本体规则，工具描述携带钩子约定）、`args`（任意可选 JSON 值，原样作为全局变量 `args` 向脚本公开），以及 `run_in_background`（可选；仅在 `enableRunInBackground` 生效时存在）。

脚本无返回值时省略 result 字段与 Return value 部分；显式 null 仍为 JSON 结果。CLI 任务通知也会在值缺失时省略 result 标签。

前台成功返回包络 `{ kind: 'foreground', runId, agentsStarted, result }`，向模型渲染为 `workflow "<name>" completed (<count> agent<optional-s>).`，后接 `Return value:` 与美化打印的 JSON。无法启动的工作流——脚本解析或 meta 校验失败——返回模型可以修正的错误。取消与执行失败返回 `Error: workflow run was cancelled` 或 `Error: workflow run failed: <error>`；部分输出绝不会被报告为成功。

### 运行期间的预期

前台模式等待并释放运行；默认后台模式立即返回任务标识，由任务拥有运行及其清理。中间子代理对话不会加入父级历史。

### 后台运行

省略 `run_in_background` 默认后台执行；同步调用方传 false 或配置 `defaultRunInBackground: false`。名称发现覆盖项目祖先、用户目录及已启用插件的 `plugin:name` 命名空间，包含 manifest 指定路径。嵌套名称／路径调用使用相同解析器。

`run_in_background: true` 会立刻返回 `{ kind: 'background', jobId, runId }`：运行以自有 `workflow` 任务身份注册到 `ctx.jobs`，会话头部任务列表因此从该任务的输出环实时流式显示它的 `phase()`、`log()` 与成员生命周期行，行的进度行跟随当前阶段。没有任何工具步骤信号到达该运行——`job_kill`、列表里的停止控件与 owner 拆除才是取消它的途径。结算即任务的结算：完成的运行把同一份渲染后的返回值作为任务的 result 交出（完成通知宣布它，模型结算后的第一次 `job_output` 携带它一次），被取消的运行以 kill 原因结算为 `killed`，失败的运行以脚本的失败信息结算为 `failed`。没有活体任务注册表与服务于调用方的控制器时调用失败，并点名缺失的组合部件。

`inputMode: claude-code` 提供可调用但不列入模型 schema 的 `RunWorkflow` 别名。配置 `toolName: Workflow` 使用 CLI 规范名称。成功返回 `{ status: "async_launched", taskId, taskType: "local_workflow", workflowName, runId, summary, transcriptDir?, scriptPath? }`；任务标识定位本次执行，运行标识用于恢复。启动文本给出脚本和转录目录。完成时通过 `<task-notification>` 直接送达返回值或失败信息、原始工具调用、恢复指引以及引擎提供的完整输出文件。为 `dsh-tool-jobs` 启用 `claudeCodeTaskStop` 可使用原生取消参数。通用 Harness 模式保留前台／后台结果。

### 配置

| 字段 | 默认值 | 含义 |
|---|---|---|
| `toolName` | `workflow` | 要注册的面向模型工具名称。 |
| `maxResultChars` | `50000` | 渲染结果上限；更长的 JSON 会被截断并附上提示。 |
| `enableRunInBackground` | `true` | 公开 `run_in_background`；关闭后调用同样会被拒绝。 |

生成的[配置目录](../../../docs/config-catalog.zh.md#deepseek-aidsh-tool-workflow)是每个受支持字段的穷尽式真源。

CLI 的 scriptPath 要求目标是身份非零且只有一个硬链接的普通文件。文件系统提供方会在读取前核对规范路径与打开的描述符；可读符号链接仍可使用。注册表发现和默认 harness 模式保留普通字节读取行为。

-----

<a id="understand-the-implementation"></a>
## 理解实现

<details>
<summary>实现细节——点击展开</summary>

本节解释消费方如何与引擎拆分、运行生命周期与记录如何工作；可观察行为已在[使用本包](#use-this-package)中完整说明。

### 设计理念

消费方拥有模型侧 schema、`tool:<toolName>` 系统提示词指导与结果包络；脚本解析、执行、上限与取消位于 `ctx.workflowEngine` 之后，PTC 引擎与 `run_code` 共享 Node 进程约束。使用指导以提示词段的形式随工具插件交付，绝不放入部署 persona。

### 运行生命周期

`execute` 启动运行，并在 `try/finally` 内等待 `run.result`；该结构总会对运行执行 dispose。`exec.signal` 会桥接到 `run.cancel()`，包括启动前已经中止的情况。非 `completed` 结束原因会映射为报告原因的 `isError` 结果；完成时渲染 `{ kind, runId, agentsStarted, result }`，Native 渲染器只会在 `maxResultChars` 处截断该投影。

### 后台生命周期

后台调用在任务 starter 内经 `jobs.start` 注册运行，因此引擎的同步拒绝什么都不会注册，准入预检也先于引擎生成执行。任务的 `done` 链接自 `run.result`：先 dispose（释放失败只告警，绝不 reject 进注册表），再停止镜像，然后把停止原因映射到任务结果。环镜像（`src/record.ts`）按插件订阅一次 `workflow/phase`、`workflow/log` 与成员事件，并把它们路由进被跟踪运行的 `JobHandle` 面（`append` 写行，`updateProgress` 写阶段）；结算后的零星事件找不到被跟踪的运行，对已结算任务的 append 则在注册表内丢弃。

### 持久会话记录

对于根 transport 执行（`exec.parent` 缺省），工具会用 log-only 事件把运行投影到调用方 agent 的会话：`start()` 返回后写 run-start，只记录 `run.id` 匹配的阶段变化、成员活动、开始与结束，并且只在结果可用且 dispose 完全停稳后写 run-end。嵌套 transport 调用照常执行，但不写任何记录。会话追加操作首次失败后，本运行会停止后续记录并只告警一次，留下空记录或合法连续前缀，同时不改变工具结果和清理。包 invariant 会在冷加载与实时追加时拒绝重复 start、未配对成员、仍有开放成员的终点与 run-end 后更新，同时允许缺失终态后缀的连续前缀。

引擎的 `workflow/phase` 会写入 `tool-workflow/phase`，会话日志记录阶段、run 与成员生命周期，Web transcript 由这些记录派生。`workflow/log` 不持久化。后台运行的这些行改经任务观察 record 抵达人类，而 record 的瞬态是设计使然。

阶段记录保留执行器分配的可选 index 和 child kind；成员开始记录保留 phaseIndex。invariant 要求带编号的成员引用已公告且标题匹配的阶段，并拒绝阶段标识变化。缺少这些字段的旧记录仍然有效。参见[阶段迁移指南](../../../docs/upgrade-guide/v0.2.0-rc.2/workflow-phase-identity/guide.zh.md)。

排队与发布前失败事件保存为 tool-workflow/agent-admission。回放保留原始行顺序；agent-start 将实际子代理附加到同一行。运行关闭时可以保留从未发布子代理的排队行。新版读取器接受没有准入记录的旧日志；不认识此必需事件的旧版读取器会拒绝新日志。参见[准入迁移指南](../../../docs/upgrade-guide/v0.2.0-rc.2/workflow-admissions/guide.zh.md)。

### 渲染意图

按[渲染意图 Agent Note](../../../.agents/notes/implemented/architecture/2026-07-02-tool-render-intent-union.zh.md)预先确定：使用 `generic` 卡片，标题为 `workflow: <meta.name>`，直接从 `args.meta.name` 读取——呈现是参数的纯函数——脚本文本作为 `rawInput` 携带。结果继续使用 generic 卡片。

### 源码地图

| 文件 | 职责 |
|---|---|
| [`src/index.ts`](src/index.ts) | 插件入口：工具注册、运行生命周期、后台任务注册、记录器接线 |
| [`src/record.ts`](src/record.ts) | 后台运行进任务输出环的实时进度镜像 |
| [`src/types.ts`](src/types.ts) | log-only 记录事件 payload 及其 `SessionEventMap` 声明 |
| [`src/invariant.ts`](src/invariant.ts) | 不变式配套入口：持久工作流记录协议校验 |

</details>

-----

<a id="further-exploration"></a>
## 进一步探索

当工具级约定不够用时阅读以下页面。这些页面依次介绍共享工作流模型、引擎，以及可供比较的委派工具。

- [工作流子系统](../../../docs/subsystems/workflow.zh.md)——seam 约定、启动请求与事件载荷。
- [工作流 seam](../workflow/README.zh.md)——工具背后的运行与结果词汇。
- [PTC 工作流引擎](../workflow-ptc/README.zh.md)——执行脚本的引擎。
- [subagent 工具](../../subagent/tool-subagent/README.zh.md)——一两项委派时的普通委派替代方案。
- [组地图](../README.zh.md)——工作流能力家族及其包。
- [动态工作流 Agent Note](../../../.agents/notes/implemented/feature/2026-07-05-dynamic-workflows.zh.md)——seam 设计及其决策。

-----

<a id="model-experience"></a>
## 模型体验

### 系统提示词

#### 模型看到什么

在该插件的注册作用域内，每个父级请求都会收到下方的工作流指导。作用域工具限制可以隐藏 schema，而不移除这段独立注册的指导。

##### 工作流指导

```markdown
Use the <toolName> tool ONLY when the user explicitly asks for a workflow or for large multi-agent orchestration: you write a JavaScript script (the tool description documents the exact format) that fans work out across many subagents with phases and structured results. For one or two delegations, prefer plain subagent calls.
```

#### Token 影响

插件启用期间，每个请求都会产生少量固定的指导 token 开销。

#### KV Cache 影响

只要插件作用域与指导文本不变，前缀就保持稳定。启用或 dispose 可能会使从该提示词段起的缓存复用失效。

### 工具 schema

#### 模型看到什么

工具可见时，已生成的默认 [`workflow` schema](../../../docs/tool-catalog.zh.md#deepseek-aidsh-tool-workflow) 包含完整的 JavaScript 钩子与元数据约定；`toolName` 可以重命名该定义，模型会提交脚本、元数据与可选 args。

#### Token 影响

工具可见时，每个请求都会产生较大的固定 schema token 开销。

#### KV Cache 影响

只要 `toolName`、定义与可见性不变，前缀就保持稳定。重命名、插件生命周期或作用域限制可能会使从该 schema 起的缓存复用失效。

### 工具调用历史与结果

#### 模型看到什么

由模型编写的完整脚本、元数据与 args 会保留在 assistant 工具调用中。存在返回值时，前台成功结果精确为 `workflow "<name>" completed (<count> agent<optional-s>).`、换行、`Return value:`、换行，以及美化打印且依赖数据的 JSON；达到上限时，会在新行添加 `… [truncated: <omitted> more characters]`。后台受理结果精确为 `workflow "<name>" started in the background as job <jobId>. Its return value arrives with the completion notice; check on it with job_output, stop it with job_kill.`，同样渲染的值稍后经任务完成播报与 `job_output` 抵达模型。失败结果精确为 `Error: workflow run was cancelled`（可以追加后缀 ` (<error>)`）、`Error: workflow run failed: <error-or-unknown error>` 或防御性的 `Error: workflow run ended abnormally (<reason>)`；没有所属 agent 的调用变为 `Error: workflow tool requires a calling agent (exec.agent was undefined)`。中间子 agent 消息会被省略。

#### Token 影响

调用 token 可能很多，并会保留到压缩（compaction）为止。结果渲染受 `maxResultChars` 限制；子模型 token 与父级保留的上下文相互独立。

#### KV Cache 影响

仅追加；新增可见内容位于可复用请求前缀之后，不会使现有 KV Cache 条目失效。

## 已知限制与延期工作

<a id="known-limitations-and-deferred-work"></a>


这些限制说明该工具尚未支持什么。它们是当前约束，不是任务积压。

- **后台运行不向模型报告中间值**——结算前的 `job_output` 只返回状态；返回值在完成时整体送达，取消仍会丢弃局部输出。
- **Native 结果文本有界**——规范工作流结果保持完整，超过 `maxResultChars` 的 JSON 会在面向模型的投影中截断，而不是存储在检索句柄背后。
- **每次工具注册的工作流策略固定**——提供方选择、上限与工具名称属于部署配置，不是模型调用参数。
- **持久记录只覆盖顶层且只供观察**——嵌套 PTC mode dispatch 不记录；记录故障会刻意退化为不完整前缀，而不改变执行。

<a id="dev-note"></a>
### 开发备注

<details>
<summary>维护者的工作上下文——点击展开</summary>

本开发备注是维护者的工作上下文：尚未决定的开放方向。它明确不具权威性——已交付的行为、限制与既定理由以上文、包代码与相关 Agent Note 为准。

开放方向：记录顶层以外的嵌套分派。

</details>
