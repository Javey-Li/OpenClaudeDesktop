/**
 * Workflow seam vocabulary: the request/run/result types a workflow engine
 * consumes and produces, plus the fields in the `workflow/*` event payloads.
 * Types only (plus the id-brand factory), per the package convention.
 *
 * @module @deepseek-ai/dsh-workflow/types
 */
import type { Branded } from '@deepseek-ai/dsh-brand';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
/** Identifies one workflow run. */
export type WorkflowRunId = Branded<'WorkflowRunId'>;
/**
 * Brand a string as a {@link WorkflowRunId}.
 * @param id - the raw id string (the engine mints UUIDs; tests may pass fixtures).
 * @returns the same string, branded.
 */
export declare function WorkflowRunId(id: string): WorkflowRunId;
/** Identifies one execution attempt, including each resume of the same run. */
export type WorkflowAttemptId = Branded<'WorkflowAttemptId'>;
/** Brand an engine-generated attempt identity.
 * @param id - Raw attempt identity.
 * @returns The same string, branded.
 */
export declare function WorkflowAttemptId(id: string): WorkflowAttemptId;
/**
 * One phase declared in a script's `meta.phases` (progress vocabulary only —
 * phases group agents in observers/UIs; they impose no execution structure).
 */
export interface WorkflowPhase {
    /** The phase title; `phase()` calls match against it by exact string. */
    title: string;
    /** Optional one-line description of what the phase does. */
    detail?: string;
    /** Optional provider override this phase is expected to use (informational). */
    provider?: string;
    /** Optional model override this phase is expected to use (informational). */
    model?: string;
}
/** Activity and cumulative usage observed after a member starts. */
export interface WorkflowAgentProgressInfo {
    /** Current execution attempt, starting at one. */
    attempt?: number;
    /** Provider retry deadline in epoch milliseconds while waiting on a rate limit. */
    retryAt?: number;
    /** Child identity for the current attempt. */
    childId?: SessionId;
    /** The active member's 1-based invocation sequence. */
    seq: number;
    /** Host timestamp of the most recently observed activity, in epoch milliseconds. */
    lastProgressAt: number;
    /** Disjoint input, cache and output usage since this child started. */
    tokens?: number;
    /** Output usage since this child started, used by the run budget. */
    outputTokens?: number;
    /** Number of tool calls observed in this child. */
    toolCalls?: number;
    /** Tool calls whose results have not arrived yet. */
    activeTools?: number;
    /** Name of the latest tool called by this child. */
    lastToolName?: string;
    /** Short display excerpt from the latest tool arguments. */
    lastToolSummary?: string;
    /** Model reported by the local child. */
    model?: string;
}
/**
 * The script's identity block, provided as plain JSON data alongside the
 * script body (the model-facing tool carries it as its `meta` parameter) and
 * validated by the engine before the body runs. `name`/`description` are
 * required; the rest is optional annotation. The field vocabulary matches the
 * Claude Code dynamic-workflows meta block.
 */
export interface WorkflowMeta {
    /** Short kebab-case workflow name (display + persistence key). */
    name: string;
    /** One-line description of what the workflow does. */
    description: string;
    /** Optional display title; the workflow name remains its lookup and execution identity. */
    title?: string;
    /** Optional guidance on when this workflow applies (shown in listings). */
    whenToUse?: string;
    /** Optional phase declarations matched by `phase()` calls. */
    phases?: WorkflowPhase[];
}
/**
 * Why a run settled. CLOSED union (engine-owned, consumers may exhaust):
 * `completed` = the script ran to its final `return`; `cancelled` = the run
 * was cancelled (caller `cancel()`/signal); `error` = the script threw, a
 * fatal `WorkflowError` propagated, or the result failed materialization.
 */
export type WorkflowStopReason = 'completed' | 'cancelled' | 'error';
/**
 * The outcome resolved by a live workflow run. `value` is
 * the script's JSON-compatible return value (`undefined` when the script has no return value) — meaningful only for `completed`.
 * A non-`completed` reason carries the failure in `error`; the consumer maps
 * it to an `isError` tool result rather than reporting partial output.
 */
export interface WorkflowResult {
    /** The script's return value; undefined is distinct from an explicit null. */
    value: unknown;
    /** Why the run settled. */
    stopReason: WorkflowStopReason;
    /** The failure message (present iff `stopReason` is not `completed`). */
    error?: string;
    /**
     * How many `agent()` calls the run accepted over its whole lifetime. On a
     * graceful settlement this is the script-side count (calls still queued for
     * a concurrency slot included); on a termination path (cancellation or
     * process failure) it degrades to the host-observed count — calls queued
     * inside a terminated script are unknowable then.
     */
    agentsStarted: number;
    /** Saved script location, when supported by the engine. */
    scriptPath?: string;
}
/** Identifying detail for a run, carried by every `workflow/*` event as borrowed immutable data, never the live run. */
export interface WorkflowRunInfo {
    /** The run's id. */
    id: WorkflowRunId;
    /** Distinguishes resumed executions; absent on engines without resume identity reuse. */
    attemptId?: WorkflowAttemptId;
    /** The run's validated meta block. */
    meta: WorkflowMeta;
}
/** Stable progress group identity assigned by the execution, including reserved child groups. */
export interface WorkflowPhaseInfo {
    /** One-based index; empty child groups can leave gaps in announced records. */
    index: number;
    /** Child grouping marker, fixed by the first reservation of this title. */
    kind?: 'child';
}
/** One uncached invocation queued before a child exists, or failed before publication. */
export interface WorkflowAgentAdmissionInfo {
    /** One-based invocation sequence, shared with a later agent-start. */
    seq: number;
    /** Normalized display label; an empty label is valid. */
    label: string;
    /** Captured phase title at invocation. */
    phase?: string;
    /** Execution-assigned phase identity. */
    phaseIndex?: number;
    /** Requested model, when specified. */
    model?: string;
    /** Requested named agent and isolation policy. */
    agentType?: string;
    isolation?: string;
    /** Queue registration or failure before a child was published. */
    state: 'queued' | 'failed';
    /** Unix milliseconds captured before waiting for concurrency. */
    queuedAt: number;
    /** Unix milliseconds of this admission observation. */
    lastProgressAt: number;
    /** Prompt preview using the Workflow diagnostic limit. */
    promptPreview?: string;
    /** Failure detail, required for failed admissions and absent for queued calls. */
    error?: string;
}
/** One `agent()` call's identity within a run (the `workflow/agent-start` payload). */
export interface WorkflowAgentInfo {
    /** 1-based sequence number of this `agent()` call within the run. */
    seq: number;
    /** The display label (the `label` option, or a prompt snippet). */
    label: string;
    /** The phase this agent belongs to (the `phase` option, else the current `phase()` title). */
    phase?: string;
    /** Execution-assigned phase index; absent for unphased calls and older providers. */
    phaseIndex?: number;
    /** The child agent's id on the subagent seam. */
    childId: SessionId;
    /** True when this call reuses a journal result without launching a child. */
    cached?: boolean;
    /** Effective requested model, when explicitly selected. */
    model?: string;
    /** Whether the child reports activity while running. */
    progressSupported?: boolean;
}
/** How one `agent()` call settled: clean result, child failure (script sees `null`), or run cancellation. */
export type WorkflowAgentOutcome = 'completed' | 'failed' | 'cancelled';
/** One `agent()` call's settlement (the `workflow/agent-end` payload). */
export interface WorkflowAgentEndInfo extends WorkflowAgentInfo {
    /** How the call settled. */
    outcome: WorkflowAgentOutcome;
    /** Provider-reported input, cache and output tokens, excluding inherited history. */
    tokens?: number;
    /** Output tokens charged to this run's budget. Cached calls spend zero. */
    outputTokens?: number;
    /** Provider-authored failure detail, when available. */
    error?: string;
    /** Elapsed child time, excluding the queue. */
    durationMs?: number;
}
/**
 * A settled run's outcome as event data (the `workflow/end` payload): the
 * {@link WorkflowResult} minus `value` (a listener observing outcomes must not
 * receive a mutable alias of the caller's result value; a consumer that needs
 * the value holds the run and awaits `result`).
 */
export interface WorkflowResultInfo {
    /** Why the run settled. */
    stopReason: WorkflowStopReason;
    /** The failure message (present iff `stopReason` is not `completed`). */
    error?: string;
    /** How many `agent()` calls the run accepted (see {@link WorkflowResult.agentsStarted}). */
    agentsStarted: number;
    /** Saved script location, when supported by the engine. */
    scriptPath?: string;
}
//# sourceMappingURL=types.d.ts.map