/**
 * Service Definition for the workflow capability seam. Service Providers execute orchestration scripts;
 * observe-only lifecycle events never expose run control.
 * @module @deepseek-ai/dsh-workflow
 */
import { Context, Service } from '@deepseek-ai/cordis';
import { HarnessError } from '@deepseek-ai/dsh-llm';
import type { WorkflowAgentAdmissionInfo, WorkflowAgentEndInfo, WorkflowAgentInfo, WorkflowAgentProgressInfo, WorkflowResultInfo, WorkflowRunInfo, WorkflowRunId, WorkflowPhaseInfo } from './types.ts';
import type { WorkflowRun, WorkflowStartRequest } from './runtime-types.ts';
export { WorkflowRunId, WorkflowAttemptId } from './types.ts';
export type { WorkflowAgentAdmissionInfo, WorkflowAgentEndInfo, WorkflowAgentInfo, WorkflowAgentProgressInfo, WorkflowAgentOutcome, WorkflowMeta, WorkflowPhase, WorkflowPhaseInfo, WorkflowResult, WorkflowResultInfo, WorkflowRunInfo, WorkflowStopReason, } from './types.ts';
export type { WorkflowRun, WorkflowStartRequest } from './runtime-types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        workflowEngine: WorkflowEngine;
    }
    interface Events {
        /**
         * A workflow run started — the script's meta block validated, the body
         * about to execute. Paired with {@link Events['workflow/end']}.
         * @param info - the run's identity snapshot (id + meta).
         * @mode emit
         */
        'workflow/start'(info: WorkflowRunInfo): void;
        /**
         * A phase is first announced, including metadata and per-agent phases.
         * Repeated titles reuse the execution-assigned identity.
         * @param info - the run's identity snapshot.
         * @param title - the phase title, verbatim.
         * @param phase - execution-assigned identity, absent on older providers.
         * @mode emit
         */
        'workflow/phase'(info: WorkflowRunInfo, title: string, phase?: WorkflowPhaseInfo): void;
        /**
         * The script emitted a narration line (a `log(message)` call).
         * @param info - the run's identity snapshot.
         * @param message - the logged message, verbatim.
         * @mode emit
         */
        'workflow/log'(info: WorkflowRunInfo, message: string): void;
        /**
         * An uncached call entered the queue or failed before publishing a child.
         * Queue observations do not expose member control or require an agent-end.
         * @param info - The owning workflow run.
         * @param agent - Invocation identity, queue timestamps, and optional failure.
         * @mode emit
         */
        'workflow/agent-admission'(info: WorkflowRunInfo, agent: WorkflowAgentAdmissionInfo): void;
        /**
         * One `agent()` call established a published child run. Paired with
         * {@link Events['workflow/agent-end']} by `agent.seq`. A call that never
         * receives a published run from the provider emits neither
         * event in this pair.
         * @param info - the run's identity snapshot.
         * @param agent - the call's sequence number, label, phase, and child id.
         * @mode emit
         */
        'workflow/agent-start'(info: WorkflowRunInfo, agent: WorkflowAgentInfo): void;
        /**
         * An established child reported activity or usage; never controls the child.
         * @param info - The owning workflow run.
         * @param agent - Member sequence and observed cumulative progress.
         * @mode emit
         */
        'workflow/agent-progress'(info: WorkflowRunInfo, agent: WorkflowAgentProgressInfo): void;
        /**
         * One `agent()` call settled (clean result, child failure, or run
         * cancellation). Paired with {@link Events['workflow/agent-start']} by
         * `agent.seq`, exactly once per started call on every stop path — on an
         * engine termination path the end is
         * engine-synthesized with outcome `'cancelled'`.
         * @param info - the run's identity snapshot.
         * @param agent - the call identity plus its outcome.
         * @mode emit
         */
        'workflow/agent-end'(info: WorkflowRunInfo, agent: WorkflowAgentEndInfo): void;
        /**
         * A workflow run settled (any stop reason). Fired when
         * {@link WorkflowRun.result} resolves. Paired with
         * {@link Events['workflow/start']}.
         * @param info - the run's identity snapshot.
         * @param result - the outcome data (stop reason, error, agent count) —
         *   deliberately WITHOUT the result value (see {@link WorkflowResultInfo}).
         * @mode emit
         */
        'workflow/end'(info: WorkflowRunInfo, result: WorkflowResultInfo): void;
    }
}
/** The full set of `workflow/*` event names {@link WorkflowEngine.emitWorkflowEvent} dispatches. */
export type WorkflowEventName = 'workflow/start' | 'workflow/phase' | 'workflow/log' | 'workflow/agent-admission' | 'workflow/agent-start' | 'workflow/agent-progress' | 'workflow/agent-end' | 'workflow/end';
/**
 * Machine-routable workflow failures: parse/meta/argument/schema errors,
 * resource caps, subagent infrastructure failures, unserializable boundary
 * values, and cancellation. An ordinary child failure resolves its item to
 * `null` without throwing one of these codes.
 */
export type WorkflowErrorCode = 'SCRIPT_PARSE' | 'META_INVALID' | 'INVALID_ARGUMENT' | 'UNSUPPORTED_OPTION' | 'UNSUPPORTED_SCHEMA' | 'AGENT_CAP' | 'ITEM_CAP' | 'AGENT_START' | 'AGENT_RESULT' | 'RESULT_UNSERIALIZABLE' | 'CANCELLED' | 'RESUME_UNAVAILABLE' | 'BUDGET_EXCEEDED';
/**
 * Typed error for workflow-seam failures. Extends {@link HarnessError}, so the
 * `code` is machine-routable taxonomy. The legacy `fatal` flag remains available
 * to consumers; PTC combinators contain every per-item exception as null.
 * Uncaught exceptions outside combinators fail the script.
 */
export declare class WorkflowError extends HarnessError {
    /** Legacy severity hint for consumers; not a PTC combinator propagation rule. */
    readonly fatal: boolean;
    constructor(message: string, code: WorkflowErrorCode, options?: ErrorOptions & {
        fatal?: boolean;
    });
}
/**
 * Read the legacy severity hint without imposing a combinator error policy.
 * @param error - any thrown value; fatality is host `instanceof` (unforgeable from a script realm).
 * @returns true iff `error` is a {@link WorkflowError} whose `fatal` flag is set.
 */
export declare function isFatalWorkflowError(error: unknown): boolean;
/**
 * Workflow Service Definition contract. Invalid requests throw before publication; a live
 * run is holder-owned, its result never rejects, and disposal waits for script
 * and child cleanup. Lifecycle
 * listener failures are contained, and `workflow/end` fires exactly once as the
 * result settles.
 */
export declare abstract class WorkflowEngine extends Service {
    constructor(ctx: Context);
    /**
     * Parse and execute a workflow script.
     * @param request - the script, its `args`, the parent agent, and an
     *   optional cancel signal.
     * @returns the live run; its `result` resolves when the script settles.
     */
    abstract start(request: WorkflowStartRequest): WorkflowRun;
    /**
     * Restore retained same-Session data before resolving a resume source.
     * @param parent - Agent owning the prior run and retained Session records.
     * @param id - Run to resume; active runs must remain untouched.
     * @param scriptPath - Optional source path in the execution world; callers authorize Read before preparing it.
     */
    prepareResume(parent: WorkflowStartRequest['parent'], id: WorkflowRunId, scriptPath?: string): void;
    /**
     * Return private source directories owned by the requesting Agent's Session.
     * @param parent - The Agent whose saved scripts may be read again.
     * @returns Absolute host paths; consumers must map them into their execution world. Unsupported engines return none.
     */
    sourceDirectories(parent: WorkflowStartRequest['parent']): readonly string[];
    /**
     * Control a member only when the requesting Agent owns the live run.
     * @param parent - The requesting live Agent.
     * @param id - Workflow identity within that Agent.
     * @param seq - One-based member invocation number.
     * @param action - Skip returns null; retry starts another attempt.
     * @returns Whether the engine accepted the action; unsupported engines return false.
     */
    controlMember(parent: WorkflowStartRequest['parent'], id: WorkflowRunId, seq: number, action: 'skip' | 'retry'): boolean;
    /**
     * Emit a lifecycle event while containing and logging each listener failure.
     * @param name - the `workflow/*` event to dispatch.
     * @param args - the event's payload, matching its declared signature.
     */
    protected emitWorkflowEvent(name: WorkflowEventName, ...args: unknown[]): void;
}
export default WorkflowEngine;
//# sourceMappingURL=index.d.ts.map