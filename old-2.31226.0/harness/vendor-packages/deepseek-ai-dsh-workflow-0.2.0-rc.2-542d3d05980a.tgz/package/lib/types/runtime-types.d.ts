/**
 * Host-only workflow request and live-run handles. The browser-safe durable
 * vocabulary remains in `./types` so Client programs never import Agent or
 * host Cordis context declarations.
 *
 * @module @deepseek-ai/dsh-workflow
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { WorkflowMeta, WorkflowResult, WorkflowRunId, WorkflowAttemptId } from './types.ts';
/**
 * What a caller asks for when starting a workflow run. `meta` and `args` are
 * plain JSON data by the seam contract. `parent` is required because every
 * `agent()` spawned by the script is attributed to that live Agent.
 */
export interface WorkflowStartRequest {
    /** The plain-JS script body (top-level await allowed; ends with `return <json-value>`). */
    script: string;
    /** Resolved source path in the execution world; returned unchanged, never written by the engine. */
    scriptPath?: string;
    /** The workflow's identity block, as plain JSON data (shape-validated by the engine). */
    meta: WorkflowMeta;
    /** Optional input exposed verbatim to the script as the `args` global. */
    args?: unknown;
    /** Optional engine-wide child-provider override for this run. */
    subagentProvider?: string;
    /** Optional per-run total-child ceiling. */
    maxTotalAgents?: number;
    /** Resume matching calls under the same run identity; the previous execution must have settled. */
    resumeFromRunId?: WorkflowRunId;
    /** Output-token admission ceiling against parent-turn usage; null, absent or zero disables admission checks. */
    budgetTotal?: number | null;
    /** Named nested scripts. Each script carries its identity as data. Nesting is one level. */
    workflows?: Record<string, {
        script: string;
        meta: WorkflowMeta;
    }>;
    /** Load a nested script in the caller's execution world; the run owns cancellation. */
    resolveWorkflow?: (source: {
        name?: string;
        scriptPath?: string;
    }, signal: AbortSignal) => Promise<{
        script: string;
        meta: WorkflowMeta;
    }>;
    /** Host-supplied origin context; script output cannot populate these fields. */
    origin?: {
        userRequest?: string;
        assistantContext?: string;
        automatedTrigger?: string;
    };
    /** The agent on whose behalf the run executes (parent of every child). */
    parent: Agent;
    /** Cancels the run when aborted. */
    signal?: AbortSignal;
}
/**
 * Holder-owned live workflow. `result` never rejects; consumers may cancel
 * and must call idempotent `dispose()` to await script and child quiescence.
 */
export interface WorkflowRun {
    readonly id: WorkflowRunId;
    /** Unique execution identity when the engine supports resuming the same run ID. */
    readonly attemptId?: WorkflowAttemptId;
    /** The validated meta block available before the script body runs. */
    readonly meta: WorkflowMeta;
    /** Saved script for inspection and iteration. */
    readonly scriptPath?: string;
    /** Private directory containing this run’s durable invocation records. */
    readonly transcriptDir?: string;
    /** Complete terminal output file, available only after durable publication. */
    readonly outputFile?: string | undefined;
    readonly result: Promise<WorkflowResult>;
    /** Cancel the run and its children. */
    cancel(reason?: string): void;
    /** Skip or restart one active member; false means the member is no longer active. */
    controlMember?(seq: number, action: 'skip' | 'retry'): boolean;
    /** Cancel if needed and await script and child cleanup. */
    dispose(): Promise<void>;
}
//# sourceMappingURL=runtime-types.d.ts.map