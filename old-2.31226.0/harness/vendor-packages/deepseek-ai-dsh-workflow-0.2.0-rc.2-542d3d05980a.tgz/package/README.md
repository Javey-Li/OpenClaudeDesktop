---
description: "The workflow orchestration capability: run a model-written script that fans out subagents, for users and maintainers choosing or building on ctx.workflowEngine."
kind: "package-reference"
---

# @deepseek-ai/dsh-workflow

English | [中文](README.zh.md)

## Summary

Run a plain-JavaScript orchestration script that fans work out to subagents and returns the script's final JSON value. Scripts can use `agent()`, `parallel()`, `pipeline()`, `phase()`, and `log()`; models normally access them through the `workflow` tool. Each run belongs to its caller, attributes every child to the invoking agent, resolves failures and cancellation without rejecting its result, and awaits script and child cleanup during disposal. The caller must supply an execution engine, allowing the isolation strategy to change without altering visible behavior.

## Table of Contents

- [Use this package](#use-this-package)
- [Understand the implementation](#understand-the-implementation)
- [Further Exploration](#further-exploration)
- [Model Experience](#model-experience)
- [Known Limitations and Deferred Work](#known-limitations-and-deferred-work)
- [Dev Note](#dev-note)

Resuming through the PTC engine retains runId and creates a new attemptId. Route observer events and durable records by attemptId when present; legacy records use runId. Stop the prior execution and await cleanup before resuming. Explicit script paths are retained for editing and rerunning.

-----

`prepareResume(parent, id, scriptPath?)` lets a consumer request same-Session recovery before resolving a source file. Explicit paths must pass the consumer’s Read admission first. The default engine method does nothing; providers may restore missing private files and reject unavailable or active runs.

<a id="use-this-package"></a>
## Use this package

WorkflowMeta.title is an optional display annotation. WorkflowMeta.name remains the lookup and execution identity; missing titles retain name-based display. Phase titles are exact strings, including empty strings.

`workflow/agent-progress` carries read-only activity snapshots between member start and end. Total usage includes input, cache and output; output-only usage is a separate budget field.

Run a workflow when a task decomposes into many independent pieces that one script should coordinate — an audit across many files, a migration, multi-angle research — and the model explicitly asks for workflow-style orchestration. For one or two delegations, prefer a plain subagent call.

### The model-facing path

The model reaches this capability through `dsh-tool-workflow`. Background execution is the default and returns job/run identifiers immediately; completion delivers the final result. Set `run_in_background: false` to await the JSON result. Intermediate child conversations stay outside the parent conversation.

### Running a workflow script

An orchestration script is a plain JavaScript body (not TypeScript) that runs with top-level `await` and ends with `return <json-value>`. The `meta` identity block and any `args` arrive as plain JSON data — never evaluated code. During execution the script calls the provided hooks: `agent(prompt, opts)` starts one subagent and resolves with its final text or, with a schema, a validated structured value; `parallel()` and `pipeline()` combine independent work; `phase()` and `log()` narrate progress for observers.

```text
// Script body — runs with top-level await, ends with a JSON return value:
const reviews = await parallel([
  () => agent('Review src/a.ts for correctness'),
  () => agent('Review src/b.ts for correctness'),
])
return { reviewed: reviews.length }
```

When the script settles, the run's result resolves with the returned value, the stop reason, and the number of children started. A script that returns nothing yields `null`.

### Programmatic runs

Plugin consumers can start a run directly: `ctx.workflowEngine.start({ script, meta, args?, parent, signal? })`. `parent` attributes every child to the invoking agent; `signal` cancels the run when aborted. `start()` validates the meta block and parses the script before a run exists, so a malformed request fails immediately with a violation list.

A returned run exposes `id`, `meta`, optional `scriptPath`, `result`, `cancel(reason?)`, and `dispose()`. The result never rejects: a script failure resolves with `stopReason: 'error'`, cancellation with `'cancelled'`. The caller owns the run — call `dispose()` on every path; it cancels remaining work and waits for script and child cleanup under the providers' lifecycle contracts.

A run may expose `transcriptDir` for durable invocation records and, after settlement, `outputFile` for the complete terminal output. Consumers must check these optional capabilities before presenting file paths.

### Failures and recovery

Invalid scripts, metadata and routes fail before publication. An ordinary child failure returns null. `parallel()` and `pipeline()` await every item and contain each item exception, including argument and budget errors, as null. Uncaught exceptions outside combinators fail the script.

-----

<a id="understand-the-implementation"></a>
## Understand the implementation

`sourceDirectories(parent)` returns the requesting Session’s private source roots as host paths. Providers without saved scripts return an empty list. Consumers map these roots into their execution-world filesystem before applying Read admission; unrelated Sessions receive no grant.

<details>
<summary>Implementation internals — click to expand</summary>

This section explains how the capability is split and where the contracts live; observable behavior is fully covered in [Use this package](#use-this-package).

### Design concept

The package separates the script, run, result, and event contracts from execution: any engine can implement `ctx.workflowEngine` behind the same vocabulary, and one engine serves a context at a time — loading a second engine fails loudly, so swapping engines means changing which engine plugin the composition loads. The `workflow/*` events are observe-only: payloads carry run identity snapshots, never the live run, so listeners cannot acquire cancellation or disposal authority.

### Source map

| File | Role |
|---|---|
| [`src/index.ts`](src/index.ts) | Service definition, `workflow/*` event declarations, `WorkflowError` and its fatal flag |
| [`src/types.ts`](src/types.ts) | Browser-safe vocabulary: `WorkflowMeta`, `WorkflowResult`, run and agent event info |
| [`src/runtime-types.ts`](src/runtime-types.ts) | Host-only `WorkflowStartRequest` and `WorkflowRun` handles |
| [`src/invariant.ts`](src/invariant.ts) | Invariant companion: event pairing and identity checks |

### Lifecycle and ownership

A run is holder-owned: engine-plugin unload prevents new starts but does not revoke accepted runs, and the caller must dispose every run it starts. `dispose()` cancels if needed and awaits script and child cleanup. The PTC engine aborts its managed process immediately; child disposal still follows each subagent provider's lifecycle contract.

`workflow/start` and `workflow/end` pair the run; `workflow/phase` announces stable progress groups and `workflow/log` carries script narration; `workflow/agent-start` and `workflow/agent-end` pair each child call by `seq`. Every listener is independently contained: a throwing listener is logged without starving peers or changing execution, and each receives its own payload clone.

`workflow/agent-admission` reports an uncached call before a child exists, then optionally reports failure before publication. Its seq and captured phase match a later agent-start; queued calls have no child handle and require no agent-end. Run agent counts include queued and pre-publication failures.

### Failure discipline

`WorkflowError.code` identifies the failure. The legacy `fatal` flag remains available to consumers and does not control PTC combinator propagation. Combinators contain item exceptions; uncaught exceptions fail the script.

The per-item `null` is reserved for child-run failures and ordinary in-stage script errors, so a child that resolves normally with a non-completed stop reason is not an infrastructure exception: `agent()` returns `null`, letting the script handle an ordinary child failure.

</details>

-----

<a id="further-exploration"></a>
## Further Exploration

Read these pages when the package-level contract is not enough. They move from the shared workflow model to the current engine and the model-facing consumers.

- [Workflow subsystem](../../../docs/subsystems/workflow.md) — the full type vocabulary, start request, and event payloads.
- [Group map](../README.md) — the workflow capability family and its packages.
- [workflow tool](../tool-workflow/README.md) — the model-facing consumer that owns the call schema and result envelope.
- [PTC workflow engine](../workflow-ptc/README.md) — the current execution engine and its isolation boundary.
- [Dynamic workflows Agent Note](../../../.agents/notes/implemented/feature/2026-07-05-dynamic-workflows.md) — the seam design and its decisions.

-----

<a id="model-experience"></a>
## Model Experience

Indirectly, through its consumer `dsh-tool-workflow` and a workflow engine, which render the parent tool result and the child-agent requests.

#### KV Cache effect

No direct invalidation; the named consumer and engine own any request-prefix changes.

## Known Limitations and Deferred Work

<a id="known-limitations-and-deferred-work"></a>


These limits define what the capability does not yet support. They are current constraints, not a task backlog.

- **Engine-owned recovery** — `resumeFromRunId`, `budgetTotal`, named `workflows` and host origin context are optional request extensions; PTC behavior is documented by its engine.

<a id="dev-note"></a>
### Dev Note

<details>
<summary>Working context for maintainers — click to expand</summary>

This Dev Note is working context for maintainers: open directions that are not decided. It is explicitly non-authoritative — shipped behavior, limits, and accepted rationale live in the sections above, the package code, and the linked Agent Notes.

Deferred direction: spill large returned values into separately retrievable artifacts.

</details>
