---
description: "工作流编排能力：运行由模型编写的、扇出 subagent 的脚本，供选择或构建在 ctx.workflowEngine 之上的用户与维护者阅读。"
kind: "package-reference"
---

# @deepseek-ai/dsh-workflow

[English](README.md) | 中文

## 概述

运行一段纯 JavaScript 编排脚本，将工作扇出给 subagent，并返回脚本的最终 JSON 值。脚本可以使用 `agent()`、`parallel()`、`pipeline()`、`phase()` 和 `log()`；模型通常通过 `workflow` 工具访问它们。每次运行都归调用方所有，将每个子 agent（智能体）归属于调用它的 agent，在失败或取消时以结果兑现而不拒绝，并在 dispose（资源释放）期间等待脚本与子 agent 清理完成。调用方必须提供执行引擎，因此可以更换隔离策略而不改变可见行为。


## 目录

- [使用本包](#use-this-package)
- [理解实现](#understand-the-implementation)
- [进一步探索](#further-exploration)
- [模型体验](#model-experience)
- [已知限制与延期工作](#known-limitations-and-deferred-work)
- [开发备注](#dev-note)

通过 PTC 引擎恢复时保留 runId，并生成新的 attemptId。观察事件与持久记录在存在 attemptId 时按它关联，旧记录使用 runId。恢复前须停止上次执行并等待清理完成。显式脚本路径会保留，供编辑和重跑。

-----

`prepareResume(parent, id, scriptPath?)` 让消费方在解析脚本文件前请求同 Session 恢复。显式路径必须先通过消费方的 Read 准入。默认引擎方法不执行操作；提供方可以恢复缺失私有文件，并拒绝不可用或仍活跃的运行。

<a id="use-this-package"></a>
## 使用本包

WorkflowMeta.title 是可选显示注解。WorkflowMeta.name 仍用于查找和执行标识；缺少标题时继续显示名称。阶段标题按精确字符串处理，包括空字符串。

`workflow/agent-progress` 在成员开始与结束之间传递只读活动快照。总用量包含输入、缓存与输出；输出预算使用独立字段。

当任务分解为许多独立部分、适合用一段脚本统一协调——例如跨多个文件的审计、一次迁移、多角度研究——且模型明确要求工作流式编排时，运行工作流。一两项委派时，优先使用普通 subagent 调用。

### 模型侧路径

模型通过 `dsh-tool-workflow` 的 `workflow` 工具运行脚本。默认后台运行立即返回 job/run 标识，完成后送达结果；`run_in_background: false` 等待最终 JSON 结果。中间子代理对话不会进入父级对话。

### 运行工作流脚本

编排脚本是纯 JavaScript 脚本体（不是 TypeScript），以顶层 `await` 运行并以 `return <json-value>` 结尾。`meta` 身份块与任何 `args` 都以普通 JSON 数据到达——绝不作为代码求值。执行期间脚本调用提供的钩子：`agent(prompt, opts)` 启动一个 subagent，并以其最终文本、或在提供 schema 时以经过校验的结构化值兑现；`parallel()` 与 `pipeline()` 组合独立工作；`phase()` 与 `log()` 为观察者叙述进度。

```text
// Script body — runs with top-level await, ends with a JSON return value:
const reviews = await parallel([
  () => agent('Review src/a.ts for correctness'),
  () => agent('Review src/b.ts for correctness'),
])
return { reviewed: reviews.length }
```

脚本结算时，运行的 result 以返回值、结束原因和已启动的子 agent 数量兑现。脚本不返回值时得到 `null`。

### 编程方式运行

请求支持恢复、输出预算、命名定义和 `resolveWorkflow` 嵌套加载回调。PTC 在父级轮次内共享输出用量；脱离轮次启动的直接运行使用独立预算。结果永不拒绝，持有者负责释放。

插件消费方可以直接启动运行：`ctx.workflowEngine.start({ script, meta, args?, parent, signal? })`。`parent` 把每个子 agent 归属于调用它的 agent；`signal` 在中止时取消运行。`start()` 在运行存在之前校验 meta 块并解析脚本，因此格式错误的请求会立即以违规清单失败。

返回的运行公开 `id`、`meta`、可选 `scriptPath`、`result`、`cancel(reason?)` 与 `dispose()`。result 绝不拒绝：脚本失败以 `stopReason: 'error'` 兑现，取消以 `'cancelled'` 兑现。调用方拥有该运行——每条路径都要调用 `dispose()`；它会取消剩余工作，并按提供方的生命周期约定等待脚本与子 agent 清理完成。

运行可通过 `transcriptDir` 提供持久调用记录目录，并在结算后通过 `outputFile` 提供完整终态输出。消费者展示文件路径前必须检查这些可选能力。

### 失败与恢复

启动前拒绝无效脚本、元数据或路由。普通子代理失败返回 `null`。`parallel()` / `pipeline()` 等待全部条目，并将每项异常（含参数和预算错误）转为 `null`；组合器外未捕获的异常使脚本失败。

-----

<a id="understand-the-implementation"></a>
## 理解实现

`sourceDirectories(parent)` 返回请求 Session 的私有源文件宿主路径根目录。不保存脚本的提供方返回空列表。消费者先将根目录映射到执行环境的文件系统，再应用 Read 准入；其他 Session 不会因此获得授权。

<details>
<summary>实现细节——点击展开</summary>

本节解释能力如何拆分、约定位于何处；可观察行为已在[使用本包](#use-this-package)中完整说明。

### 设计理念

本包把脚本、运行、结果与事件约定同执行分开：任何引擎都可以在同一词汇背后实现 `ctx.workflowEngine`，一个上下文同时只有一个引擎——加载第二个引擎会明确报错，因此更换引擎意味着更改组合所加载的引擎插件。`workflow/*` 事件只供观察：payload 携带运行身份快照，绝不携带活动运行，因此监听器无法取得取消或 dispose 权限。

### 源码地图

| 文件 | 职责 |
|---|---|
| [`src/index.ts`](src/index.ts) | 服务定义、`workflow/*` 事件声明、`WorkflowError` 及其 fatal 标志 |
| [`src/types.ts`](src/types.ts) | 浏览器安全词汇：`WorkflowMeta`、`WorkflowResult`、运行与 agent 事件信息 |
| [`src/runtime-types.ts`](src/runtime-types.ts) | 仅宿主的 `WorkflowStartRequest` 与 `WorkflowRun` 句柄 |
| [`src/invariant.ts`](src/invariant.ts) | 不变式伴生插件：事件配对与身份校验 |

### 生命周期与归属

运行由持有方负责：引擎插件卸载会阻止新的启动，但不会撤销已接受的运行，调用方必须 dispose 自己启动的每个运行。`dispose()` 在需要时取消，并等待脚本与子 agent 清理完成。PTC 引擎立即中止受管进程；子 agent 的资源释放仍遵循各 subagent 提供方的生命周期约定。

`workflow/start` 与 `workflow/end` 为运行配对；`workflow/phase` 公告稳定的进度分组，`workflow/log` 携带脚本叙述；`workflow/agent-start` 与 `workflow/agent-end` 按 `seq` 为每次子 agent 调用配对。每个监听器都独立隔离：抛错的监听器只记录日志，不会饿死同级监听器或改变执行，并且每个监听器都会收到自己的 payload 副本。

`workflow/agent-admission` 在子代理存在前报告未命中缓存的调用，也可随后报告发布前失败。它的 seq 和已捕获阶段与后续 agent-start 一致；排队调用没有子代理句柄，也不要求 agent-end。运行调用数包括排队调用和发布前失败。

### 失败纪律

`WorkflowError` 的 code 标识错误种类；保留的 `fatal` 标志供旧消费方读取，不再决定 PTC 组合器是否抛错。逐项异常被组合器隔离，未捕获异常才使脚本失败。

持有者可用 `run.controlMember(seq, action)` 跳过或重试活动成员；服务方法要求提供相同父级对象以校验所有权。重试保留逻辑调用序号与累计用量。

</details>

-----

<a id="further-exploration"></a>
## 进一步探索

当包级契约不够用时阅读以下页面。它们从共享工作流模型逐步进入当前引擎与面向模型的消费方。

- [工作流子系统](../../../docs/subsystems/workflow.zh.md)——完整类型词汇、启动请求与事件载荷。
- [组地图](../README.zh.md)——工作流能力家族及其包。
- [workflow 工具](../tool-workflow/README.zh.md)——拥有调用 schema 与结果包络的模型侧消费方。
- [PTC 工作流引擎](../workflow-ptc/README.zh.md)——当前执行引擎及其隔离边界。
- [动态工作流 Agent Note](../../../.agents/notes/implemented/feature/2026-07-05-dynamic-workflows.zh.md)——seam 设计及其决策。

-----

<a id="model-experience"></a>
## 模型体验

间接地，通过其消费方 `dsh-tool-workflow` 与一个工作流引擎，由它们渲染父级工具结果与子 agent 请求。

#### KV Cache 影响

不会直接导致失效；请求前缀的任何变化均由上述消费方与引擎负责。

## 已知限制与延期工作

<a id="known-limitations-and-deferred-work"></a>


这些限制说明该能力尚未支持什么。它们是当前约束，不是任务积压。

- **恢复由引擎负责**——`resumeFromRunId`、`budgetTotal`、命名 `workflows` 与宿主来源上下文均为可选请求扩展；具体 PTC 行为由引擎文档定义。

<a id="dev-note"></a>
### 开发备注

<details>
<summary>维护者的工作上下文——点击展开</summary>

本开发备注是维护者的工作上下文：尚未决定的开放方向。它明确不具权威性——已交付的行为、限制与既定理由以上文、包代码与相关 Agent Note 为准。

延期方向：将较大的返回值存为可单独检索的产物。

</details>
