/** Shared validation for provider-owned history-repair coordinates. */
import type { LlmFailure } from './types.ts';
/**
 * Validate a whole-history or positioned reasoning omission without reading provider payloads.
 * @param value - untrusted recovery metadata.
 * @returns whether the metadata is a canonical recovery decision.
 */
export declare function isReasoningRecovery(value: unknown): value is NonNullable<LlmFailure['reasoningRecovery']>;
//# sourceMappingURL=reasoning-recovery.d.ts.map