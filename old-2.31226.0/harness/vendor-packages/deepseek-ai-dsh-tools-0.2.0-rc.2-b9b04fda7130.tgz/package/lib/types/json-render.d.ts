/** Stack-safe JSON rendering for tool transcripts and program results. */
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
/**
 * Render JSON without recursive traversal or unbounded indentation growth.
 * @param value - a detached JSON value.
 * @param compact - omit presentation whitespace when recording tool arguments.
 * @returns JSON text for the complete value.
 */
export declare function renderJsonValue(value: JsonValue, compact?: boolean): string;
//# sourceMappingURL=json-render.d.ts.map