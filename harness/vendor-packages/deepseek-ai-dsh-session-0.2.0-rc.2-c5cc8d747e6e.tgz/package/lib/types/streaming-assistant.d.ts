/** Browser-safe reconstruction of durably advertised streaming tool batches. */
import type { AssistantStreamRecord, ContentBlock, ReplayEnvelope } from '@deepseek-ai/dsh-llm';
import type { SessionMessageProjection } from './surface.ts';
/** One block and its exact, independently replayable stream segment. */
export interface StreamedAssistantBlock {
    readonly index: number;
    readonly block: ContentBlock;
    readonly closed: boolean;
    readonly stream: AssistantStreamRecord[];
}
/**
 * Retain completed tools even after a failed or truncated response. Incomplete
 * calls become eligible only at a successful terminal finish. Replay entries
 * follow the same keep/drop positions, including opaque provider signatures.
 * @param stream - the exact accumulated response chunks.
 * @param incompleteBlocks - the recorded policy for unclosed blocks on unsuccessful settlement.
 * @returns safe blocks in first-seen model order and aligned replay metadata.
 */
export declare function assembleStreamedAssistant(stream: readonly AssistantStreamRecord[], incompleteBlocks?: 'discard'): {
    blocks: StreamedAssistantBlock[];
    replayState?: ReplayEnvelope;
};
/** Built-in definitions shared by live, detached, restored, and browser folds. */
export declare const assistantStreamProjections: readonly SessionMessageProjection[];
//# sourceMappingURL=streaming-assistant.d.ts.map