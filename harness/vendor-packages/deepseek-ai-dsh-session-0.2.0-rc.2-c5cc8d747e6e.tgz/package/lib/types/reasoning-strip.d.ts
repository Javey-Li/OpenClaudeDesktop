import type { SessionMessageProjection } from './surface.ts';
/** Validate a complete decision before projecting any changed messages. */
export declare const reasoningStripProjection: SessionMessageProjection<'assistant/reasoning-strip'>;
//# sourceMappingURL=reasoning-strip.d.ts.map