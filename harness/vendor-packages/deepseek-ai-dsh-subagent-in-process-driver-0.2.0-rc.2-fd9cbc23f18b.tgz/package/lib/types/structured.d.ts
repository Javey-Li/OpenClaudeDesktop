/**
 * Child-scoped structured-output tool, prompt instruction, terminal guard, and authoritative
 * result capture for in-process subagents. Each child registers its real schema on its own
 * scope, so concurrent runs do not interact and disposal leaves no global residue. The prompt
 * contribution is ordinary reconstructed request state.
 *
 * Capture commits only after the authoritative `tools/result` succeeds; PTC mode capture also
 * waits for the enclosing `run_code` result. Call completion guards later tools; response
 * completion finishes the batch and retains its last valid capture. Both enforce the retry cap.
 * @module @deepseek-ai/dsh-subagent-in-process-driver/structured
 */
import type { Context } from '@deepseek-ai/cordis';
import { type StructuredOutputSchema } from '@deepseek-ai/dsh-subagent';
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        /** Attribution only; readers preserve the recorded instruction without this producer.
         * @persistenceAttribution
         */
        'subagent-structured-output': {
            kind: 'subagent-structured-output';
            form: 'instructions';
        };
    }
}
/** Logged reminder emitted once if the model finishes without a valid capture. */
export declare const STRUCTURED_OUTPUT_REMINDER: string;
/** The model-facing tool name a structured child must call to finish. */
export declare const STRUCTURED_OUTPUT_TOOL = "structured_output";
/**
 * The instruction registered as the child's trailing scoped prompt section:
 * the demand travels with the
 * tool, as ordinary prompt state of exactly one agent.
 */
export declare const STRUCTURED_OUTPUT_INSTRUCTION: string;
/** One structured run's live handle: read the captured value once the child settles. */
export interface StructuredAttachment {
    /**
     * The captured value, once the child called the tool with valid arguments
     * and the authoritative final tool result accepted that call.
     * @returns the committed value, or undefined while none was accepted.
     */
    captured(): {
        value: unknown;
    } | undefined;
    /** Terminal schema failure, when no result survived. */
    failure(): string | undefined;
    /** Calls handled before response completion or the retry limit; undefined in legacy call mode. */
    toolCalls(): number | undefined;
}
/**
 * Attach the scoped capture tool, instruction, and enforcement to a child during
 * its creation window. Child disposal removes every registration.
 * @param childCtx - the child agent's scope context (`setup`'s argument).
 * @param schema - the full object-rooted JSON Schema to enforce.
 * @param maxFailures - maximum failed capture calls before ending the child (default 5).
 * @param completion - finish the current response instead of rejecting calls after the first capture.
 * @returns the attachment handle (read `captured()` after the child settles).
 */
export declare function attachStructuredRuntime(childCtx: Context, schema: StructuredOutputSchema, maxFailures?: number, completion?: 'response'): StructuredAttachment;
//# sourceMappingURL=structured.d.ts.map